DROP DATABASE IF EXISTS ChocolateriaUnificada;
CREATE DATABASE ChocolateriaUnificada;
USE ChocolateriaUnificada;

-- Desabilita a verificação de chaves estrangeiras para evitar erros durante as inserções
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------
-- ESTRUTURA DAS TABELAS
-- -----------------------------------------------------

-- Tabela Estoque (sem fornecedor agora)
CREATE TABLE Estoque (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    id_filial VARCHAR(4),
    nome_do_chocolate VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL,
    preco DECIMAL(10, 2),
    data_de_validade DATE,
    data_que_foi_entregue DATE,
    tipo_do_chocolate VARCHAR(100),
    peso DECIMAL(10, 2),
    FOREIGN KEY (id_filial) REFERENCES Filial(id_filial)
);

-- Tabela Funcionario
CREATE TABLE Funcionario (
    id_funcionario INT PRIMARY KEY AUTO_INCREMENT,
    id_conta INT,
    nome VARCHAR(100) NOT NULL,
    idade INT,
    cpf VARCHAR(15),
    data_entrada DATE,
    cargo VARCHAR(100) NOT NULL,
    salario DECIMAL(10, 2),
    telefone VARCHAR(20)
);

-- Tabela Conta
CREATE TABLE Conta (
    ID_Conta INT PRIMARY KEY,
    ID_Funcionario INT,
    Data_Nascimento DATE,
    Username VARCHAR(50),
    Senha VARCHAR(50),
    Telefone VARCHAR(20),
    Email VARCHAR(50)
);

-- Tabela Cliente
CREATE TABLE Cliente (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    id_conta INT,
    id_filial VARCHAR(4),
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100),
    cpf VARCHAR(15),
    rg VARCHAR(15),
    data_de_nascimento DATE,
    idade INT,
    endereco VARCHAR(200),
    cep VARCHAR(10),
    bairro VARCHAR(100),
    estado VARCHAR(50),
    municipio VARCHAR(100),
    pais VARCHAR(50),
    FOREIGN KEY (id_filial) REFERENCES Filial(id_filial)
);

-- Tabela Filial
CREATE TABLE Filial (
    id_filial VARCHAR(4) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    endereco VARCHAR(200),
    telefone VARCHAR(20),
    cep VARCHAR(10),
    cnpj VARCHAR(20),
    bairro VARCHAR(100),
    estado VARCHAR(50),
    municipio VARCHAR(100),
    quantidade_de_funcionarios INT,
    clientes_por_dia INT,
    email VARCHAR(100),
    pais VARCHAR(50)
);

-- Tabela Vendas
CREATE TABLE Vendas (
    id_venda INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    id_filial VARCHAR(4),
    data_da_compra DATE,
    valor_total DECIMAL(10, 2),
    status VARCHAR(50),
    forma_de_pagamento VARCHAR(50),
    data_do_envio DATE,
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_filial) REFERENCES Filial(id_filial)
);

/*
Inserts Vendas
*/
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (107, 'FL01', '2024-05-05', 13.18, 'Cancelado', 'Dinheiro', '2024-05-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (140, 'FL05', '2024-05-23', 283.99, 'Pendente', 'Pix', '2024-09-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (4, 'FL03', '2024-01-06', 222.56, 'Pendente', 'Pix', '2024-06-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (69, 'FL07', '2024-02-13', 434.21, 'Pendente', 'Pix', '2024-06-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (108, 'FL11', '2024-08-05', 413.29, 'Pendente', 'Dinheiro', '2024-05-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (135, 'FL12', '2024-01-18', 112.22, 'Pendente', 'Cartão de Débito', '2024-06-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (187, 'FL07', '2024-01-28', 391.22, 'Enviado', 'Cartão de Crédito', '2024-11-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (12, 'FL16', '2024-11-09', 466.34, 'Cancelado', 'Cartão de Débito', '2024-09-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL07', '2024-08-18', 450.25, 'Enviado', 'Pix', '2024-08-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (1, 'CF01', '2024-06-01', 360.28, 'Pendente', 'Pix', '2024-08-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (36, 'FL02', '2024-10-16', 457.19, 'Cancelado', 'Dinheiro', '2024-05-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (10, 'FL18', '2024-12-05', 364.95, 'Cancelado', 'Pix', '2024-12-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (118, 'FL03', '2024-07-08', 49.73, 'Pendente', 'Dinheiro', '2024-01-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (93, 'FL17', '2024-07-28', 152.28, 'Pendente', 'Dinheiro', '2024-03-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (73, 'FL11', '2024-02-04', 216.22, 'Pendente', 'Cartão de Débito', '2024-07-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (149, 'FL11', '2024-09-01', 118.53, 'Pendente', 'Dinheiro', '2024-07-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (187, 'FL05', '2024-06-21', 221.43, 'Cancelado', 'Dinheiro', '2024-12-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (100, 'FL20', '2024-05-24', 498.92, 'Pendente', 'Dinheiro', '2024-12-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (103, 'FL07', '2024-03-18', 82.97, 'Cancelado', 'Cartão de Crédito', '2024-03-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL14', '2024-12-28', 28.66, 'Pendente', 'Cartão de Débito', '2024-08-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (101, 'FL06', '2024-09-03', 409.8, 'Pendente', 'Dinheiro', '2024-01-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (152, 'FL15', '2024-09-18', 157.0, 'Pendente', 'Cartão de Débito', '2024-04-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (117, 'FL07', '2024-01-15', 221.62, 'Pendente', 'Dinheiro', '2024-12-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (132, 'FL12', '2024-11-23', 183.92, 'Cancelado', 'Cartão de Débito', '2024-02-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (38, 'CF01', '2024-06-02', 78.04, 'Cancelado', 'Pix', '2024-09-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (76, 'FL04', '2024-08-24', 235.85, 'Enviado', 'Pix', '2024-12-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (133, 'CF01', '2024-04-01', 490.36, 'Cancelado', 'Dinheiro', '2024-09-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (160, 'FL17', '2024-01-12', 45.13, 'Pendente', 'Pix', '2024-04-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (112, 'FL10', '2024-04-19', 68.14, 'Cancelado', 'Pix', '2024-11-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (84, 'FL17', '2024-09-23', 261.53, 'Pendente', 'Cartão de Crédito', '2024-04-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (199, 'FL14', '2024-12-23', 470.95, 'Cancelado', 'Dinheiro', '2024-07-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (158, 'FL12', '2024-12-16', 144.83, 'Pendente', 'Dinheiro', '2024-04-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (122, 'FL19', '2024-07-13', 195.69, 'Cancelado', 'Cartão de Crédito', '2024-01-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (35, 'FL06', '2024-08-07', 409.31, 'Pendente', 'Pix', '2024-06-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (159, 'FL17', '2024-03-16', 30.31, 'Cancelado', 'Cartão de Crédito', '2024-08-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (172, 'FL20', '2024-01-12', 129.37, 'Cancelado', 'Pix', '2024-04-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (181, 'FL05', '2024-06-23', 235.66, 'Pendente', 'Dinheiro', '2024-02-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (172, 'FL03', '2024-04-16', 453.66, 'Cancelado', 'Pix', '2024-02-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (11, 'FL16', '2024-09-22', 363.99, 'Pendente', 'Pix', '2024-11-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (164, 'FL15', '2024-10-19', 248.03, 'Enviado', 'Dinheiro', '2024-04-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (27, 'FL04', '2024-09-06', 338.35, 'Cancelado', 'Cartão de Débito', '2024-03-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (44, 'FL07', '2024-03-08', 42.61, 'Cancelado', 'Pix', '2024-03-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (82, 'FL01', '2024-01-08', 318.02, 'Cancelado', 'Pix', '2024-11-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (31, 'FL14', '2024-03-16', 411.24, 'Enviado', 'Cartão de Débito', '2024-12-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (135, 'FL04', '2024-09-25', 312.29, 'Pendente', 'Cartão de Crédito', '2024-04-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (97, 'FL12', '2024-06-19', 134.0, 'Cancelado', 'Pix', '2024-01-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (86, 'FL12', '2024-09-03', 79.57, 'Pendente', 'Pix', '2024-08-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (96, 'FL09', '2024-02-20', 169.06, 'Cancelado', 'Dinheiro', '2024-04-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (139, 'FL16', '2024-10-13', 76.84, 'Enviado', 'Pix', '2024-05-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (190, 'FL06', '2024-11-06', 59.74, 'Pendente', 'Cartão de Débito', '2024-03-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (5, 'FL13', '2024-05-04', 159.65, 'Enviado', 'Pix', '2024-01-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (47, 'FL18', '2024-01-14', 266.42, 'Cancelado', 'Cartão de Crédito', '2024-05-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (139, 'FL09', '2024-01-12', 261.51, 'Enviado', 'Cartão de Crédito', '2024-06-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (56, 'FL11', '2024-01-27', 269.32, 'Pendente', 'Pix', '2024-02-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (24, 'FL05', '2024-03-04', 233.06, 'Cancelado', 'Dinheiro', '2024-09-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (4, 'FL02', '2024-10-21', 302.37, 'Pendente', 'Dinheiro', '2024-11-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (194, 'FL11', '2024-02-12', 137.36, 'Enviado', 'Cartão de Débito', '2024-10-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (40, 'FL20', '2024-01-05', 57.81, 'Pendente', 'Dinheiro', '2024-05-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (159, 'FL18', '2024-05-04', 244.44, 'Pendente', 'Dinheiro', '2024-06-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (114, 'FL08', '2024-05-12', 370.91, 'Enviado', 'Dinheiro', '2024-07-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (39, 'FL10', '2024-01-08', 406.44, 'Enviado', 'Cartão de Débito', '2024-02-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (159, 'FL04', '2024-12-01', 378.0, 'Cancelado', 'Cartão de Débito', '2024-10-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (96, 'FL14', '2024-05-17', 469.83, 'Pendente', 'Cartão de Débito', '2024-08-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (181, 'CF01', '2024-09-23', 326.96, 'Cancelado', 'Cartão de Débito', '2024-07-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (46, 'FL17', '2024-10-14', 376.4, 'Cancelado', 'Pix', '2024-12-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (156, 'FL08', '2024-04-27', 438.22, 'Pendente', 'Dinheiro', '2024-02-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (167, 'FL10', '2024-02-22', 208.28, 'Pendente', 'Cartão de Débito', '2024-10-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (25, 'FL10', '2024-02-25', 180.53, 'Cancelado', 'Pix', '2024-09-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL11', '2024-03-06', 312.18, 'Cancelado', 'Cartão de Débito', '2024-06-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (185, 'FL12', '2024-09-17', 213.06, 'Pendente', 'Pix', '2024-01-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (65, 'FL10', '2024-08-03', 17.97, 'Cancelado', 'Pix', '2024-10-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL13', '2024-07-24', 455.96, 'Enviado', 'Cartão de Débito', '2024-07-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (49, 'FL13', '2024-02-09', 213.41, 'Pendente', 'Pix', '2024-04-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (198, 'FL14', '2024-07-24', 70.37, 'Pendente', 'Cartão de Crédito', '2024-10-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (162, 'FL10', '2024-09-26', 304.1, 'Enviado', 'Pix', '2024-12-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (91, 'FL09', '2024-12-17', 394.16, 'Enviado', 'Dinheiro', '2024-05-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL01', '2024-02-27', 53.03, 'Pendente', 'Dinheiro', '2024-05-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (89, 'FL01', '2024-05-11', 93.46, 'Pendente', 'Dinheiro', '2024-04-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (92, 'FL11', '2024-02-25', 329.17, 'Pendente', 'Cartão de Débito', '2024-09-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (83, 'FL07', '2024-01-08', 262.86, 'Enviado', 'Dinheiro', '2024-02-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (14, 'FL11', '2024-01-16', 373.34, 'Pendente', 'Cartão de Débito', '2024-07-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (197, 'FL19', '2024-10-01', 191.1, 'Enviado', 'Dinheiro', '2024-08-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (66, 'FL07', '2024-03-27', 496.01, 'Cancelado', 'Cartão de Débito', '2024-04-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (2, 'CF01', '2024-09-23', 284.1, 'Enviado', 'Dinheiro', '2024-11-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (123, 'FL06', '2024-06-28', 384.46, 'Pendente', 'Dinheiro', '2024-04-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (116, 'FL03', '2024-07-05', 220.67, 'Pendente', 'Pix', '2024-09-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (200, 'FL18', '2024-08-28', 166.14, 'Pendente', 'Dinheiro', '2024-03-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (5, 'FL18', '2024-09-06', 206.82, 'Enviado', 'Cartão de Débito', '2024-08-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (135, 'FL08', '2024-09-07', 499.28, 'Cancelado', 'Cartão de Débito', '2024-11-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (138, 'FL14', '2024-07-13', 101.18, 'Cancelado', 'Cartão de Débito', '2024-08-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (131, 'FL15', '2024-01-04', 133.89, 'Pendente', 'Cartão de Débito', '2024-12-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (135, 'FL09', '2024-06-04', 107.93, 'Cancelado', 'Cartão de Crédito', '2024-03-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (195, 'FL12', '2024-07-01', 446.44, 'Enviado', 'Cartão de Crédito', '2024-10-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (3, 'FL11', '2024-11-03', 330.46, 'Pendente', 'Cartão de Débito', '2024-12-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (72, 'FL10', '2024-09-12', 241.31, 'Pendente', 'Cartão de Débito', '2024-02-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (188, 'FL06', '2024-02-22', 120.71, 'Cancelado', 'Cartão de Crédito', '2024-09-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (145, 'FL09', '2024-02-09', 35.97, 'Enviado', 'Pix', '2024-04-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (58, 'FL14', '2024-05-08', 26.3, 'Cancelado', 'Dinheiro', '2024-12-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (68, 'FL12', '2024-03-21', 259.55, 'Enviado', 'Cartão de Crédito', '2024-06-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (34, 'FL01', '2024-07-18', 400.72, 'Pendente', 'Pix', '2024-05-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (60, 'FL07', '2024-10-11', 307.45, 'Enviado', 'Cartão de Crédito', '2024-12-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (140, 'FL12', '2024-07-27', 326.53, 'Pendente', 'Pix', '2024-02-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (98, 'FL02', '2024-08-11', 453.64, 'Pendente', 'Dinheiro', '2024-04-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (27, 'FL05', '2024-07-25', 158.05, 'Cancelado', 'Dinheiro', '2024-03-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (81, 'FL13', '2024-06-10', 148.4, 'Cancelado', 'Cartão de Crédito', '2024-11-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (160, 'FL06', '2024-03-13', 140.82, 'Cancelado', 'Dinheiro', '2024-04-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (136, 'FL11', '2024-11-09', 19.45, 'Pendente', 'Dinheiro', '2024-04-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (98, 'FL07', '2024-10-26', 443.47, 'Enviado', 'Dinheiro', '2024-10-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (121, 'FL14', '2024-02-23', 115.46, 'Cancelado', 'Cartão de Débito', '2024-04-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (131, 'FL06', '2024-07-02', 282.06, 'Cancelado', 'Cartão de Débito', '2024-04-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (48, 'FL19', '2024-02-01', 61.14, 'Pendente', 'Cartão de Crédito', '2024-12-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (96, 'FL07', '2024-02-10', 391.16, 'Cancelado', 'Pix', '2024-02-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (51, 'FL16', '2024-12-13', 18.26, 'Cancelado', 'Cartão de Débito', '2024-05-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (48, 'FL15', '2024-08-02', 321.27, 'Enviado', 'Pix', '2024-04-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (99, 'FL16', '2024-01-01', 445.51, 'Enviado', 'Dinheiro', '2024-05-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (126, 'FL16', '2024-12-15', 180.33, 'Pendente', 'Cartão de Crédito', '2024-02-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (34, 'FL19', '2024-03-12', 14.57, 'Pendente', 'Cartão de Débito', '2024-07-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (174, 'FL09', '2024-11-09', 478.5, 'Enviado', 'Cartão de Débito', '2024-09-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (180, 'FL18', '2024-02-10', 79.48, 'Enviado', 'Pix', '2024-09-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (78, 'FL04', '2024-07-21', 386.51, 'Pendente', 'Dinheiro', '2024-08-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (109, 'FL20', '2024-08-15', 418.49, 'Enviado', 'Dinheiro', '2024-11-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (7, 'FL20', '2024-11-14', 404.7, 'Cancelado', 'Cartão de Débito', '2024-12-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (12, 'FL04', '2024-06-27', 214.89, 'Cancelado', 'Pix', '2024-07-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (30, 'FL19', '2024-02-22', 240.75, 'Pendente', 'Cartão de Crédito', '2024-03-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (191, 'FL06', '2024-03-14', 178.21, 'Pendente', 'Cartão de Crédito', '2024-03-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (37, 'FL16', '2024-11-02', 303.44, 'Pendente', 'Pix', '2024-05-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (90, 'FL07', '2024-02-21', 232.3, 'Cancelado', 'Cartão de Crédito', '2024-09-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (151, 'FL05', '2024-05-21', 17.12, 'Enviado', 'Dinheiro', '2024-07-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (48, 'FL13', '2024-12-22', 44.1, 'Enviado', 'Dinheiro', '2024-08-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (73, 'FL14', '2024-08-26', 171.8, 'Enviado', 'Pix', '2024-05-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (7, 'FL17', '2024-02-16', 268.63, 'Pendente', 'Pix', '2024-03-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (101, 'FL14', '2024-01-07', 300.68, 'Enviado', 'Cartão de Crédito', '2024-06-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (106, 'FL17', '2024-10-12', 373.56, 'Enviado', 'Dinheiro', '2024-07-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (52, 'FL06', '2024-03-19', 233.78, 'Cancelado', 'Cartão de Débito', '2024-11-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (185, 'FL07', '2024-02-09', 295.38, 'Cancelado', 'Cartão de Débito', '2024-02-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (157, 'FL15', '2024-11-06', 281.77, 'Enviado', 'Pix', '2024-01-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (149, 'FL13', '2024-08-02', 314.23, 'Pendente', 'Pix', '2024-01-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (36, 'FL05', '2024-10-22', 162.83, 'Enviado', 'Cartão de Crédito', '2024-03-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (193, 'FL05', '2024-09-19', 141.59, 'Pendente', 'Cartão de Débito', '2024-08-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (93, 'FL13', '2024-04-12', 30.72, 'Cancelado', 'Cartão de Crédito', '2024-02-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (101, 'CF01', '2024-10-10', 258.05, 'Enviado', 'Dinheiro', '2024-09-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (67, 'FL17', '2024-10-01', 242.99, 'Enviado', 'Dinheiro', '2024-07-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (120, 'FL02', '2024-07-02', 120.9, 'Cancelado', 'Cartão de Crédito', '2024-08-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (174, 'FL04', '2024-05-27', 173.48, 'Cancelado', 'Pix', '2024-08-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (173, 'FL16', '2024-10-02', 320.72, 'Enviado', 'Pix', '2024-11-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (113, 'FL02', '2024-09-09', 233.76, 'Cancelado', 'Cartão de Débito', '2024-03-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (188, 'FL02', '2024-08-21', 329.04, 'Enviado', 'Dinheiro', '2024-03-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'FL14', '2024-03-09', 209.39, 'Pendente', 'Cartão de Débito', '2024-01-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (64, 'FL05', '2024-05-04', 152.32, 'Cancelado', 'Pix', '2024-03-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (100, 'FL17', '2024-10-02', 243.01, 'Enviado', 'Dinheiro', '2024-06-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (4, 'FL15', '2024-09-16', 235.99, 'Cancelado', 'Pix', '2024-12-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (49, 'FL12', '2024-09-24', 348.71, 'Pendente', 'Pix', '2024-12-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (12, 'FL11', '2024-06-12', 37.79, 'Cancelado', 'Dinheiro', '2024-01-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (90, 'FL02', '2024-04-21', 284.43, 'Pendente', 'Cartão de Crédito', '2024-09-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (116, 'FL02', '2024-09-02', 301.87, 'Pendente', 'Pix', '2024-03-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (151, 'FL12', '2024-06-07', 400.83, 'Cancelado', 'Cartão de Crédito', '2024-11-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (109, 'FL06', '2024-10-27', 285.57, 'Cancelado', 'Cartão de Débito', '2024-07-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (14, 'FL17', '2024-07-18', 483.15, 'Pendente', 'Cartão de Crédito', '2024-04-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (76, 'FL09', '2024-03-18', 374.82, 'Enviado', 'Dinheiro', '2024-10-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (72, 'FL17', '2024-10-09', 263.35, 'Cancelado', 'Cartão de Crédito', '2024-04-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL05', '2024-03-22', 327.06, 'Cancelado', 'Cartão de Crédito', '2024-07-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (7, 'FL10', '2024-10-25', 96.31, 'Enviado', 'Pix', '2024-04-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (178, 'FL09', '2024-11-14', 312.64, 'Cancelado', 'Pix', '2024-05-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (47, 'FL03', '2024-10-26', 473.5, 'Cancelado', 'Cartão de Crédito', '2024-03-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (174, 'FL19', '2024-06-08', 155.29, 'Pendente', 'Dinheiro', '2024-02-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (161, 'FL09', '2024-02-28', 488.71, 'Cancelado', 'Dinheiro', '2024-10-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'FL05', '2024-06-18', 329.28, 'Cancelado', 'Cartão de Débito', '2024-10-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (195, 'FL11', '2024-09-08', 374.25, 'Cancelado', 'Cartão de Débito', '2024-12-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (32, 'FL17', '2024-02-19', 493.83, 'Pendente', 'Pix', '2024-04-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (18, 'FL12', '2024-07-20', 453.42, 'Pendente', 'Dinheiro', '2024-09-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (150, 'FL18', '2024-01-12', 283.56, 'Enviado', 'Cartão de Crédito', '2024-11-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (43, 'FL16', '2024-02-21', 29.68, 'Enviado', 'Pix', '2024-04-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (34, 'FL11', '2024-10-26', 39.0, 'Enviado', 'Pix', '2024-01-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (118, 'CF01', '2024-04-13', 199.28, 'Pendente', 'Cartão de Crédito', '2024-06-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (138, 'FL02', '2024-02-18', 480.22, 'Enviado', 'Cartão de Crédito', '2024-05-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (188, 'FL16', '2024-06-08', 93.17, 'Cancelado', 'Cartão de Débito', '2024-09-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (143, 'CF01', '2024-04-10', 91.55, 'Enviado', 'Cartão de Débito', '2024-09-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (188, 'FL03', '2024-05-23', 243.89, 'Enviado', 'Cartão de Débito', '2024-12-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (161, 'FL13', '2024-10-04', 425.12, 'Pendente', 'Pix', '2024-08-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL20', '2024-11-03', 148.12, 'Cancelado', 'Cartão de Crédito', '2024-09-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (9, 'FL04', '2024-08-14', 355.52, 'Cancelado', 'Cartão de Crédito', '2024-05-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (48, 'FL04', '2024-05-18', 128.11, 'Enviado', 'Dinheiro', '2024-01-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (87, 'FL06', '2024-02-11', 127.13, 'Pendente', 'Cartão de Débito', '2024-04-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (58, 'FL10', '2024-04-08', 236.85, 'Enviado', 'Cartão de Débito', '2024-07-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (29, 'FL13', '2024-12-24', 53.4, 'Pendente', 'Cartão de Crédito', '2024-03-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (198, 'FL12', '2024-12-10', 87.98, 'Enviado', 'Cartão de Crédito', '2024-06-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (190, 'FL12', '2024-04-08', 114.54, 'Enviado', 'Cartão de Débito', '2024-02-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (39, 'FL12', '2024-05-26', 468.37, 'Pendente', 'Cartão de Crédito', '2024-02-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (178, 'FL08', '2024-04-07', 161.73, 'Pendente', 'Dinheiro', '2024-09-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (46, 'FL16', '2024-05-20', 10.92, 'Cancelado', 'Cartão de Crédito', '2024-02-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (118, 'FL09', '2024-03-04', 460.8, 'Pendente', 'Dinheiro', '2024-02-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (53, 'FL03', '2024-06-16', 413.92, 'Enviado', 'Pix', '2024-02-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (14, 'FL20', '2024-04-18', 437.28, 'Enviado', 'Pix', '2024-01-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (150, 'FL12', '2024-08-21', 257.15, 'Cancelado', 'Cartão de Débito', '2024-10-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (1, 'FL06', '2024-01-07', 267.85, 'Cancelado', 'Cartão de Crédito', '2024-05-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (67, 'CF01', '2024-04-19', 326.36, 'Cancelado', 'Pix', '2024-11-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (129, 'FL03', '2024-06-09', 80.53, 'Enviado', 'Pix', '2024-07-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (168, 'FL05', '2024-03-26', 199.59, 'Cancelado', 'Pix', '2024-11-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (183, 'FL02', '2024-05-22', 27.64, 'Pendente', 'Cartão de Crédito', '2024-01-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (74, 'FL13', '2024-07-18', 66.03, 'Cancelado', 'Cartão de Débito', '2024-07-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (79, 'FL05', '2024-02-14', 345.84, 'Enviado', 'Pix', '2024-02-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (107, 'FL09', '2024-02-20', 244.82, 'Pendente', 'Dinheiro', '2024-08-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (24, 'FL07', '2024-04-01', 377.24, 'Cancelado', 'Cartão de Débito', '2024-03-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (98, 'FL12', '2024-04-12', 304.19, 'Enviado', 'Cartão de Débito', '2024-04-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (56, 'FL17', '2024-12-10', 440.35, 'Pendente', 'Cartão de Crédito', '2024-10-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (166, 'FL08', '2024-01-06', 265.1, 'Enviado', 'Cartão de Débito', '2024-03-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (44, 'FL15', '2024-06-25', 271.63, 'Pendente', 'Dinheiro', '2024-05-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (140, 'FL13', '2024-09-23', 91.21, 'Cancelado', 'Pix', '2024-06-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (40, 'FL14', '2024-10-20', 181.5, 'Enviado', 'Cartão de Crédito', '2024-12-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (5, 'FL07', '2024-11-18', 379.61, 'Cancelado', 'Pix', '2024-08-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (20, 'FL13', '2024-08-11', 274.36, 'Cancelado', 'Cartão de Débito', '2024-05-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (37, 'FL02', '2024-09-21', 94.32, 'Enviado', 'Cartão de Débito', '2024-02-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (64, 'FL16', '2024-04-02', 109.86, 'Enviado', 'Cartão de Crédito', '2024-06-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (62, 'FL16', '2024-07-16', 82.4, 'Enviado', 'Cartão de Débito', '2024-07-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (4, 'FL13', '2024-05-20', 385.97, 'Pendente', 'Pix', '2024-03-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (109, 'FL03', '2024-03-27', 118.89, 'Cancelado', 'Pix', '2024-04-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (27, 'FL05', '2024-05-28', 211.48, 'Pendente', 'Cartão de Débito', '2024-09-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (75, 'FL18', '2024-04-11', 443.88, 'Pendente', 'Dinheiro', '2024-07-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (81, 'FL08', '2024-11-01', 297.34, 'Pendente', 'Cartão de Débito', '2024-05-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (105, 'FL14', '2024-06-18', 99.74, 'Pendente', 'Cartão de Crédito', '2024-06-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (53, 'FL19', '2024-02-19', 400.58, 'Cancelado', 'Dinheiro', '2024-06-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (28, 'FL07', '2024-07-05', 189.14, 'Cancelado', 'Cartão de Crédito', '2024-03-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (16, 'FL01', '2024-03-05', 302.24, 'Enviado', 'Dinheiro', '2024-08-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (193, 'FL09', '2024-03-04', 494.55, 'Pendente', 'Pix', '2024-11-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (76, 'FL01', '2024-09-26', 97.6, 'Pendente', 'Pix', '2024-02-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (137, 'FL14', '2024-11-19', 34.3, 'Pendente', 'Cartão de Débito', '2024-05-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (159, 'FL20', '2024-10-10', 304.55, 'Enviado', 'Cartão de Débito', '2024-05-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (150, 'FL05', '2024-11-08', 132.5, 'Enviado', 'Dinheiro', '2024-08-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (155, 'FL03', '2024-01-02', 124.4, 'Enviado', 'Cartão de Débito', '2024-03-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (101, 'FL04', '2024-10-11', 353.2, 'Cancelado', 'Cartão de Crédito', '2024-05-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (162, 'FL20', '2024-02-05', 212.84, 'Pendente', 'Dinheiro', '2024-02-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (127, 'FL14', '2024-02-15', 285.91, 'Pendente', 'Dinheiro', '2024-03-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (33, 'FL12', '2024-02-13', 458.69, 'Cancelado', 'Pix', '2024-09-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (156, 'FL05', '2024-11-09', 221.37, 'Pendente', 'Dinheiro', '2024-03-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (45, 'FL02', '2024-12-07', 384.97, 'Enviado', 'Pix', '2024-11-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (64, 'FL05', '2024-05-28', 22.21, 'Pendente', 'Pix', '2024-08-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (3, 'FL13', '2024-06-09', 19.77, 'Pendente', 'Cartão de Crédito', '2024-08-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (26, 'FL06', '2024-04-24', 59.82, 'Enviado', 'Dinheiro', '2024-12-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (67, 'FL17', '2024-01-18', 421.6, 'Enviado', 'Pix', '2024-03-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (6, 'FL11', '2024-07-17', 419.38, 'Cancelado', 'Pix', '2024-04-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (110, 'FL01', '2024-05-27', 279.57, 'Pendente', 'Cartão de Crédito', '2024-05-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (140, 'FL17', '2024-04-03', 247.3, 'Cancelado', 'Cartão de Crédito', '2024-04-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (131, 'FL13', '2024-09-14', 248.68, 'Cancelado', 'Cartão de Débito', '2024-02-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL09', '2024-05-26', 346.48, 'Pendente', 'Cartão de Crédito', '2024-10-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (116, 'FL13', '2024-02-04', 483.29, 'Enviado', 'Cartão de Crédito', '2024-11-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (68, 'FL09', '2024-07-02', 327.2, 'Enviado', 'Cartão de Crédito', '2024-07-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (114, 'FL06', '2024-04-27', 253.08, 'Enviado', 'Dinheiro', '2024-07-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (135, 'FL14', '2024-03-03', 292.01, 'Pendente', 'Cartão de Débito', '2024-05-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (148, 'FL10', '2024-04-24', 321.62, 'Pendente', 'Dinheiro', '2024-09-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (163, 'FL17', '2024-03-07', 78.61, 'Cancelado', 'Pix', '2024-04-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (131, 'FL07', '2024-05-15', 378.44, 'Cancelado', 'Pix', '2024-11-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'FL14', '2024-07-02', 290.85, 'Pendente', 'Dinheiro', '2024-04-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (68, 'FL07', '2024-02-12', 34.46, 'Cancelado', 'Cartão de Crédito', '2024-06-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (113, 'FL09', '2024-03-04', 21.23, 'Cancelado', 'Cartão de Crédito', '2024-10-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (10, 'CF01', '2024-03-16', 181.62, 'Cancelado', 'Cartão de Crédito', '2024-03-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (189, 'FL06', '2024-09-24', 419.43, 'Pendente', 'Cartão de Débito', '2024-06-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (1, 'FL11', '2024-02-23', 437.12, 'Enviado', 'Pix', '2024-09-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL17', '2024-04-10', 72.13, 'Pendente', 'Cartão de Débito', '2024-08-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (6, 'FL11', '2024-10-05', 93.83, 'Enviado', 'Dinheiro', '2024-01-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'FL14', '2024-10-25', 180.07, 'Enviado', 'Cartão de Débito', '2024-03-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (138, 'FL17', '2024-09-21', 329.43, 'Cancelado', 'Cartão de Crédito', '2024-12-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (198, 'FL08', '2024-11-13', 20.33, 'Pendente', 'Cartão de Débito', '2024-09-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (175, 'FL04', '2024-07-27', 330.7, 'Enviado', 'Dinheiro', '2024-07-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (151, 'FL15', '2024-06-18', 451.57, 'Enviado', 'Cartão de Crédito', '2024-10-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (163, 'FL05', '2024-12-26', 454.09, 'Pendente', 'Pix', '2024-10-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (86, 'FL19', '2024-02-08', 74.55, 'Cancelado', 'Cartão de Crédito', '2024-07-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (5, 'FL10', '2024-01-10', 207.57, 'Pendente', 'Dinheiro', '2024-10-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (28, 'FL20', '2024-11-12', 484.07, 'Enviado', 'Cartão de Crédito', '2024-03-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (85, 'FL11', '2024-09-03', 294.81, 'Cancelado', 'Dinheiro', '2024-05-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (154, 'FL14', '2024-01-21', 413.09, 'Cancelado', 'Pix', '2024-04-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (94, 'FL13', '2024-03-16', 178.38, 'Enviado', 'Pix', '2024-05-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL01', '2024-08-05', 61.02, 'Cancelado', 'Cartão de Débito', '2024-11-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (34, 'FL17', '2024-03-18', 365.21, 'Cancelado', 'Pix', '2024-05-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (10, 'FL04', '2024-02-03', 100.23, 'Cancelado', 'Cartão de Crédito', '2024-04-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (21, 'FL02', '2024-02-19', 165.0, 'Pendente', 'Pix', '2024-01-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (28, 'FL05', '2024-06-11', 418.04, 'Pendente', 'Pix', '2024-09-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (108, 'CF01', '2024-01-18', 408.35, 'Enviado', 'Pix', '2024-08-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (32, 'FL14', '2024-03-26', 11.24, 'Cancelado', 'Pix', '2024-09-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'FL17', '2024-04-19', 46.05, 'Cancelado', 'Pix', '2024-09-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (36, 'CF01', '2024-03-09', 497.88, 'Cancelado', 'Pix', '2024-12-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (84, 'FL04', '2024-08-27', 423.46, 'Cancelado', 'Cartão de Débito', '2024-12-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (54, 'FL08', '2024-12-17', 41.5, 'Pendente', 'Cartão de Débito', '2024-09-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (119, 'FL03', '2024-11-01', 16.69, 'Cancelado', 'Dinheiro', '2024-11-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (75, 'FL08', '2024-09-18', 295.28, 'Pendente', 'Dinheiro', '2024-01-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (63, 'CF01', '2024-04-04', 204.44, 'Cancelado', 'Cartão de Crédito', '2024-10-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (84, 'FL08', '2024-07-07', 403.57, 'Pendente', 'Cartão de Crédito', '2024-03-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (165, 'FL11', '2024-12-18', 248.33, 'Pendente', 'Dinheiro', '2024-12-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (69, 'FL19', '2024-12-21', 454.95, 'Pendente', 'Cartão de Crédito', '2024-02-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (38, 'FL16', '2024-07-17', 107.05, 'Enviado', 'Dinheiro', '2024-04-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (158, 'FL07', '2024-10-06', 485.21, 'Cancelado', 'Cartão de Crédito', '2024-09-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (9, 'FL17', '2024-07-19', 18.35, 'Enviado', 'Cartão de Crédito', '2024-05-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (68, 'FL13', '2024-06-15', 276.83, 'Cancelado', 'Pix', '2024-11-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (136, 'FL19', '2024-01-12', 171.85, 'Enviado', 'Pix', '2024-04-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (13, 'FL12', '2024-09-12', 69.45, 'Cancelado', 'Cartão de Crédito', '2024-09-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (73, 'FL12', '2024-12-02', 441.86, 'Enviado', 'Cartão de Crédito', '2024-02-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (155, 'FL09', '2024-08-06', 28.06, 'Pendente', 'Dinheiro', '2024-09-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (45, 'FL20', '2024-11-13', 208.39, 'Pendente', 'Dinheiro', '2024-12-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (148, 'FL07', '2024-06-26', 250.58, 'Cancelado', 'Cartão de Crédito', '2024-10-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (194, 'FL01', '2024-02-02', 401.4, 'Enviado', 'Cartão de Débito', '2024-08-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (93, 'FL20', '2024-03-19', 115.06, 'Cancelado', 'Pix', '2024-07-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (153, 'FL08', '2024-03-05', 393.76, 'Cancelado', 'Dinheiro', '2024-01-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (144, 'FL20', '2024-06-18', 43.37, 'Enviado', 'Pix', '2024-02-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (160, 'FL15', '2024-07-17', 448.67, 'Enviado', 'Pix', '2024-04-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (184, 'CF01', '2024-01-11', 168.8, 'Enviado', 'Cartão de Débito', '2024-10-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (129, 'FL17', '2024-10-28', 175.43, 'Cancelado', 'Cartão de Débito', '2024-03-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (106, 'FL18', '2024-05-04', 114.08, 'Cancelado', 'Cartão de Crédito', '2024-04-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (115, 'FL16', '2024-06-18', 274.57, 'Enviado', 'Cartão de Crédito', '2024-12-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (36, 'FL10', '2024-10-17', 347.51, 'Pendente', 'Cartão de Débito', '2024-01-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (12, 'CF01', '2024-10-11', 389.57, 'Cancelado', 'Cartão de Débito', '2024-05-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (44, 'FL05', '2024-08-26', 64.49, 'Pendente', 'Cartão de Débito', '2024-08-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (87, 'FL09', '2024-06-07', 73.31, 'Pendente', 'Dinheiro', '2024-11-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (140, 'FL17', '2024-04-14', 428.69, 'Cancelado', 'Pix', '2024-09-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (32, 'FL05', '2024-03-20', 210.81, 'Pendente', 'Dinheiro', '2024-03-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (86, 'FL05', '2024-02-13', 333.38, 'Pendente', 'Pix', '2024-02-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (19, 'FL14', '2024-03-20', 404.26, 'Enviado', 'Dinheiro', '2024-07-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (29, 'FL14', '2024-10-05', 429.8, 'Pendente', 'Pix', '2024-01-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (28, 'FL02', '2024-07-06', 39.07, 'Cancelado', 'Cartão de Crédito', '2024-12-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (67, 'FL02', '2024-10-24', 408.56, 'Enviado', 'Cartão de Crédito', '2024-01-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL15', '2024-07-22', 203.2, 'Enviado', 'Cartão de Débito', '2024-01-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (33, 'FL01', '2024-07-25', 346.8, 'Cancelado', 'Pix', '2024-06-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (15, 'FL13', '2024-09-16', 393.22, 'Enviado', 'Cartão de Crédito', '2024-12-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (181, 'FL04', '2024-11-17', 64.96, 'Enviado', 'Dinheiro', '2024-03-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (26, 'FL13', '2024-03-23', 326.22, 'Pendente', 'Dinheiro', '2024-12-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (37, 'FL08', '2024-08-05', 408.52, 'Pendente', 'Dinheiro', '2024-12-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (88, 'FL17', '2024-02-05', 182.25, 'Pendente', 'Cartão de Crédito', '2024-04-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (37, 'FL03', '2024-10-19', 80.1, 'Cancelado', 'Pix', '2024-02-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (122, 'FL06', '2024-05-05', 79.66, 'Enviado', 'Cartão de Crédito', '2024-04-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (19, 'FL20', '2024-10-25', 405.13, 'Enviado', 'Cartão de Crédito', '2024-10-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (98, 'FL08', '2024-05-19', 344.58, 'Enviado', 'Pix', '2024-06-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (12, 'FL03', '2024-07-14', 363.53, 'Pendente', 'Cartão de Crédito', '2024-10-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (129, 'CF01', '2024-04-17', 265.91, 'Enviado', 'Pix', '2024-04-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (62, 'FL03', '2024-02-13', 136.95, 'Pendente', 'Cartão de Crédito', '2024-03-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (32, 'FL07', '2024-06-05', 129.92, 'Pendente', 'Cartão de Débito', '2024-09-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (28, 'FL06', '2024-06-23', 63.19, 'Cancelado', 'Cartão de Débito', '2024-07-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (96, 'FL06', '2024-03-26', 115.01, 'Pendente', 'Cartão de Débito', '2024-09-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (166, 'FL07', '2024-06-09', 285.29, 'Pendente', 'Cartão de Débito', '2024-04-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (129, 'FL11', '2024-02-01', 181.4, 'Cancelado', 'Dinheiro', '2024-11-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (138, 'CF01', '2024-07-21', 296.93, 'Enviado', 'Cartão de Crédito', '2024-03-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (59, 'FL12', '2024-01-18', 363.87, 'Cancelado', 'Cartão de Débito', '2024-12-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (147, 'FL07', '2024-05-20', 231.26, 'Enviado', 'Dinheiro', '2024-09-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (11, 'FL01', '2024-12-28', 160.17, 'Enviado', 'Dinheiro', '2024-05-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (74, 'FL02', '2024-02-01', 265.02, 'Enviado', 'Pix', '2024-11-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL09', '2024-02-05', 467.98, 'Enviado', 'Cartão de Débito', '2024-08-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (103, 'FL04', '2024-03-06', 384.43, 'Cancelado', 'Dinheiro', '2024-11-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (5, 'FL12', '2024-01-16', 72.07, 'Enviado', 'Cartão de Débito', '2024-06-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (182, 'FL02', '2024-02-11', 121.67, 'Enviado', 'Dinheiro', '2024-09-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (26, 'FL09', '2024-10-11', 238.31, 'Enviado', 'Cartão de Débito', '2024-01-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (175, 'FL07', '2024-05-20', 447.05, 'Pendente', 'Pix', '2024-04-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (121, 'FL11', '2024-11-23', 150.68, 'Enviado', 'Cartão de Crédito', '2024-11-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (167, 'FL17', '2024-03-26', 218.21, 'Enviado', 'Pix', '2024-02-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (21, 'FL11', '2024-09-16', 485.2, 'Cancelado', 'Cartão de Débito', '2024-07-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (9, 'FL03', '2024-06-27', 351.69, 'Enviado', 'Pix', '2024-05-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (139, 'FL12', '2024-04-23', 119.71, 'Enviado', 'Cartão de Débito', '2024-10-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (74, 'FL19', '2024-11-23', 38.95, 'Enviado', 'Cartão de Crédito', '2024-01-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (178, 'FL07', '2024-02-10', 153.1, 'Enviado', 'Cartão de Crédito', '2024-10-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (102, 'FL10', '2024-06-24', 346.1, 'Cancelado', 'Pix', '2024-09-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (60, 'FL12', '2024-09-03', 149.96, 'Enviado', 'Cartão de Crédito', '2024-07-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (88, 'FL16', '2024-06-01', 208.08, 'Cancelado', 'Pix', '2024-04-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (69, 'FL14', '2024-01-25', 459.3, 'Cancelado', 'Pix', '2024-01-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (169, 'FL19', '2024-10-05', 361.58, 'Enviado', 'Cartão de Crédito', '2024-05-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (181, 'FL01', '2024-02-15', 389.13, 'Pendente', 'Pix', '2024-12-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (20, 'FL10', '2024-06-25', 310.8, 'Enviado', 'Dinheiro', '2024-02-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (127, 'FL04', '2024-07-27', 27.41, 'Cancelado', 'Dinheiro', '2024-10-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (153, 'FL07', '2024-01-02', 98.71, 'Cancelado', 'Cartão de Débito', '2024-03-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (189, 'FL04', '2024-11-14', 402.86, 'Pendente', 'Cartão de Crédito', '2024-02-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (12, 'FL04', '2024-03-23', 411.74, 'Pendente', 'Cartão de Crédito', '2024-11-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (181, 'FL03', '2024-03-09', 399.43, 'Pendente', 'Dinheiro', '2024-03-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (17, 'FL06', '2024-09-04', 96.33, 'Cancelado', 'Pix', '2024-10-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (181, 'CF01', '2024-08-22', 439.43, 'Cancelado', 'Dinheiro', '2024-07-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (99, 'FL13', '2024-09-24', 437.1, 'Pendente', 'Cartão de Débito', '2024-03-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (111, 'FL02', '2024-09-23', 112.45, 'Pendente', 'Pix', '2024-06-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (92, 'FL05', '2024-11-16', 31.55, 'Pendente', 'Pix', '2024-02-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (187, 'CF01', '2024-01-15', 373.16, 'Pendente', 'Dinheiro', '2024-09-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (157, 'FL06', '2024-02-06', 483.7, 'Cancelado', 'Pix', '2024-11-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (90, 'FL01', '2024-08-20', 349.58, 'Cancelado', 'Pix', '2024-04-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (29, 'FL03', '2024-09-18', 487.56, 'Enviado', 'Dinheiro', '2024-10-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (57, 'FL12', '2024-09-03', 359.34, 'Enviado', 'Dinheiro', '2024-02-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (7, 'CF01', '2024-09-24', 34.9, 'Pendente', 'Cartão de Débito', '2024-02-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (44, 'FL03', '2024-02-24', 275.59, 'Cancelado', 'Pix', '2024-12-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (193, 'FL20', '2024-01-12', 395.63, 'Cancelado', 'Pix', '2024-08-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (121, 'FL19', '2024-11-16', 203.51, 'Cancelado', 'Dinheiro', '2024-05-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (163, 'FL02', '2024-10-14', 226.4, 'Pendente', 'Cartão de Débito', '2024-06-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (70, 'CF01', '2024-01-03', 48.85, 'Pendente', 'Dinheiro', '2024-10-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (24, 'FL08', '2024-08-27', 282.38, 'Enviado', 'Dinheiro', '2024-10-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (147, 'FL10', '2024-08-18', 284.13, 'Enviado', 'Cartão de Crédito', '2024-11-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (2, 'FL10', '2024-12-11', 431.13, 'Pendente', 'Pix', '2024-03-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (149, 'FL06', '2024-04-13', 211.72, 'Pendente', 'Cartão de Débito', '2024-01-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (128, 'FL10', '2024-01-12', 363.9, 'Cancelado', 'Pix', '2024-04-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (165, 'FL03', '2024-08-01', 453.25, 'Enviado', 'Pix', '2024-06-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (198, 'FL14', '2024-07-17', 242.45, 'Cancelado', 'Cartão de Crédito', '2024-06-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (159, 'FL05', '2024-12-17', 195.31, 'Enviado', 'Dinheiro', '2024-10-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (131, 'FL06', '2024-12-27', 468.39, 'Pendente', 'Cartão de Débito', '2024-05-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (38, 'FL18', '2024-04-09', 454.53, 'Enviado', 'Pix', '2024-03-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (200, 'FL18', '2024-03-23', 10.24, 'Cancelado', 'Cartão de Crédito', '2024-11-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (15, 'FL17', '2024-12-08', 185.94, 'Cancelado', 'Cartão de Débito', '2024-06-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (112, 'CF01', '2024-01-12', 132.61, 'Enviado', 'Dinheiro', '2024-08-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (2, 'FL02', '2024-07-02', 97.77, 'Pendente', 'Cartão de Débito', '2024-05-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (22, 'FL06', '2024-05-20', 174.55, 'Enviado', 'Pix', '2024-08-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (35, 'FL16', '2024-01-02', 66.88, 'Enviado', 'Cartão de Crédito', '2024-11-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (115, 'FL10', '2024-11-24', 245.32, 'Enviado', 'Cartão de Débito', '2024-03-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (103, 'FL19', '2024-06-28', 117.11, 'Cancelado', 'Cartão de Crédito', '2024-04-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (11, 'FL03', '2024-09-17', 116.26, 'Enviado', 'Cartão de Débito', '2024-01-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (148, 'FL11', '2024-07-20', 92.43, 'Pendente', 'Dinheiro', '2024-10-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (74, 'FL02', '2024-08-19', 60.43, 'Pendente', 'Pix', '2024-12-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (126, 'FL03', '2024-01-15', 424.54, 'Enviado', 'Pix', '2024-07-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (79, 'FL07', '2024-04-14', 319.12, 'Cancelado', 'Cartão de Débito', '2024-07-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (174, 'FL04', '2024-04-05', 125.03, 'Pendente', 'Pix', '2024-08-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (84, 'FL15', '2024-07-08', 378.91, 'Cancelado', 'Cartão de Crédito', '2024-08-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (6, 'FL16', '2024-07-03', 142.66, 'Enviado', 'Dinheiro', '2024-10-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (39, 'FL09', '2024-03-23', 438.24, 'Enviado', 'Cartão de Crédito', '2024-08-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (70, 'FL11', '2024-07-13', 313.9, 'Enviado', 'Cartão de Crédito', '2024-11-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (112, 'FL19', '2024-12-27', 107.43, 'Cancelado', 'Dinheiro', '2024-02-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (81, 'FL05', '2024-07-06', 200.26, 'Enviado', 'Cartão de Crédito', '2024-07-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (59, 'FL19', '2024-06-17', 302.5, 'Pendente', 'Cartão de Crédito', '2024-02-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (31, 'FL07', '2024-01-08', 183.58, 'Pendente', 'Cartão de Débito', '2024-01-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (47, 'FL05', '2024-05-15', 41.48, 'Cancelado', 'Cartão de Crédito', '2024-03-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (98, 'FL13', '2024-10-06', 111.34, 'Pendente', 'Cartão de Crédito', '2024-09-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (175, 'FL16', '2024-07-02', 391.23, 'Pendente', 'Dinheiro', '2024-02-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (21, 'FL02', '2024-08-06', 15.87, 'Pendente', 'Dinheiro', '2024-12-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (62, 'FL05', '2024-12-04', 363.11, 'Pendente', 'Cartão de Débito', '2024-08-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (111, 'FL20', '2024-10-18', 465.5, 'Cancelado', 'Cartão de Débito', '2024-12-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (126, 'FL18', '2024-01-26', 54.15, 'Enviado', 'Dinheiro', '2024-08-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'CF01', '2024-06-27', 398.35, 'Cancelado', 'Dinheiro', '2024-01-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (130, 'FL13', '2024-03-09', 275.11, 'Cancelado', 'Cartão de Crédito', '2024-10-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (147, 'FL16', '2024-11-12', 92.46, 'Pendente', 'Cartão de Débito', '2024-03-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (11, 'FL15', '2024-04-13', 29.58, 'Cancelado', 'Cartão de Débito', '2024-08-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (3, 'FL04', '2024-09-28', 65.06, 'Pendente', 'Cartão de Crédito', '2024-12-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (41, 'CF01', '2024-09-16', 497.42, 'Cancelado', 'Cartão de Crédito', '2024-01-01');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (200, 'FL09', '2024-06-19', 70.83, 'Pendente', 'Cartão de Crédito', '2024-04-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (21, 'FL12', '2024-09-22', 397.38, 'Cancelado', 'Cartão de Débito', '2024-10-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (30, 'FL18', '2024-01-18', 132.95, 'Pendente', 'Cartão de Crédito', '2024-09-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (170, 'FL09', '2024-08-26', 11.5, 'Pendente', 'Cartão de Crédito', '2024-06-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (171, 'FL06', '2024-12-16', 350.74, 'Enviado', 'Cartão de Débito', '2024-07-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (127, 'FL05', '2024-12-14', 308.11, 'Cancelado', 'Cartão de Débito', '2024-08-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (89, 'FL15', '2024-03-11', 163.08, 'Cancelado', 'Cartão de Crédito', '2024-12-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (120, 'FL03', '2024-03-06', 93.51, 'Enviado', 'Cartão de Débito', '2024-10-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (129, 'FL10', '2024-08-01', 282.26, 'Pendente', 'Cartão de Crédito', '2024-06-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (73, 'FL10', '2024-09-22', 233.51, 'Enviado', 'Cartão de Débito', '2024-05-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (126, 'FL06', '2024-05-02', 463.78, 'Enviado', 'Pix', '2024-01-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (171, 'FL07', '2024-06-20', 253.98, 'Enviado', 'Dinheiro', '2024-05-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (71, 'FL08', '2024-05-06', 67.38, 'Pendente', 'Dinheiro', '2024-10-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (62, 'FL14', '2024-10-25', 362.3, 'Cancelado', 'Dinheiro', '2024-10-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (97, 'FL01', '2024-08-15', 164.66, 'Pendente', 'Cartão de Débito', '2024-06-27');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (47, 'FL17', '2024-01-06', 316.77, 'Pendente', 'Pix', '2024-08-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (86, 'FL12', '2024-10-18', 154.19, 'Pendente', 'Cartão de Débito', '2024-04-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (45, 'FL20', '2024-07-02', 238.67, 'Cancelado', 'Cartão de Crédito', '2024-04-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (46, 'FL17', '2024-10-23', 230.99, 'Enviado', 'Cartão de Débito', '2024-12-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (7, 'FL04', '2024-03-16', 343.29, 'Pendente', 'Dinheiro', '2024-01-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (38, 'FL03', '2024-04-09', 352.45, 'Enviado', 'Dinheiro', '2024-08-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (79, 'FL03', '2024-04-26', 275.1, 'Enviado', 'Cartão de Débito', '2024-05-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (60, 'FL18', '2024-03-06', 418.57, 'Cancelado', 'Cartão de Débito', '2024-05-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (52, 'FL05', '2024-01-14', 286.68, 'Enviado', 'Dinheiro', '2024-10-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (118, 'FL07', '2024-03-22', 235.12, 'Pendente', 'Cartão de Crédito', '2024-04-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (175, 'FL02', '2024-11-04', 61.49, 'Cancelado', 'Dinheiro', '2024-08-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (69, 'FL01', '2024-01-05', 104.74, 'Pendente', 'Cartão de Crédito', '2024-09-08');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (169, 'FL01', '2024-07-01', 119.68, 'Pendente', 'Cartão de Crédito', '2024-01-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (18, 'FL18', '2024-08-20', 498.43, 'Enviado', 'Dinheiro', '2024-11-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (99, 'FL14', '2024-10-03', 10.05, 'Pendente', 'Dinheiro', '2024-12-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (149, 'FL14', '2024-05-01', 217.18, 'Enviado', 'Dinheiro', '2024-07-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (101, 'FL05', '2024-06-06', 238.04, 'Cancelado', 'Cartão de Débito', '2024-03-22');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (57, 'FL05', '2024-09-04', 460.93, 'Cancelado', 'Dinheiro', '2024-06-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (144, 'FL03', '2024-11-26', 384.04, 'Enviado', 'Cartão de Crédito', '2024-03-10');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (192, 'FL15', '2024-12-24', 159.4, 'Cancelado', 'Cartão de Débito', '2024-11-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (9, 'CF01', '2024-12-03', 235.86, 'Enviado', 'Pix', '2024-01-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (190, 'FL16', '2024-09-19', 234.31, 'Cancelado', 'Dinheiro', '2024-03-20');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (146, 'FL04', '2024-01-14', 23.52, 'Pendente', 'Cartão de Débito', '2024-09-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (145, 'FL13', '2024-02-15', 137.88, 'Enviado', 'Pix', '2024-05-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (141, 'FL08', '2024-07-06', 312.45, 'Enviado', 'Cartão de Crédito', '2024-09-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (94, 'FL11', '2024-08-06', 230.21, 'Enviado', 'Pix', '2024-06-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (30, 'FL16', '2024-02-21', 210.47, 'Enviado', 'Dinheiro', '2024-03-26');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (170, 'FL03', '2024-05-21', 233.75, 'Pendente', 'Cartão de Débito', '2024-02-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (6, 'FL12', '2024-09-03', 484.41, 'Enviado', 'Cartão de Crédito', '2024-09-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (188, 'FL16', '2024-11-08', 311.86, 'Enviado', 'Cartão de Crédito', '2024-08-09');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (16, 'FL03', '2024-07-16', 124.64, 'Enviado', 'Cartão de Débito', '2024-10-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (74, 'FL18', '2024-05-12', 355.75, 'Enviado', 'Cartão de Débito', '2024-01-28');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (104, 'FL03', '2024-08-09', 374.02, 'Pendente', 'Cartão de Débito', '2024-09-23');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (188, 'FL09', '2024-01-02', 66.07, 'Cancelado', 'Cartão de Débito', '2024-08-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (182, 'FL01', '2024-03-11', 468.53, 'Cancelado', 'Pix', '2024-12-11');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (112, 'FL14', '2024-02-14', 355.79, 'Enviado', 'Dinheiro', '2024-06-12');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (116, 'FL18', '2024-04-20', 459.38, 'Cancelado', 'Pix', '2024-10-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (2, 'FL02', '2024-03-18', 226.3, 'Pendente', 'Pix', '2024-12-07');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (24, 'FL14', '2024-04-28', 261.85, 'Cancelado', 'Dinheiro', '2024-08-18');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (64, 'FL04', '2024-08-11', 184.59, 'Pendente', 'Cartão de Débito', '2024-08-13');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (106, 'FL02', '2024-08-06', 146.86, 'Pendente', 'Cartão de Débito', '2024-09-04');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (32, 'FL10', '2024-06-24', 292.4, 'Cancelado', 'Pix', '2024-04-24');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (184, 'FL09', '2024-09-13', 422.16, 'Enviado', 'Dinheiro', '2024-04-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (138, 'FL19', '2024-03-03', 488.07, 'Pendente', 'Cartão de Débito', '2024-06-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (51, 'FL13', '2024-01-13', 358.13, 'Pendente', 'Pix', '2024-02-16');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (4, 'FL06', '2024-12-14', 192.1, 'Enviado', 'Pix', '2024-06-06');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (42, 'FL01', '2024-06-03', 437.28, 'Enviado', 'Cartão de Débito', '2024-06-21');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (11, 'FL01', '2024-12-02', 311.18, 'Cancelado', 'Cartão de Crédito', '2024-10-02');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (157, 'FL19', '2024-04-16', 63.78, 'Enviado', 'Pix', '2024-03-19');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (138, 'FL02', '2024-10-07', 113.09, 'Pendente', 'Dinheiro', '2024-11-05');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (121, 'FL16', '2024-02-16', 38.36, 'Cancelado', 'Cartão de Débito', '2024-04-17');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (3, 'FL11', '2024-11-09', 159.97, 'Pendente', 'Dinheiro', '2024-12-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (100, 'FL04', '2024-10-24', 70.46, 'Pendente', 'Pix', '2024-10-25');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (2, 'FL08', '2024-04-18', 329.72, 'Enviado', 'Cartão de Crédito', '2024-09-03');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (191, 'FL03', '2024-07-11', 454.13, 'Pendente', 'Pix', '2024-06-14');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (120, 'FL02', '2024-06-18', 110.73, 'Cancelado', 'Pix', '2024-11-15');
INSERT INTO Vendas (id_cliente, id_filial, data_da_compra, valor_total, status, forma_de_pagamento, data_do_envio) VALUES (101, 'FL02', '2024-01-16', 371.32, 'Enviado', 'Pix', '2024-10-16');


-- Tabela ItemVenda
CREATE TABLE ItemVenda (
    id_item_venda INT AUTO_INCREMENT PRIMARY KEY,
    id_venda INT,
    id_produto INT,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_venda) REFERENCES Vendas(id_venda),
    FOREIGN KEY (id_produto) REFERENCES Estoque(id_produto)
);

/*
Inserts ItemVenda
*/
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (196, 123, 3, 36.14);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (100, 68, 3, 25.75);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (277, 232, 6, 25.13);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (134, 36, 9, 23.27);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (187, 261, 10, 31.21);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (277, 68, 3, 5.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (67, 207, 6, 45.63);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (64, 220, 1, 42.72);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (323, 44, 6, 47.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (385, 130, 1, 18.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (89, 297, 2, 11.22);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (285, 33, 3, 30.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (42, 184, 5, 7.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (160, 283, 2, 43.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (73, 83, 8, 16.29);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (140, 123, 10, 10.28);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (50, 193, 7, 12.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (139, 4, 7, 46.11);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (269, 43, 2, 8.61);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (102, 140, 10, 26.78);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (358, 274, 4, 24.13);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (30, 248, 3, 28.89);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (468, 90, 6, 36.48);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (54, 43, 6, 6.03);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (292, 80, 7, 23.14);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (161, 172, 6, 8.76);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (27, 184, 7, 6.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (206, 222, 8, 16.54);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (380, 146, 3, 38.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (212, 91, 6, 19.93);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (335, 122, 4, 43.46);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (77, 240, 4, 31.36);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (248, 155, 1, 13.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (71, 181, 2, 28.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (161, 107, 5, 32.13);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (9, 195, 10, 19.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (438, 246, 8, 26.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (393, 290, 10, 48.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (387, 230, 7, 48.25);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (130, 130, 5, 8.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (306, 274, 5, 45.07);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (129, 215, 2, 22.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (320, 104, 7, 40.34);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (148, 227, 9, 14.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (90, 249, 6, 5.56);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (484, 190, 1, 20.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (102, 29, 10, 30.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (406, 93, 4, 19.5);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (489, 290, 6, 20.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (138, 13, 1, 18.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (368, 185, 8, 41.21);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (125, 177, 9, 24.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (339, 157, 4, 47.06);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (32, 199, 7, 32.9);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (395, 53, 4, 13.22);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (272, 215, 9, 13.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (378, 213, 2, 48.97);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (247, 247, 6, 19.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (356, 236, 4, 43.08);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (190, 85, 9, 18.09);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (107, 270, 5, 32.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (150, 152, 5, 21.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (15, 111, 9, 33.25);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (294, 225, 4, 24.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (173, 245, 9, 11.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (470, 217, 9, 47.17);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (380, 139, 1, 28.12);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (276, 19, 4, 8.36);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (379, 71, 9, 34.03);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (252, 193, 3, 17.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (163, 81, 4, 19.74);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (19, 168, 9, 30.6);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (42, 167, 8, 9.5);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (248, 280, 5, 36.18);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (82, 250, 5, 10.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (360, 153, 8, 23.04);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (5, 157, 4, 38.05);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (450, 6, 1, 39.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (222, 132, 7, 29.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (50, 206, 9, 45.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (82, 222, 8, 24.66);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (472, 240, 6, 49.27);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (139, 73, 4, 46.85);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (480, 273, 2, 40.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (482, 272, 5, 46.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (426, 275, 7, 5.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (21, 121, 7, 20.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (441, 24, 10, 19.9);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (219, 196, 2, 31.62);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (458, 221, 9, 46.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (206, 91, 10, 32.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (129, 114, 10, 18.1);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (447, 39, 7, 38.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (96, 272, 8, 9.27);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (228, 199, 6, 9.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (195, 51, 8, 36.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (411, 292, 4, 28.96);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (140, 82, 6, 8.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (365, 135, 1, 39.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (129, 24, 1, 23.08);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (322, 246, 6, 30.39);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (443, 41, 2, 36.14);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (289, 52, 7, 35.3);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (447, 88, 9, 20.24);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (8, 229, 4, 19.11);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (49, 43, 5, 39.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (80, 116, 4, 34.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (462, 121, 9, 12.17);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (423, 278, 5, 48.63);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (15, 251, 8, 5.12);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (24, 216, 1, 45.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (44, 145, 7, 46.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (448, 192, 6, 38.3);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (267, 14, 3, 23.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (316, 249, 5, 28.34);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (137, 296, 6, 21.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (162, 36, 2, 26.85);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (208, 141, 5, 40.9);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (392, 19, 6, 31.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (54, 96, 10, 34.76);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (494, 45, 3, 15.38);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (440, 17, 2, 8.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (376, 245, 2, 48.6);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (137, 22, 8, 24.28);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (478, 64, 5, 36.38);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (80, 286, 8, 35.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (336, 82, 9, 40.16);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (489, 219, 1, 39.3);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (439, 116, 5, 40.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (186, 209, 6, 41.49);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (113, 254, 9, 12.71);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (349, 255, 2, 31.65);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (439, 150, 4, 17.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (328, 284, 1, 39.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (116, 156, 1, 46.93);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (215, 57, 2, 29.23);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (474, 68, 4, 35.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (493, 222, 3, 28.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (170, 259, 3, 37.67);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (384, 161, 8, 40.75);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (301, 88, 6, 17.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (391, 41, 10, 22.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (135, 38, 2, 13.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (67, 10, 10, 36.92);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (327, 87, 3, 38.75);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (451, 1, 5, 44.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (140, 22, 7, 39.92);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (498, 61, 6, 11.49);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (88, 174, 3, 38.07);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (259, 39, 3, 32.75);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (476, 71, 1, 11.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (123, 197, 3, 22.61);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (241, 33, 5, 47.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (256, 49, 7, 26.67);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (343, 109, 6, 35.74);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (458, 258, 10, 29.69);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (302, 135, 7, 29.66);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (45, 47, 10, 45.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (4, 25, 3, 36.95);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (213, 99, 10, 31.1);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (457, 178, 3, 30.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (260, 212, 6, 40.49);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (122, 148, 8, 46.87);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (347, 228, 1, 17.75);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (463, 145, 10, 26.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (44, 177, 2, 17.1);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (92, 2, 4, 8.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (146, 259, 9, 33.29);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (152, 15, 2, 7.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (263, 221, 5, 8.8);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (98, 13, 8, 7.72);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (441, 214, 3, 12.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (54, 111, 5, 11.77);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (16, 34, 4, 20.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (184, 279, 9, 40.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (455, 55, 1, 15.13);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (363, 29, 3, 18.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (463, 213, 5, 29.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (201, 193, 9, 44.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (491, 195, 7, 8.6);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (16, 91, 3, 31.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (319, 45, 8, 18.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (149, 184, 7, 40.23);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (160, 246, 9, 30.09);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (384, 85, 4, 46.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (268, 66, 9, 10.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (269, 6, 4, 20.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (116, 159, 1, 6.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (142, 234, 3, 30.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (272, 183, 5, 18.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (332, 278, 1, 31.52);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (104, 43, 10, 49.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (118, 37, 5, 27.03);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (457, 111, 6, 14.61);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (137, 208, 2, 45.63);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (148, 135, 2, 40.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (341, 2, 5, 25.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (449, 285, 10, 25.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (203, 211, 5, 38.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (465, 125, 9, 11.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (260, 221, 10, 14.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (208, 233, 2, 42.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (112, 3, 4, 35.88);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (435, 126, 8, 6.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (428, 218, 3, 6.42);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (54, 242, 5, 36.66);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (1, 57, 9, 36.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (96, 3, 5, 11.95);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (272, 287, 9, 25.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (468, 188, 5, 12.56);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (342, 101, 4, 49.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (415, 20, 7, 18.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (467, 116, 1, 22.84);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (143, 86, 10, 41.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (204, 188, 8, 24.92);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (5, 142, 9, 20.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (227, 163, 4, 9.65);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (96, 188, 9, 40.52);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (7, 56, 9, 15.71);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (213, 210, 6, 48.43);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (121, 19, 6, 35.46);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (153, 91, 4, 21.77);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (52, 25, 5, 7.24);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (103, 84, 6, 41.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (227, 86, 5, 46.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (6, 44, 7, 43.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (219, 293, 6, 27.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (358, 240, 4, 37.63);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (260, 263, 6, 20.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (400, 46, 2, 22.8);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (410, 278, 5, 22.36);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (183, 200, 2, 43.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (402, 96, 7, 7.69);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (60, 63, 3, 48.04);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (70, 81, 3, 33.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (289, 265, 1, 8.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (340, 9, 4, 32.89);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (294, 194, 5, 19.23);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (194, 124, 9, 9.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (287, 239, 1, 26.93);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (388, 155, 2, 48.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (381, 143, 3, 7.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (181, 224, 10, 12.24);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (42, 260, 5, 29.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (456, 219, 10, 33.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (412, 69, 2, 32.83);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (349, 77, 5, 26.84);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (497, 204, 2, 40.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (48, 274, 6, 34.24);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (61, 48, 3, 14.93);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (41, 230, 2, 9.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (395, 240, 10, 27.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (224, 145, 10, 48.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (265, 96, 3, 42.43);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (20, 48, 5, 37.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (141, 261, 2, 31.43);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (321, 67, 2, 13.88);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (136, 292, 4, 32.88);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (154, 157, 2, 20.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (300, 184, 7, 40.03);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (104, 212, 8, 33.62);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (309, 178, 7, 48.02);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (273, 164, 1, 13.49);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (232, 222, 10, 36.5);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (491, 72, 10, 12.03);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (351, 154, 6, 7.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (340, 28, 1, 30.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (419, 102, 1, 33.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (389, 116, 7, 49.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (461, 210, 10, 30.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (102, 104, 5, 32.27);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (127, 155, 6, 34.62);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (259, 229, 1, 17.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (19, 208, 4, 41.9);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (34, 57, 9, 45.12);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (88, 296, 7, 43.41);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (97, 11, 3, 36.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (71, 231, 3, 13.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (469, 29, 1, 48.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (439, 138, 3, 7.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (110, 182, 3, 31.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (413, 223, 2, 19.34);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (368, 77, 8, 31.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (105, 129, 6, 6.0);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (367, 103, 2, 29.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (430, 145, 4, 18.87);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (53, 95, 3, 32.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (130, 146, 2, 12.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (192, 67, 8, 19.69);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (104, 265, 6, 28.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (94, 2, 10, 21.76);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (127, 294, 3, 36.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (319, 176, 7, 46.66);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (15, 193, 10, 16.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (23, 176, 8, 7.31);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (385, 123, 4, 45.56);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (440, 189, 6, 41.11);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (444, 218, 6, 47.71);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (159, 18, 4, 35.3);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (295, 195, 10, 48.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (330, 234, 3, 32.5);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (489, 1, 10, 24.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (207, 283, 2, 33.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (368, 108, 6, 7.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (115, 75, 10, 34.33);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (55, 245, 1, 21.54);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (480, 219, 4, 39.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (241, 106, 5, 49.89);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (288, 198, 8, 43.61);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (19, 235, 6, 41.58);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (378, 255, 10, 5.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (94, 217, 10, 31.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (30, 105, 10, 28.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (65, 279, 7, 47.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (266, 207, 1, 43.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (134, 288, 4, 21.03);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (182, 145, 6, 24.29);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (373, 84, 2, 43.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (285, 143, 4, 23.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (255, 247, 9, 44.02);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (444, 9, 8, 46.9);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (485, 117, 1, 6.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (407, 90, 9, 11.06);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (115, 246, 6, 26.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (301, 220, 9, 31.8);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (318, 110, 8, 37.52);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (431, 156, 8, 20.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (433, 272, 7, 10.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (495, 226, 9, 32.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (362, 183, 7, 41.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (373, 57, 9, 14.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (399, 59, 8, 8.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (431, 189, 4, 28.02);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (172, 27, 10, 24.68);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (487, 71, 10, 12.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (490, 142, 2, 22.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (238, 22, 5, 21.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (97, 79, 2, 48.48);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (261, 66, 5, 47.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (479, 68, 10, 15.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (95, 75, 8, 26.07);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (266, 36, 8, 42.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (339, 55, 7, 44.34);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (422, 255, 2, 38.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (337, 213, 6, 35.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (449, 242, 6, 10.76);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (245, 189, 2, 7.22);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (358, 259, 6, 26.18);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (164, 113, 7, 25.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (425, 107, 6, 11.95);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (420, 243, 10, 12.39);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (198, 79, 4, 40.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (461, 224, 9, 38.3);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (252, 59, 5, 20.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (463, 94, 10, 9.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (204, 118, 4, 8.67);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (103, 134, 6, 26.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (236, 190, 10, 33.89);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (494, 155, 8, 38.3);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (268, 173, 8, 46.87);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (221, 191, 3, 18.86);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (320, 38, 1, 18.98);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (46, 138, 10, 23.48);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (170, 190, 2, 34.71);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (106, 169, 8, 22.2);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (481, 195, 9, 37.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (432, 246, 8, 24.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (123, 12, 7, 10.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (317, 246, 10, 46.13);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (498, 46, 1, 46.56);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (411, 47, 2, 12.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (304, 151, 9, 15.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (197, 212, 3, 8.02);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (227, 4, 6, 28.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (388, 127, 1, 37.52);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (454, 75, 3, 21.46);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (144, 261, 4, 32.38);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (310, 270, 8, 47.39);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (440, 157, 3, 9.69);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (390, 297, 8, 25.17);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (81, 44, 9, 41.59);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (389, 3, 1, 43.19);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (389, 107, 5, 34.11);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (378, 134, 1, 38.23);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (172, 102, 2, 30.77);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (361, 101, 2, 40.33);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (184, 256, 6, 27.97);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (95, 69, 3, 44.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (158, 106, 6, 13.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (366, 186, 9, 24.63);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (148, 62, 6, 13.78);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (182, 54, 5, 17.33);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (437, 257, 1, 30.98);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (342, 89, 8, 25.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (72, 273, 4, 45.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (259, 55, 7, 48.65);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (126, 29, 3, 9.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (305, 251, 2, 7.72);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (417, 260, 5, 13.94);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (86, 268, 9, 16.27);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (61, 286, 5, 44.08);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (87, 176, 5, 8.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (86, 269, 2, 15.9);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (469, 93, 8, 18.08);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (270, 66, 8, 37.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (38, 294, 9, 15.1);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (374, 48, 6, 37.38);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (58, 195, 9, 26.41);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (398, 100, 10, 44.27);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (122, 243, 6, 35.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (42, 191, 6, 45.48);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (293, 212, 8, 9.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (121, 247, 8, 28.66);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (348, 216, 8, 12.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (76, 143, 8, 37.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (283, 262, 6, 42.52);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (118, 247, 4, 23.55);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (267, 250, 4, 28.09);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (143, 39, 3, 25.26);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (75, 97, 10, 45.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (211, 6, 3, 31.72);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (436, 3, 8, 36.8);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (372, 286, 4, 34.07);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (181, 203, 1, 7.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (409, 152, 10, 45.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (337, 130, 2, 23.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (386, 17, 8, 7.05);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (77, 51, 1, 40.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (9, 104, 6, 11.95);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (139, 60, 9, 33.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (81, 25, 4, 43.76);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (100, 227, 8, 35.18);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (480, 1, 4, 47.8);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (115, 258, 7, 13.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (143, 68, 3, 12.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (259, 16, 2, 23.56);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (437, 30, 7, 49.82);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (31, 100, 3, 45.81);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (459, 111, 6, 10.91);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (365, 25, 2, 49.07);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (314, 203, 7, 19.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (269, 191, 8, 28.02);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (310, 120, 5, 17.47);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (494, 174, 2, 7.17);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (370, 251, 10, 11.51);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (58, 292, 4, 16.41);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (288, 175, 4, 15.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (483, 246, 3, 12.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (321, 28, 1, 13.76);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (73, 19, 5, 21.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (349, 169, 5, 20.85);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (479, 247, 4, 25.6);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (166, 98, 3, 30.22);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (366, 43, 8, 11.85);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (207, 163, 6, 10.57);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (213, 22, 3, 6.46);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (147, 224, 3, 31.4);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (369, 15, 6, 20.64);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (455, 52, 3, 40.49);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (201, 62, 3, 19.43);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (418, 136, 10, 24.62);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (361, 125, 3, 49.96);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (489, 212, 2, 26.88);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (93, 219, 8, 8.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (66, 229, 9, 16.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (8, 232, 8, 40.07);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (208, 107, 10, 11.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (437, 275, 5, 44.48);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (482, 2, 3, 13.04);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (29, 207, 1, 45.32);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (371, 287, 1, 18.49);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (253, 96, 8, 20.85);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (462, 101, 9, 9.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (20, 11, 2, 19.79);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (195, 213, 10, 7.13);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (301, 97, 5, 43.69);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (466, 94, 7, 42.71);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (26, 139, 9, 44.71);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (46, 109, 8, 21.35);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (207, 71, 10, 16.53);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (136, 106, 5, 40.25);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (117, 115, 1, 40.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (115, 116, 9, 6.93);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (212, 126, 5, 11.7);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (324, 201, 9, 5.41);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (55, 33, 4, 30.44);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (440, 251, 10, 38.16);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (449, 254, 10, 46.77);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (330, 18, 9, 49.15);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (498, 168, 10, 11.06);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (181, 116, 2, 11.37);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (235, 282, 10, 21.73);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (252, 88, 9, 9.16);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (137, 38, 4, 20.45);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (453, 88, 6, 26.52);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (54, 285, 5, 39.99);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (170, 107, 9, 40.34);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (218, 287, 8, 28.33);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (186, 178, 3, 13.01);
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario) VALUES (185, 294, 4, 45.87);


-- -----------------------------------------------------
-- INSERÇÃO DE DADOS
-- -----------------------------------------------------

-- Insere 20 Filiais
INSERT INTO Filial (id_filial, nome, endereco, telefone, cep, cnpj, bairro, estado, municipio, quantidade_de_funcionarios, clientes_por_dia, email, pais) VALUES
('CF01', 'Empresa Chefe', 'Av. Paulista, 1000', '1133334444', '01310-100', '01.234.567/0001-89', 'Bela Vista', 'SP', 'São Paulo', 50, 100, 'matriz@email.com', 'Brasil');

INSERT INTO Filial (id_filial, nome, endereco, telefone, cep, cnpj, bairro, estado, municipio, quantidade_de_funcionarios, clientes_por_dia, email, pais)
SELECT
    CONCAT('FL', LPAD(T.n, 2, '0')),
    CONCAT('Filial ', LPAD(T.n, 2, '0')),
    CASE WHEN RAND() > 0.5 THEN 'Rua dos Chocolates, 10' ELSE 'Chocolate Ave, 500' END,
    CASE WHEN RAND() > 0.5 THEN '119' ELSE '613' END,
    CASE WHEN RAND() > 0.5 THEN '01000-000' ELSE 'M4W 1W2' END,
    CASE WHEN RAND() > 0.5 THEN '01.234.567/0001-89' ELSE '99.887.765/0001-23' END,
    CASE WHEN RAND() > 0.5 THEN 'Centro' ELSE 'Downtown' END,
    CASE WHEN RAND() > 0.5 THEN 'SP' ELSE 'ON' END,
    CASE WHEN RAND() > 0.5 THEN 'São Paulo' ELSE 'Toronto' END,
    FLOOR(RAND() * 20) + 10,
    FLOOR(RAND() * 200) + 50,
    CONCAT('filial', LPAD(T.n, 2, '0'), '@email.com'),
    CASE WHEN RAND() > 0.5 THEN 'Brasil' ELSE 'Canadá' END
FROM (SELECT a.n + b.n * 10 AS n FROM 
      (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
              SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a,
      (SELECT 0 AS n UNION ALL SELECT 1) b) AS T
WHERE T.n BETWEEN 1 AND 20;

/* -- Insere 200 Clientes
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais)
SELECT
    NULL,
    F.id_filial,
    CONCAT('Cliente ', T.n),
    CONCAT('119', FLOOR(RAND() * 90000000) + 10000000),
    CONCAT('cliente', T.n, '@email.com'),
    CONCAT(FLOOR(RAND() * 999), '.', FLOOR(RAND() * 999), '.', FLOOR(RAND() * 999), '-', FLOOR(RAND() * 99)),
    CONCAT(FLOOR(RAND() * 99), '.', FLOOR(RAND() * 999), '.', FLOOR(RAND() * 999)),
    CURDATE() - INTERVAL FLOOR(RAND() * 20000) DAY,
    FLOOR(RAND() * 40) + 20,
    'Rua das Rosas, 456',
    CONCAT(FLOOR(RAND() * 99999), '-', FLOOR(RAND() * 999)),
    'Jardim da Gloria',
    'SP',
    'São Paulo',
    'Brasil'
FROM Filial F
JOIN (SELECT a.n + b.n * 10 AS n 
      FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
                   SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, 
           (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
                   SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b) AS T
WHERE T.n BETWEEN 1 AND 200
ORDER BY RAND();
*/

INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Michelle Yang', '99123380302', 'michelle.yang@email.com', '277.279.440-89', '61.213.744', '1970-06-08', 55, '2448 Melvin Junction', '47980-338', 'Centro', 'DE', 'Fisherland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Justin Stein', '79507681946', 'justin.stein@email.com', '667.229.680-83', '28.364.185', '1984-03-24', 41, '9266 Dave Manor', '38301-637', 'Centro', 'AZ', 'Lake Austin', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Juan Carlos Nadia Mares', '48364850473', 'juan.carlos.nadia.mares@email.com', '110.580.798-52', '86.474.284', '1994-11-26', 31, 'Callejón Cazares 226 777', '66912-868', 'Centro', 'HGO', 'San Natalia los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Laura Sisneros', '61213984271', 'laura.sisneros@email.com', '969.313.171-65', '29.125.660', '2006-09-01', 19, 'Circuito Domínguez 761 Interior 698', '72033-631', 'Centro', 'MOR', 'San Eva de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Leonor Pareja Ramírez', '38284635656', 'leonor.pareja.ramírez@email.com', '919.416.311-86', '91.563.656', '1955-09-22', 70, 'C. de Rita Vera 98', '63192-464', 'Centro', 'SP', 'Valladolid', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Trinidad Batalla Torrecilla', '67127035906', 'trinidad.batalla.torrecilla@email.com', '151.195.187-43', '36.938.715', '2006-02-25', 19, 'Cañada de Manola Porta 2', '75711-244', 'Centro', 'SP', 'Ávila', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Julia Ford', '48351820757', 'julia.ford@email.com', '277.241.895-44', '17.956.161', '2001-10-21', 24, '9216 Love Hills Suite 143', '79379-370', 'Centro', 'VT', 'South Carolynland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Ana Carolina Azevedo', '55849843402', 'ana.carolina.azevedo@email.com', '225.924.120-18', '95.379.709', '1993-09-25', 32, 'Distrito de da Costa, 48', '16695-378', 'Centro', 'RO', 'Novaes', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Kevin Walsh', '04441142372', 'kevin.walsh@email.com', '198.237.617-48', '80.808.761', '1957-07-15', 68, '255 Day Vista', '19641-808', 'Centro', 'SP', 'Morganland', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Letícia da Mata', '55219303681', 'letícia.da.mata@email.com', '666.330.518-17', '25.876.803', '2001-12-22', 24, 'Setor de Monteiro, 2', '59690-479', 'Centro', 'PA', 'Costa da Mata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Monica Barrett', '59295948410', 'monica.barrett@email.com', '440.423.691-99', '24.818.506', '1987-12-30', 38, '1491 Michelle Burgs', '80645-218', 'Centro', 'SP', 'Triciaville', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Patricia Case', '73220693499', 'patricia.case@email.com', '720.615.897-93', '55.925.370', '1967-01-01', 58, '27282 Zachary Plaza Suite 646', '18109-966', 'Centro', 'SP', 'South Amber', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'James West', '83838780002', 'james.west@email.com', '913.881.929-25', '40.352.273', '1958-04-21', 67, '9655 Leslie Islands', '70372-682', 'Centro', 'SP', 'Sotoport', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Calebe Vieira', '55419906380', 'calebe.vieira@email.com', '705.745.552-72', '72.737.633', '1988-04-16', 37, 'Favela de da Rocha', '79250-380', 'Centro', 'CE', 'Araújo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Stacy Brown', '99407029740', 'stacy.brown@email.com', '898.959.751-68', '72.261.730', '1961-10-06', 64, '27069 Kathy Mountain Apt. 081', '67320-837', 'Centro', 'ND', 'Stevenville', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Mr. Nicholas Jackson', '77308918350', 'mr..nicholas.jackson@email.com', '839.147.737-42', '64.515.212', '1988-05-26', 37, '18570 Johnston Mountains', '72971-455', 'Centro', 'SP', 'West Tonyaberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Victorino Guardia', '83718742283', 'victorino.guardia@email.com', '997.379.338-17', '74.203.634', '1998-12-24', 27, 'Alameda de Clemente Ortiz 40 Apt. 50 ', '23201-914', 'Centro', 'SP', 'Castellón', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Letícia Moraes', '55619680246', 'letícia.moraes@email.com', '456.654.297-71', '85.944.700', '1965-08-25', 60, 'Parque de Lima, 16', '28665-549', 'Centro', 'RO', 'Costa', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Amando Cobo-Blanch', '90901823631', 'amando.cobo-blanch@email.com', '445.178.137-65', '48.165.608', '2000-07-20', 25, 'Via Adelardo Mesa 37 Piso 6 ', '84899-805', 'Centro', 'SP', 'Guipúzcoa', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Ing. Iván Pérez', '48203462168', 'ing..iván.pérez@email.com', '767.661.530-19', '76.680.838', '1985-05-12', 40, 'Peatonal Sur Apodaca 061 687', '67404-851', 'Centro', 'BC', 'San Diana de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Jennifer Lewis', '48466443639', 'jennifer.lewis@email.com', '652.774.722-83', '83.882.816', '2001-07-07', 24, '12803 Hebert Pines Suite 728', '22483-631', 'Centro', 'SP', 'Katherineland', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Michelle Lester', '43192626394', 'michelle.lester@email.com', '945.779.637-88', '50.316.235', '1998-02-22', 27, '7858 Small Shoals Suite 691', '70932-170', 'Centro', 'LA', 'Wilsonview', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Russell Alvarado', '74364387206', 'russell.alvarado@email.com', '385.448.440-36', '47.627.657', '2002-08-17', 23, '38891 Joshua Skyway', '44084-234', 'Centro', 'SP', 'Danielshire', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Frank Copeland', '89953719299', 'frank.copeland@email.com', '922.876.499-24', '81.590.202', '1991-10-03', 34, '61669 Johnston Heights Apt. 469', '46687-633', 'Centro', 'SP', 'Moranberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Eloy Benjamín Puga Meléndez', '84463998492', 'eloy.benjamín.puga.meléndez@email.com', '285.895.487-18', '15.932.651', '2001-05-07', 24, 'Pasaje Cisneros 267 Interior 733', '28841-289', 'Centro', 'DGO', 'San Marcela de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Jacobo Gabriel Corona', '80244371775', 'jacobo.gabriel.corona@email.com', '833.346.795-97', '94.910.345', '1975-01-16', 50, 'Periférico Nuevo León 070 Interior 573', '45295-721', 'Centro', 'ZAC', 'San Adela de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Ani de Morell', '01842192437', 'ani.de.morell@email.com', '359.518.521-36', '24.540.351', '1967-07-25', 58, 'Vial Reynaldo Mur 86 Apt. 61 ', '36045-152', 'Centro', 'SP', 'Asturias', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Christopher Howard', '81864444363', 'christopher.howard@email.com', '206.185.141-67', '18.270.348', '1993-04-27', 32, '81585 Jefferson Court Apt. 628', '76847-843', 'Centro', 'SP', 'Port Amyport', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Jaime Brown', '01050217732', 'jaime.brown@email.com', '978.449.686-21', '95.745.801', '1972-06-08', 53, '6720 Andrew Island', '85968-651', 'Centro', 'DE', 'South Adrienne', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Joseph Porter', '16691584538', 'joseph.porter@email.com', '655.308.354-76', '91.652.565', '1964-02-14', 61, '97408 Caldwell Tunnel Apt. 719', '61141-419', 'Centro', 'SP', 'North Carlosland', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Erick Almeida', '55219966843', 'erick.almeida@email.com', '465.238.494-69', '37.270.210', '1971-04-18', 54, 'Viela Moraes, 91', '66209-549', 'Centro', 'PB', 'Moura', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Suzanne Green', '00048329942', 'suzanne.green@email.com', '550.266.747-10', '12.318.173', '1964-10-03', 61, '05878 Fox Union Apt. 194', '83799-649', 'Centro', 'AZ', 'Brownhaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Janet Green', '42949027021', 'janet.green@email.com', '198.534.409-82', '26.275.637', '1978-02-25', 47, '98020 Delgado Path', '95609-820', 'Centro', 'SP', 'Lake Mike', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Sr. Diego Porto', '55219117754', 'sr..diego.porto@email.com', '311.490.594-26', '63.250.337', '2001-11-24', 24, 'Setor de Lopes, 82', '61222-998', 'Centro', 'GO', 'Duarte', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Sra. Ana Beatriz Rezende', '55319420951', 'sra..ana.beatriz.rezende@email.com', '666.924.173-79', '63.408.793', '1963-04-18', 62, 'Condomínio Pedro Henrique Nogueira, 94', '39676-695', 'Centro', 'AC', 'Lima da Prata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Timothy Schaefer', '62271025840', 'timothy.schaefer@email.com', '540.613.657-40', '12.543.578', '1971-08-27', 54, '80719 Jose Plains Suite 167', '85152-493', 'Centro', 'SP', 'Port Amandamouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Esther Bétancourt Castañeda', '66457593917', 'esther.bétancourt.castaneda@email.com', '862.839.829-38', '69.879.819', '1971-01-14', 54, 'Calzada Meraz 527 Edif. 275 , Depto. 068', '24792-515', 'Centro', 'COAH', 'Nueva Bolivia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Jesse Smith', '36477284737', 'jesse.smith@email.com', '688.671.890-66', '72.188.740', '1999-04-03', 26, '1833 Welch View Apt. 699', '86299-510', 'Centro', 'KS', 'Ashleyhaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Michael Roberts', '82792187909', 'michael.roberts@email.com', '781.275.172-33', '94.599.323', '1957-08-23', 68, '8073 Victoria Hill', '32675-138', 'Centro', 'SP', 'Summerton', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Esther Teixeira', '55219846825', 'esther.teixeira@email.com', '935.853.836-43', '47.435.692', '1990-02-18', 35, 'Vale de Azevedo, 45', '98020-740', 'Centro', 'PI', 'da Luz', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Alicia Longoria Benavídez', '12885312123', 'alicia.longoria.benavídez@email.com', '816.242.474-35', '85.255.356', '1990-09-24', 35, 'Circunvalación Yucatán 127 878', '11911-503', 'Centro', 'SLP', 'Vieja Tonga', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Cecilia Norma Colón Téllez', '53866507544', 'cecilia.norma.colón.téllez@email.com', '669.165.299-30', '47.412.764', '1977-04-07', 48, 'Callejón Marruecos 954 Edif. 272 , Depto. 423', '85865-313', 'Centro', 'COAH', 'Nueva Mongolia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Brian Best', '56350066121', 'brian.best@email.com', '411.991.382-64', '17.873.351', '1993-01-25', 32, '99743 David Mill', '69520-568', 'Centro', 'NJ', 'South Patriciabury', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Rebeca Boada Rius', '36870958907', 'rebeca.boada.rius@email.com', '983.914.811-70', '24.837.169', '1978-10-04', 47, 'Cañada de Artemio Gisbert 35 Puerta 2 ', '23984-597', 'Centro', 'SP', 'Huelva', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Bryan Terrell', '11570243896', 'bryan.terrell@email.com', '357.378.594-62', '66.489.342', '1997-09-04', 28, '6341 Brandy River', '85151-169', 'Centro', 'WY', 'Davisbury', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Anthony Weeks', '35446014949', 'anthony.weeks@email.com', '439.258.583-80', '89.766.652', '1960-05-29', 65, '052 Cindy Ridge', '12872-768', 'Centro', 'SP', 'West Shawn', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Ángela Jos Lozano Palacios', '53043873779', 'ángela.jos.lozano.palacios@email.com', '548.622.251-42', '85.966.828', '1975-05-19', 50, 'Boulevard Liechtenstein 329 Interior 280', '36234-608', 'Centro', 'SON', 'San María los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Yesenia Leonard', '82225663807', 'yesenia.leonard@email.com', '924.581.396-73', '51.539.871', '1982-03-26', 43, '6987 Baker Bypass', '20294-846', 'Centro', 'TX', 'Port Cassie', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Joana Freitas', '55519527784', 'joana.freitas@email.com', '608.805.164-19', '81.402.138', '1955-03-30', 70, 'Largo de Nascimento, 972', '65476-100', 'Centro', 'PE', 'Porto', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Dr. Murilo Lima', '55619422495', 'dr..murilo.lima@email.com', '305.243.708-16', '14.636.603', '1992-01-19', 33, 'Favela de da Mota, 68', '80726-132', 'Centro', 'GO', 'Lima', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Jon Delgado', '11250504081', 'jon.delgado@email.com', '830.384.398-27', '37.701.608', '1981-08-16', 44, '5104 Clark Rue Apt. 540', '11835-905', 'Centro', 'CO', 'Jesseview', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Brenda Murphy', '02530992890', 'brenda.murphy@email.com', '875.594.680-60', '33.924.396', '1980-03-28', 45, '70826 Carlson Knoll Suite 218', '62534-595', 'Centro', 'ME', 'Williamsonmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Abel Reig Tur', '17315606101', 'abel.reig.tur@email.com', '894.355.152-83', '36.392.504', '1971-02-07', 54, 'Vial de Pía Berenguer 63 Puerta 6 ', '86135-560', 'Centro', 'SP', 'Sevilla', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Lorena Alves', '55819026390', 'lorena.alves@email.com', '858.191.879-33', '52.478.903', '1998-06-12', 27, 'Avenida Teixeira, 461', '79615-310', 'Centro', 'TO', 'Araújo da Prata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Amada Tamayo Aranda', '53237397404', 'amada.tamayo.aranda@email.com', '284.212.611-82', '98.636.184', '1997-06-12', 28, 'Cuesta de Sebastián Luz 93 Apt. 53 ', '68721-949', 'Centro', 'SP', 'La Rioja', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Patricia Wilson', '06681498152', 'patricia.wilson@email.com', '544.350.439-56', '24.819.472', '2004-12-03', 21, '211 Blake Court', '74525-496', 'Centro', 'SP', 'East Stephaniebury', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Anthony Cardoso', '55119550263', 'anthony.cardoso@email.com', '109.429.772-26', '87.762.781', '1958-06-12', 67, 'Favela Levi Oliveira', '84380-213', 'Centro', 'SP', 'Teixeira do Galho', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Espartaco Orta Villalpando', '41822808352', 'espartaco.orta.villalpando@email.com', '841.290.133-67', '85.291.414', '1970-11-06', 55, 'Corredor Santa Lucía 290 Interior 837', '26714-413', 'Centro', 'OAX', 'Vieja China', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Balduino Riquelme', '14536730990', 'balduino.riquelme@email.com', '529.688.857-78', '72.415.269', '1977-07-06', 48, 'Plaza de Leandra Pardo 4', '42723-109', 'Centro', 'SP', 'Granada', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Trinidad Aragón-Amador', '61220374347', 'trinidad.aragón-amador@email.com', '691.164.734-97', '48.602.400', '2007-08-11', 18, 'Vial Consuelo Guillen 77 Piso 1 ', '15918-595', 'Centro', 'SP', 'Palencia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Eric Smith', '04652484743', 'eric.smith@email.com', '933.754.727-78', '36.334.247', '1959-06-04', 66, '670 Michael Shores', '10320-747', 'Centro', 'SP', 'Thomasfurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Daniel Salazar', '22830678264', 'daniel.salazar@email.com', '393.198.574-62', '34.633.146', '1979-12-20', 46, '06803 Rhodes Path Apt. 091', '54753-782', 'Centro', 'SP', 'Mcneilburgh', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Carolyn Wade', '40480386267', 'carolyn.wade@email.com', '973.373.326-15', '36.944.605', '1988-10-29', 37, '60821 Nicholas Mountains Suite 304', '62381-235', 'Centro', 'SP', 'New Manuelberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Jessica Brown', '68784216020', 'jessica.brown@email.com', '450.364.939-97', '17.104.468', '1985-08-02', 40, '805 James Neck Suite 733', '99416-936', 'Centro', 'SP', 'South David', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Thomas Ferguson', '42798288186', 'thomas.ferguson@email.com', '890.746.861-59', '65.154.170', '1981-02-22', 44, '385 Davis Estates Suite 757', '51304-110', 'Centro', 'WV', 'Frazierstad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Alfonso Pelayo Paredes', '63154641716', 'alfonso.pelayo.paredes@email.com', '888.105.553-94', '21.717.105', '1984-01-15', 41, 'Avenida Sur Calvillo 405 Interior 610', '68938-758', 'Centro', 'YUC', 'Vieja Jordania', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Débora Eugenia Valadez Contreras', '20694314329', 'débora.eugenia.valadez.contreras@email.com', '819.961.572-66', '49.636.879', '1987-11-20', 38, 'Calle Roybal 430 693', '56678-642', 'Centro', 'OAX', 'Vieja Colombia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Theo Oliveira', '55619392822', 'theo.oliveira@email.com', '743.726.832-93', '21.430.602', '2006-12-29', 19, 'Parque Castro', '11952-487', 'Centro', 'PI', 'da Cruz', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Mar Zapata', '39840475820', 'mar.zapata@email.com', '806.240.646-20', '36.246.916', '2005-10-12', 20, 'C. de Isidoro Pedro 370 Puerta 8 ', '65534-382', 'Centro', 'SP', 'Santa Cruz de Tenerife', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Hermelinda Violeta Valladares Pabón', '21000201846', 'hermelinda.violeta.valladares.pabón@email.com', '794.573.913-86', '99.349.863', '1973-11-14', 52, 'Callejón Báez 395 219', '85890-295', 'Centro', 'MOR', 'San Verónica de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Martirio de Sala', '07856421192', 'martirio.de.sala@email.com', '844.716.608-56', '59.729.336', '1972-04-27', 53, 'Avenida de Ceferino Villena 84 Piso 4 ', '60871-780', 'Centro', 'SP', 'Guadalajara', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Juan Carlos Medina', '53211655762', 'juan.carlos.medina@email.com', '990.545.216-12', '61.347.732', '1969-12-26', 56, 'Boulevard Norte Acosta 347 496', '91540-496', 'Centro', 'VER', 'San Beatriz los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Joseph Roberts', '40996432256', 'joseph.roberts@email.com', '780.151.228-45', '67.944.944', '1965-01-22', 60, '642 Walker Lodge', '96861-644', 'Centro', 'OK', 'South Stanley', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Sarah Avery', '68154952250', 'sarah.avery@email.com', '676.659.646-98', '34.400.793', '1967-06-04', 58, '759 Laura Flats', '12292-199', 'Centro', 'SP', 'Christineberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Donna Aguilar', '71834567243', 'donna.aguilar@email.com', '957.297.169-52', '45.243.132', '2001-02-24', 24, '162 Jessica Square Apt. 679', '46418-216', 'Centro', 'SD', 'South Kevinside', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Cristina Solorio Padilla', '95629298933', 'cristina.solorio.padilla@email.com', '757.259.927-36', '31.240.452', '1980-10-09', 45, 'Retorno Camboya 494 Interior 253', '91278-182', 'Centro', 'TAMPS', 'Nueva República de Moldova', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Edelmiro Avilés Montoya', '59223647139', 'edelmiro.avilés.montoya@email.com', '267.618.166-78', '81.580.275', '1976-11-22', 49, 'Paseo Germán Cañete 76', '65482-841', 'Centro', 'SP', 'Vizcaya', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Concepción Valdez', '25458346342', 'concepción.valdez@email.com', '309.883.305-91', '67.237.593', '1977-03-18', 48, 'Corredor Norte Gallegos 997 Edif. 635 , Depto. 690', '42816-392', 'Centro', 'BC', 'San Adela los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Carla Aldonza Sarabia Haro', '41490466790', 'carla.aldonza.sarabia.haro@email.com', '327.293.784-78', '17.240.624', '2001-04-26', 24, 'Pasaje Puebla 460 Edif. 928 , Depto. 248', '15240-114', 'Centro', 'COL', 'San Elias los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Isis Rezende', '55319574548', 'isis.rezende@email.com', '535.639.888-95', '44.709.389', '1967-05-15', 58, 'Colônia Cardoso, 68', '22823-772', 'Centro', 'DF', 'da Costa da Serra', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Breno Araújo', '55719318993', 'breno.araújo@email.com', '217.201.584-32', '56.461.967', '1960-06-22', 65, 'Vila de Gomes, 2', '45451-371', 'Centro', 'AP', 'Pereira da Prata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'David Andrews', '04564044551', 'david.andrews@email.com', '356.750.419-64', '88.718.271', '1979-12-10', 46, '3280 Dillon Course', '92123-484', 'Centro', 'AL', 'Wagnerfort', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Yolanda Montañez', '62111138977', 'yolanda.montanez@email.com', '394.271.991-63', '55.863.129', '1987-09-02', 38, 'Calle Mares 262 Edif. 106 , Depto. 036', '23527-665', 'Centro', 'MOR', 'San Clemente de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Jacqueline Rodriguez', '80739031494', 'jacqueline.rodriguez@email.com', '783.257.878-38', '51.303.736', '1957-10-06', 68, '5382 Thomas Station', '84140-123', 'Centro', 'SP', 'North Herbert', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Michelle Brooks', '58395736651', 'michelle.brooks@email.com', '312.284.125-73', '25.362.894', '2006-11-14', 19, '7197 Brandi Common', '57187-847', 'Centro', 'KS', 'South Davidborough', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Milena Moura', '55319937418', 'milena.moura@email.com', '746.657.791-63', '46.733.168', '1998-01-06', 27, 'Fazenda Maitê Porto, 27', '69060-310', 'Centro', 'PI', 'Almeida', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Justin Vang', '58689971267', 'justin.vang@email.com', '965.614.468-86', '99.470.476', '1966-06-05', 59, '70171 Young Lodge', '26770-941', 'Centro', 'SP', 'North John', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Gustavo Henrique Silva', '55219322879', 'gustavo.henrique.silva@email.com', '212.785.652-97', '51.647.722', '1966-05-18', 59, 'Aeroporto de Rocha, 755', '35799-196', 'Centro', 'RO', 'Martins', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Manolo del Múgica', '16789843431', 'manolo.del.múgica@email.com', '820.273.832-17', '93.845.805', '1971-01-07', 54, 'Pasaje Valentina Reig 3', '19683-772', 'Centro', 'SP', 'Málaga', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'David Donaldson', '24739784705', 'david.donaldson@email.com', '130.784.928-90', '65.119.106', '1975-10-01', 50, '3541 Hall Ford Suite 734', '99147-632', 'Centro', 'CT', 'Davisstad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Robert Burton', '76520725297', 'robert.burton@email.com', '310.827.301-51', '14.554.452', '1975-10-21', 50, '4322 Walker Mills Apt. 006', '17769-569', 'Centro', 'SP', 'Katelynbury', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Mónica Villagómez Pedraza', '34164564839', 'mónica.villagómez.pedraza@email.com', '107.692.156-83', '20.685.428', '1976-04-23', 49, 'Prolongación Sonora 544 897', '49327-850', 'Centro', 'SLP', 'San Claudio los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Amber Davis', '01572937419', 'amber.davis@email.com', '253.791.210-56', '51.712.332', '1983-05-07', 42, '098 Beck Flat Apt. 073', '35771-767', 'Centro', 'OR', 'Lyonsborough', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Genaro Razo', '92743734211', 'genaro.razo@email.com', '720.645.426-56', '26.409.299', '1987-01-20', 38, 'Circuito Mauritania 810 753', '34570-887', 'Centro', 'CAMP', 'San Bernabé los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Paca Lledó Espada', '68972869141', 'paca.lledó.espada@email.com', '131.686.253-51', '67.335.489', '1965-02-26', 60, 'Alameda Emiliana Barrio 11 Apt. 36 ', '10520-130', 'Centro', 'SP', 'Baleares', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Vitória Nunes', '55819874318', 'vitória.nunes@email.com', '174.438.279-84', '21.720.236', '1967-04-27', 58, 'Estrada de Santos', '43533-758', 'Centro', 'MS', 'Melo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Josep Losada Puga', '61570669369', 'josep.losada.puga@email.com', '690.113.941-55', '69.920.413', '1986-11-18', 39, 'Calle de Juan Carlos Rosales 66 Apt. 83 ', '12676-567', 'Centro', 'SP', 'Huesca', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Ana Sofía Guzmán Escribano', '91076487753', 'ana.sofía.guzmán.escribano@email.com', '473.740.748-74', '30.743.793', '1991-04-01', 34, 'Pasaje Ildefonso Águila 64 Piso 8 ', '12404-881', 'Centro', 'SP', 'Soria', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Alicia Robledo Razo', '12354801655', 'alicia.robledo.razo@email.com', '579.984.156-14', '18.689.566', '1996-09-06', 29, 'Retorno Sur Aponte 370 Interior 098', '35548-736', 'Centro', 'MICH', 'San Mateo los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Dean Gibson', '14225790746', 'dean.gibson@email.com', '343.872.147-70', '57.514.678', '1986-08-27', 39, '299 Duane Knolls Apt. 880', '17634-267', 'Centro', 'SP', 'Brownview', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Manuela Felipa Arteaga Cerezo', '17939709780', 'manuela.felipa.arteaga.cerezo@email.com', '367.975.165-24', '94.618.301', '1966-09-07', 59, 'Alameda de Joaquín Acevedo 39 Puerta 7 ', '72473-971', 'Centro', 'SP', 'Barcelona', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Valerie Valentine', '38648984051', 'valerie.valentine@email.com', '611.390.929-37', '29.190.452', '1957-01-11', 68, '54841 James Motorway', '78208-267', 'Centro', 'MA', 'South Danielle', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Victor Rowe', '27700682231', 'victor.rowe@email.com', '339.393.113-90', '84.433.110', '1954-10-31', 71, '306 Reynolds Fort', '26353-964', 'Centro', 'MS', 'New Josephmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Dr. Paulo Melo', '55419963558', 'dr..paulo.melo@email.com', '280.359.828-70', '50.552.292', '1973-03-14', 52, 'Feira de Porto, 6', '40743-330', 'Centro', 'AL', 'Rodrigues', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Crystal Johnson', '44332802449', 'crystal.johnson@email.com', '563.879.931-20', '37.232.667', '1963-08-26', 62, '5821 Steven Pike Suite 259', '88402-501', 'Centro', 'NC', 'Thomasshire', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Jason Welch', '62752446199', 'jason.welch@email.com', '673.946.736-86', '81.947.335', '1956-09-02', 69, '3801 Holt Dale Apt. 404', '59984-777', 'Centro', 'NH', 'Port Patricia', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Francisco Javier Pineda Reyes', '65164278082', 'francisco.javier.pineda.reyes@email.com', '291.581.582-29', '99.262.848', '2002-03-17', 23, 'C. Rafael Ribera 197 Apt. 97 ', '53695-112', 'Centro', 'SP', 'Guipúzcoa', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Sarah Fogaça', '55819581809', 'sarah.fogaça@email.com', '689.718.182-40', '84.101.380', '1980-11-10', 45, 'Distrito de Souza, 73', '45677-744', 'Centro', 'RO', 'Souza da Prata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Melissa Hale', '76951863906', 'melissa.hale@email.com', '654.422.844-40', '98.562.191', '1962-04-11', 63, '7909 Robles Parkways', '58739-532', 'Centro', 'VT', 'Evanfort', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Sergio del Cuéllar', '15315220178', 'sergio.del.cuéllar@email.com', '245.769.191-72', '91.933.526', '1982-09-29', 43, 'Alameda Anna Tomé 48', '25984-880', 'Centro', 'SP', 'Cantabria', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Emanuel da Mota', '55119115560', 'emanuel.da.mota@email.com', '534.342.649-80', '31.814.495', '1971-10-03', 54, 'Estrada de Cardoso, 44', '36129-670', 'Centro', 'RR', 'Nunes', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Lic. Teodoro Bañuelos', '99018959054', 'lic..teodoro.banuelos@email.com', '662.270.454-39', '93.857.205', '1962-07-09', 63, 'Continuación Nuevo León 903 066', '25042-538', 'Centro', 'OAX', 'Nueva Portugal', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Susan Johnson', '87306828354', 'susan.johnson@email.com', '257.481.647-60', '74.873.475', '1971-11-16', 54, '790 Monica Ranch', '46449-633', 'Centro', 'NE', 'Thompsonstad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Davi Viana', '55519477888', 'davi.viana@email.com', '909.504.866-21', '51.830.678', '1981-12-11', 44, 'Alameda da Costa, 75', '51116-138', 'Centro', 'RS', 'Moraes da Mata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Caitlyn Smith', '73940229231', 'caitlyn.smith@email.com', '887.688.400-98', '82.625.753', '1989-07-10', 36, '45758 Brown Vista Apt. 294', '34412-273', 'Centro', 'MT', 'New Michaelside', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Robin Shannon', '44964660690', 'robin.shannon@email.com', '699.100.211-41', '15.459.987', '1973-06-03', 52, '49815 Liu Wells Suite 278', '89839-884', 'Centro', 'NH', 'East Deniseside', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Paco Salom Priego', '12958936380', 'paco.salom.priego@email.com', '233.458.104-75', '40.517.542', '1999-07-23', 26, 'Paseo de Américo Silva 89 Piso 1 ', '27876-821', 'Centro', 'SP', 'Albacete', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Ronald Black', '50732617582', 'ronald.black@email.com', '841.678.350-86', '34.346.899', '1958-04-12', 67, '80941 Smith Lakes Suite 752', '66616-626', 'Centro', 'SP', 'New Melissa', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Renee Tran', '55666950674', 'renee.tran@email.com', '382.105.610-49', '82.587.412', '1972-08-20', 53, '09680 Heather Fall Suite 040', '48844-863', 'Centro', 'SP', 'Jamiebury', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Wanda Smith', '34292905360', 'wanda.smith@email.com', '812.497.507-26', '81.364.741', '2003-02-05', 22, '481 Yates Way Apt. 592', '15356-776', 'Centro', 'KS', 'Jacobsshire', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Marcus Holt', '86697154363', 'marcus.holt@email.com', '960.853.517-34', '23.988.270', '1972-09-27', 53, '47421 Amy Orchard Suite 963', '92922-931', 'Centro', 'IN', 'Lake Manuelton', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Jeremy Wilson', '71794949744', 'jeremy.wilson@email.com', '764.954.457-75', '14.917.507', '1983-12-13', 42, '4227 Alexander Prairie Suite 907', '45589-376', 'Centro', 'SP', 'Jessicamouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Srta. Bruna Lopes', '55819978192', 'srta..bruna.lopes@email.com', '856.664.574-35', '36.934.449', '1965-10-13', 60, 'Setor Benjamin Rodrigues', '98322-205', 'Centro', 'MS', 'Farias da Mata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Cristian Peña', '76093643140', 'cristian.pena@email.com', '363.847.878-19', '59.752.261', '1971-08-09', 54, 'Avenida Nayarit 085 Edif. 850 , Depto. 764', '80545-691', 'Centro', 'BC', 'San Sonia de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Óliver Villalobos Espinal', '11048634637', 'óliver.villalobos.espinal@email.com', '543.466.335-58', '75.179.472', '1983-07-05', 42, 'Viaducto Líbano 428 Edif. 772 , Depto. 826', '57691-993', 'Centro', 'YUC', 'San Estela los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Damián Olivera Huerta', '45918840608', 'damián.olivera.huerta@email.com', '943.551.359-81', '73.167.105', '1979-04-30', 46, 'Urbanización Ileana Castejón 9', '75938-302', 'Centro', 'SP', 'Jaén', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Angela Friedman', '51013273163', 'angela.friedman@email.com', '282.523.706-54', '72.804.492', '1971-08-01', 54, '6548 Ryan Stravenue', '31183-353', 'Centro', 'OK', 'Port Melissa', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Susan Lee', '73361072861', 'susan.lee@email.com', '455.431.309-77', '30.343.204', '2002-06-22', 23, '912 Weber Tunnel', '92575-546', 'Centro', 'SP', 'West Michael', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Jessica Jimenez', '95027692202', 'jessica.jimenez@email.com', '833.695.700-70', '16.550.580', '2006-11-08', 19, '60838 William Oval', '88145-111', 'Centro', 'CA', 'Combsmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Brenda Willis', '19827763094', 'brenda.willis@email.com', '442.121.825-13', '51.283.259', '2003-02-08', 22, '192 Kirk Burgs Suite 727', '52524-448', 'Centro', 'CO', 'Woodton', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Dra. Laís Fernandes', '55319900128', 'dra..laís.fernandes@email.com', '183.560.804-42', '82.356.151', '1963-04-28', 62, 'Favela de da Paz, 695', '41075-192', 'Centro', 'RR', 'Santos das Flores', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Evita Manzano Segarra', '64567496257', 'evita.manzano.segarra@email.com', '210.248.479-85', '99.130.241', '1987-09-03', 38, 'Pasaje Carina Mariscal 98 Piso 2 ', '65026-616', 'Centro', 'SP', 'Baleares', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Sr. Felipe Correia', '55219223647', 'sr..felipe.correia@email.com', '997.155.637-45', '74.602.115', '1962-06-15', 63, 'Alameda Souza, 2', '50947-723', 'Centro', 'RS', 'da Rocha', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Ángela Eligia Diaz Arroyo', '89978632822', 'ángela.eligia.diaz.arroyo@email.com', '375.574.967-16', '13.597.460', '1976-03-16', 49, 'Acceso de Balduino Saez 745', '83457-392', 'Centro', 'SP', 'Huesca', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Jessica Woods', '93960724852', 'jessica.woods@email.com', '156.143.766-92', '96.367.505', '1975-01-16', 50, '062 Spencer Pine Apt. 368', '68984-287', 'Centro', 'SP', 'North Markborough', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Zacarías Bernardo Castillo Ruiz', '60178600424', 'zacarías.bernardo.castillo.ruiz@email.com', '313.722.853-76', '63.312.293', '1966-11-30', 59, 'Privada Norte Negrón 086 Interior 875', '10518-103', 'Centro', 'TLAX', 'Vieja Serbia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Igor Dias', '55619942116', 'igor.dias@email.com', '847.820.649-66', '26.181.203', '1968-07-07', 57, 'Vale Alves, 94', '22224-794', 'Centro', 'PB', 'Azevedo Verde', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Bryce Williams', '92730108429', 'bryce.williams@email.com', '468.848.812-60', '90.272.429', '1979-02-18', 46, '961 Deanna Street', '22721-345', 'Centro', 'PA', 'New Judy', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Marcos Vinicius Ribeiro', '55319586111', 'marcos.vinicius.ribeiro@email.com', '973.359.763-70', '68.469.223', '1976-06-28', 49, 'Esplanada de Novaes', '22289-564', 'Centro', 'BA', 'Rodrigues', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Carmen Cobos Caparrós', '67614364017', 'carmen.cobos.caparrós@email.com', '984.961.438-15', '53.269.398', '1972-12-25', 53, 'Cañada de Perlita Solera 34', '70219-492', 'Centro', 'SP', 'Vizcaya', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Emily Erickson', '61788537808', 'emily.erickson@email.com', '725.956.672-94', '59.310.447', '1964-08-28', 61, '61636 Bradford Road Apt. 354', '70345-629', 'Centro', 'SP', 'South Dannyfurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'María Jesús Blanco', '05917738303', 'maría.jesús.blanco@email.com', '390.723.856-37', '73.489.406', '1997-06-09', 28, 'Pasaje Laura Benito 99 Piso 1 ', '62548-549', 'Centro', 'SP', 'Cantabria', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Brittany Bell', '14163870586', 'brittany.bell@email.com', '204.447.276-80', '95.149.618', '1955-04-14', 70, '1158 John Harbor Suite 359', '46684-164', 'Centro', 'SP', 'New Johnbury', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Catalina Ledesma Arriaga', '45876532820', 'catalina.ledesma.arriaga@email.com', '174.339.220-25', '99.947.828', '1968-01-26', 57, 'Ampliación Coahuila de Zaragoza 593 Interior 918', '37387-388', 'Centro', 'CHIS', 'San Abril los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Alcides Rodrigo Paniagua Múñiz', '32396682447', 'alcides.rodrigo.paniagua.múniz@email.com', '345.517.651-54', '30.947.789', '1969-07-10', 56, 'Alameda Evangelina Lopez 53 Apt. 58 ', '40724-130', 'Centro', 'SP', 'Tarragona', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Stephen Bryant', '60168503538', 'stephen.bryant@email.com', '678.628.390-77', '35.906.309', '1998-04-18', 27, '320 Cook Mews', '30801-886', 'Centro', 'SP', 'Roblesfort', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Melissa Peterson', '91849401766', 'melissa.peterson@email.com', '951.111.301-88', '96.516.319', '1987-03-31', 38, '67148 William Coves', '88572-803', 'Centro', 'MI', 'East Vincentville', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Pamela Ochoa', '68789481556', 'pamela.ochoa@email.com', '917.116.363-46', '18.220.379', '2005-03-19', 20, '565 Holder Run Suite 830', '90062-176', 'Centro', 'NY', 'Davidberg', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Srta. Maria Fernanda Duarte', '55519394707', 'srta..maria.fernanda.duarte@email.com', '236.995.187-44', '37.537.407', '1975-02-14', 50, 'Núcleo das Neves, 83', '71788-732', 'Centro', 'MS', 'Moura do Sul', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Piedad Rivera Conde', '97234340426', 'piedad.rivera.conde@email.com', '584.476.897-44', '96.639.912', '2007-04-09', 18, 'Rambla de Ibán Fábregas 81', '61073-753', 'Centro', 'SP', 'Salamanca', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Héctor Porras', '01288103021', 'héctor.porras@email.com', '259.352.417-84', '46.678.513', '1973-07-03', 52, 'Continuación Norte Hernandes 808 Edif. 742 , Depto. 525', '57713-244', 'Centro', 'QRO', 'San Raúl los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Erin Brooks', '00304310665', 'erin.brooks@email.com', '273.907.848-11', '68.686.484', '1961-03-18', 64, '7443 Gilmore Ferry Suite 765', '26597-341', 'Centro', 'SP', 'Lake Heidi', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Lorena Alejandro Aponte', '32943459861', 'lorena.alejandro.aponte@email.com', '977.853.363-10', '56.548.188', '1978-04-01', 47, 'Viaducto Angola 580 Interior 809', '83372-842', 'Centro', 'JAL', 'Nueva Chile', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'George Mathews', '88176853574', 'george.mathews@email.com', '994.393.992-10', '94.933.175', '1960-05-07', 65, '99393 Stewart Trafficway Suite 841', '48483-653', 'Centro', 'SP', 'North Dana', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Luis Manuel Saiz', '92404897758', 'luis.manuel.saiz@email.com', '154.828.806-92', '98.534.808', '2002-06-08', 23, 'Retorno Guatemala 773 183', '14859-104', 'Centro', 'BCS', 'Nueva Luxemburgo', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Helena Farias', '55419514736', 'helena.farias@email.com', '706.646.175-94', '72.508.438', '1979-02-01', 46, 'Morro de Lopes, 48', '20132-151', 'Centro', 'MA', 'Almeida do Oeste', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Terry Higgins', '82141355710', 'terry.higgins@email.com', '481.719.384-89', '79.605.680', '1992-04-26', 33, '9018 Andrea Mission Apt. 627', '84003-194', 'Centro', 'SP', 'North Josephbury', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Catalina Velázquez Bétancourt', '62420569798', 'catalina.velázquez.bétancourt@email.com', '371.966.912-79', '99.175.625', '1958-08-24', 67, 'Privada Méndez 641 371', '77484-681', 'Centro', 'VER', 'San Vanesa de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Tadeo Ibañez Poza', '77456907587', 'tadeo.ibanez.poza@email.com', '444.384.641-80', '69.606.975', '1990-04-30', 35, 'Rambla de Carmelita Azcona 56 Apt. 50 ', '73770-926', 'Centro', 'SP', 'La Coruña', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Barbara Jones', '94634097066', 'barbara.jones@email.com', '742.640.403-60', '74.731.821', '1972-03-20', 53, '984 Church Spur', '25961-453', 'Centro', 'HI', 'Port Duaneland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Tristán Guerrero Valdés', '57668132631', 'tristán.guerrero.valdés@email.com', '759.325.220-71', '25.792.878', '1957-06-17', 68, 'Ronda Irma Manrique 67', '27334-399', 'Centro', 'SP', 'Badajoz', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Bernabé Luis Miguel Mora Vargas', '80641413493', 'bernabé.luis.miguel.mora.vargas@email.com', '812.762.793-38', '72.147.611', '1964-02-04', 61, 'Vial de David Caparrós 71', '37156-207', 'Centro', 'SP', 'Ourense', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'José Emilio Tafoya', '18222433746', 'josé.emilio.tafoya@email.com', '992.575.682-61', '76.815.763', '1999-01-23', 26, 'Prolongación Hidalgo 326 195', '71250-430', 'Centro', 'BCS', 'Nueva Emiratos Árabes Unidos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Mr. Samuel Cruz', '78868405309', 'mr..samuel.cruz@email.com', '607.974.977-52', '88.922.831', '1996-01-30', 29, '872 Michael Lakes Apt. 720', '34045-587', 'Centro', 'SP', 'Reynoldsberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Daniel Clark', '23202325155', 'daniel.clark@email.com', '788.632.443-54', '36.275.705', '1974-01-22', 51, '43292 Hannah Brook Suite 449', '98126-517', 'Centro', 'SP', 'East Alexis', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Rebecca Brown', '76536280828', 'rebecca.brown@email.com', '236.119.131-55', '33.984.107', '1997-11-26', 28, '160 Juan Manors Apt. 814', '38698-590', 'Centro', 'SP', 'Lake Taylorhaven', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Yago Vieira', '55219498249', 'yago.vieira@email.com', '797.719.466-33', '61.627.576', '2002-02-25', 23, 'Morro de Sales, 3', '59387-372', 'Centro', 'PI', 'da Paz Verde', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Brittany Woods', '91890928988', 'brittany.woods@email.com', '488.953.914-32', '14.655.717', '1986-09-28', 39, '93553 Young Grove', '48395-608', 'Centro', 'SP', 'West Shelly', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Diego Nayeli Caraballo', '23403576685', 'diego.nayeli.caraballo@email.com', '359.867.438-99', '76.508.752', '2004-01-12', 21, 'Privada Norte Escobedo 576 872', '74413-103', 'Centro', 'TAMPS', 'San Jaqueline de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Jean Cummings', '18772804971', 'jean.cummings@email.com', '966.340.653-10', '57.883.437', '1985-06-03', 40, '4583 Hall Mill Apt. 347', '37618-827', 'Centro', 'ID', 'New Danafurt', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Jerry Russell', '20122826285', 'jerry.russell@email.com', '945.421.199-83', '10.486.394', '1971-10-05', 54, '02908 Harris Prairie', '50383-813', 'Centro', 'WI', 'Elizabethland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Brunilda Planas', '71293123977', 'brunilda.planas@email.com', '878.319.503-27', '61.349.485', '2002-03-10', 23, 'Vial de Melania Sáez 5', '66053-576', 'Centro', 'SP', 'Huelva', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Mark Mata', '52907846628', 'mark.mata@email.com', '203.495.759-72', '84.443.493', '1970-04-21', 55, '0902 Meyers Court', '81226-628', 'Centro', 'SP', 'East Randy', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Anunciación del Vila', '61559121679', 'anunciación.del.vila@email.com', '159.893.255-66', '59.218.505', '1974-02-06', 51, 'Plaza de Mauricio Narváez 67 Puerta 9 ', '95126-770', 'Centro', 'SP', 'León', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Amy White', '94541512720', 'amy.white@email.com', '552.404.393-98', '82.591.404', '1967-08-16', 58, '2215 Jordan Route Apt. 328', '85885-651', 'Centro', 'AL', 'Port Derrick', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Victoria Hubbard', '54491424845', 'victoria.hubbard@email.com', '687.353.630-82', '56.412.269', '2006-11-12', 19, '03914 Sandra Trace Suite 018', '91896-887', 'Centro', 'SP', 'Anthonyshire', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Macario Almansa Saavedra', '75850111547', 'macario.almansa.saavedra@email.com', '560.194.253-95', '62.868.648', '1980-10-11', 45, 'Glorieta de Lalo Castro 91', '78855-794', 'Centro', 'SP', 'Valladolid', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Regina Bryant', '88587482918', 'regina.bryant@email.com', '960.334.847-34', '36.298.827', '1970-11-11', 55, '5849 Gray Radial', '48808-480', 'Centro', 'MS', 'West Shannon', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Irma Gálvez Cortez', '33800586778', 'irma.gálvez.cortez@email.com', '270.279.517-39', '50.819.771', '1996-11-23', 29, 'Andador Tlaxcala 779 Edif. 149 , Depto. 478', '45088-329', 'Centro', 'CHIH', 'Nueva Rumania', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'James Collins', '76824931933', 'james.collins@email.com', '408.115.263-46', '89.941.501', '1976-12-29', 49, '93736 Gill Lock', '81883-558', 'Centro', 'SP', 'Charlesfurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Rodrigo da Cruz', '55849100842', 'rodrigo.da.cruz@email.com', '621.339.348-89', '82.583.566', '2003-10-03', 22, 'Conjunto de Pinto, 80', '68654-901', 'Centro', 'ES', 'Rocha', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'John Leblanc', '04564010383', 'john.leblanc@email.com', '130.590.670-67', '14.447.998', '1964-10-30', 61, '015 Smith Summit', '61300-343', 'Centro', 'SP', 'Lake Thomas', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Katrina Brown', '15324885019', 'katrina.brown@email.com', '670.653.953-41', '59.285.690', '1962-02-20', 63, '1468 Robin Orchard', '84481-971', 'Centro', 'SC', 'Josephmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Calebe Lima', '55519546411', 'calebe.lima@email.com', '224.356.937-54', '61.351.346', '1975-03-25', 50, 'Lago Manuela Rocha, 50', '87147-446', 'Centro', 'RR', 'Mendes da Praia', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Michael Riggs', '66792278353', 'michael.riggs@email.com', '528.307.890-14', '95.293.374', '1977-05-11', 48, '3440 Johnson Plaza', '56391-705', 'Centro', 'SP', 'New Laurietown', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Theodore Nguyen', '47738677348', 'theodore.nguyen@email.com', '968.643.472-45', '15.947.192', '1982-06-03', 43, '3589 William Brooks', '57888-906', 'Centro', 'SP', 'Randallland', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Joe Dunn', '07014469523', 'joe.dunn@email.com', '459.298.833-87', '56.576.551', '1989-11-05', 36, '7765 Melissa Summit Apt. 321', '60785-522', 'Centro', 'NE', 'North Chad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'William Mcneil', '59424576488', 'william.mcneil@email.com', '671.182.285-93', '92.307.808', '1957-10-13', 68, '7067 Johnson Lodge Suite 622', '52601-121', 'Centro', 'CT', 'Johnsonmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Julie Landa', '10741623067', 'julie.landa@email.com', '548.282.153-90', '87.722.825', '1970-12-04', 55, 'Vial Marcela Esparza 45', '30063-599', 'Centro', 'SP', 'Badajoz', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Renan Sales', '55849723827', 'renan.sales@email.com', '986.965.167-26', '12.965.524', '2003-09-06', 22, 'Trevo Correia, 993', '64054-361', 'Centro', 'PR', 'Castro', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Mónica Jonás Nava Cabán', '15237714160', 'mónica.jonás.nava.cabán@email.com', '609.764.900-46', '31.299.331', '1992-08-14', 33, 'Prolongación Paz 472 201', '80258-839', 'Centro', 'SLP', 'San Eugenia los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Stephen Cooper', '52186855634', 'stephen.cooper@email.com', '205.255.903-11', '60.913.176', '1997-05-28', 28, '3368 Howard Unions', '13750-169', 'Centro', 'SP', 'Port Jennifermouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Miguel Moura', '55849546088', 'miguel.moura@email.com', '974.365.338-57', '60.135.379', '1961-02-23', 64, 'Via Nogueira, 9', '68218-354', 'Centro', 'DF', 'Dias', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Úrsula Quintero Hervás', '24366799929', 'úrsula.quintero.hervás@email.com', '876.307.381-73', '52.519.711', '1992-07-12', 33, 'Pasadizo Isaac Diez 84', '70013-803', 'Centro', 'SP', 'Palencia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'José Carlos María Elena Nevárez', '91215256886', 'josé.carlos.maría.elena.nevárez@email.com', '761.525.992-19', '58.736.947', '1981-11-28', 44, 'Diagonal Nieves 974 Edif. 593 , Depto. 958', '79076-155', 'Centro', 'ZAC', 'Vieja Países Bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Oswaldo Manuel Castellanos Garza', '53169242290', 'oswaldo.manuel.castellanos.garza@email.com', '275.709.143-22', '35.146.844', '1999-07-04', 26, 'Boulevard Sur Ferrer 020 333', '31776-371', 'Centro', 'SON', 'San Elsa los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Godofredo Santamaría', '51457446425', 'godofredo.santamaría@email.com', '532.112.705-58', '46.632.399', '1984-12-29', 41, 'Calle de Yolanda Sandoval 16', '82466-166', 'Centro', 'SP', 'Zaragoza', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Bernarda del Juliá', '93026680382', 'bernarda.del.juliá@email.com', '386.118.638-41', '37.277.212', '1992-03-12', 33, 'Calle de Remigio Santamaria 4', '57690-483', 'Centro', 'SP', 'Ceuta', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Stanley Pham', '92642636634', 'stanley.pham@email.com', '373.299.412-21', '36.921.276', '1969-12-25', 56, '6161 Schroeder Grove', '76846-686', 'Centro', 'SP', 'South Kathleenside', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Karen Greene', '15122405230', 'karen.greene@email.com', '143.837.152-73', '98.859.273', '2005-12-16', 20, '9004 Edwards Summit', '34349-400', 'Centro', 'SP', 'South Mckenziechester', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Silvano Aparicio Ríos', '54219371828', 'silvano.aparicio.ríos@email.com', '822.625.470-69', '12.661.519', '1973-07-10', 52, 'Prolongación Durango 118 Edif. 449 , Depto. 887', '37090-715', 'Centro', 'CAMP', 'San Natalia los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Sophia Fogaça', '55119287597', 'sophia.fogaça@email.com', '874.474.233-13', '10.708.262', '1991-06-28', 34, 'Esplanada Santos, 14', '40585-823', 'Centro', 'MA', 'da Rosa', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Daniela Abel Sauceda Robledo', '19477937115', 'daniela.abel.sauceda.robledo@email.com', '200.681.885-18', '51.662.800', '1957-04-20', 68, 'Continuación Norte Salas 723 Interior 212', '52399-941', 'Centro', 'QRO', 'Vieja Nauru', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Dr. Lucía Jasso', '19349065151', 'dr..lucía.jasso@email.com', '514.130.567-89', '65.302.871', '1997-02-26', 28, 'Privada Sur Cardona 789 Interior 320', '66641-998', 'Centro', 'NAY', 'Vieja Niger', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Almudena del Pérez', '53486275225', 'almudena.del.pérez@email.com', '590.305.562-82', '72.604.538', '1957-03-19', 68, 'Rambla Amaya Piña 28', '37991-709', 'Centro', 'SP', 'Murcia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Aaron Thompson', '52025443234', 'aaron.thompson@email.com', '274.853.155-81', '49.529.167', '1968-11-11', 57, '75641 Spears Walk Suite 565', '85593-170', 'Centro', 'HI', 'Kellyborough', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Mikayla Rodriguez', '95913718694', 'mikayla.rodriguez@email.com', '216.585.809-14', '65.324.864', '1967-09-27', 58, '5660 Chad Streets Suite 535', '84700-617', 'Centro', 'FL', 'Patriciaside', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Paula Allen', '34533490938', 'paula.allen@email.com', '444.459.798-88', '53.393.740', '1969-07-12', 56, '4629 Huber Isle', '44869-430', 'Centro', 'KS', 'Fieldsstad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Joel Williams', '27312989883', 'joel.williams@email.com', '826.727.838-89', '90.970.144', '1992-12-14', 33, '471 Ashley Trail Apt. 670', '40821-638', 'Centro', 'IL', 'Snyderburgh', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Salvador Parra', '41707492642', 'salvador.parra@email.com', '569.263.468-55', '45.806.752', '1969-04-07', 56, 'Privada Sonora 161 700', '94823-847', 'Centro', 'DGO', 'Vieja Botswana', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Tammy Greene', '67812014130', 'tammy.greene@email.com', '363.568.545-57', '42.653.881', '1964-01-03', 61, '4006 Andrew Shore', '41431-170', 'Centro', 'VT', 'North Daleside', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Maria Clara Nascimento', '55849524637', 'maria.clara.nascimento@email.com', '760.986.740-70', '48.981.652', '1961-06-30', 64, 'Conjunto da Luz, 20', '84411-457', 'Centro', 'RJ', 'Pereira da Prata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Lorena Viana', '55319024228', 'lorena.viana@email.com', '559.893.943-90', '18.507.707', '1994-06-26', 31, 'Sítio Pedro Miguel Oliveira, 10', '75800-414', 'Centro', 'PR', 'Correia', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Ana Clara Caldeira', '55319208563', 'ana.clara.caldeira@email.com', '444.110.699-25', '60.384.596', '1971-03-25', 54, 'Núcleo Felipe Gonçalves, 43', '39405-473', 'Centro', 'PB', 'Porto', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Thomas Gardner', '86564785195', 'thomas.gardner@email.com', '517.807.243-44', '51.978.386', '1985-07-31', 40, '3173 Jackson Turnpike Suite 783', '29653-949', 'Centro', 'SP', 'West Emily', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Vicente Alemán Ocasio', '34790577717', 'vicente.alemán.ocasio@email.com', '404.116.718-76', '57.209.490', '1958-12-28', 67, 'Diagonal Sur Corona 872 Interior 905', '47594-319', 'Centro', 'PUE', 'San Lourdes de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Augusto Gomes', '55319067620', 'augusto.gomes@email.com', '773.220.503-97', '29.332.734', '2003-08-26', 22, 'Lagoa de Caldeira', '96834-878', 'Centro', 'SE', 'Oliveira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Jeffrey Molina', '19260370637', 'jeffrey.molina@email.com', '132.610.993-29', '32.420.771', '1975-09-16', 50, '3474 Smith Lane', '12510-286', 'Centro', 'SC', 'Douglaston', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Anthony Wilkerson', '40041621725', 'anthony.wilkerson@email.com', '759.256.226-12', '31.508.937', '1971-06-29', 54, '61971 Short Cliff Suite 116', '70389-965', 'Centro', 'ME', 'Phillipstad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Daniela Wendolin Abreu', '33721314536', 'daniela.wendolin.abreu@email.com', '742.963.483-76', '35.745.427', '1958-09-10', 67, 'Ampliación Distrito Federal 923 Interior 828', '20111-541', 'Centro', 'YUC', 'Nueva República Popular Democrática de Corea', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Raúl Nava', '43353793126', 'raúl.nava@email.com', '470.387.758-78', '20.176.336', '1970-09-10', 55, 'Peatonal Querétaro 729 Interior 059', '67961-276', 'Centro', 'SIN', 'Vieja Islas Marshall', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Sr. Bernardo Castro', '55819373858', 'sr..bernardo.castro@email.com', '954.293.886-22', '63.536.910', '1959-12-04', 66, 'Favela Davi Lucas Cunha', '63154-933', 'Centro', 'SP', 'Cardoso Verde', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Humberto Lumbreras-Rozas', '40055752378', 'humberto.lumbreras-rozas@email.com', '214.778.525-20', '35.578.383', '2006-04-02', 19, 'Camino de Rita Amigó 20 Apt. 99 ', '53118-192', 'Centro', 'SP', 'Sevilla', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Sandra Arnold', '17257541935', 'sandra.arnold@email.com', '863.825.483-43', '20.978.174', '1961-11-03', 64, '075 Jennifer Gardens', '35505-693', 'Centro', 'SP', 'Jeremyside', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'José María Barceló Marco', '62241013448', 'josé.maría.barceló.marco@email.com', '130.269.947-40', '26.859.841', '1978-06-23', 47, 'C. Concha Manso 6 Apt. 57 ', '58363-483', 'Centro', 'SP', 'La Rioja', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Mirella Aragão', '55819608398', 'mirella.aragão@email.com', '692.997.619-47', '98.829.811', '1987-02-10', 38, 'Via Marina Cardoso, 76', '17177-806', 'Centro', 'AL', 'Porto', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Ing. Leonor Alba', '25267948302', 'ing..leonor.alba@email.com', '479.220.471-11', '73.719.838', '1971-07-22', 54, 'Periférico Albania 399 Edif. 231 , Depto. 305', '31802-595', 'Centro', 'ZAC', 'San Benjamín los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Ing. Karina Dávila', '93222987934', 'ing..karina.dávila@email.com', '875.614.115-28', '24.921.391', '2002-12-16', 23, 'Ampliación Sur Núñez 973 Edif. 624 , Depto. 013', '12428-262', 'Centro', 'PUE', 'Nueva Suiza', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Denise Chaney', '80538599861', 'denise.chaney@email.com', '294.717.974-36', '28.960.179', '2005-07-17', 20, '8456 Melissa Track Suite 574', '97338-904', 'Centro', 'ID', 'Danielstad', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Ruth Christensen', '82768897766', 'ruth.christensen@email.com', '513.195.238-43', '20.442.986', '1956-08-06', 69, '009 Stephanie Plains Apt. 837', '12606-350', 'Centro', 'LA', 'East Ashleyburgh', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Jose Johnson', '06538217864', 'jose.johnson@email.com', '237.869.347-37', '96.481.320', '1989-05-10', 36, '8894 Amber Crest Apt. 194', '47110-771', 'Centro', 'SP', 'South Vickie', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Robert Moore', '34407812650', 'robert.moore@email.com', '506.622.970-48', '81.997.352', '1983-08-01', 42, '84469 Stewart Junction', '12679-859', 'Centro', 'ME', 'West Joseph', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Micaela Crespo Zepeda', '05960651808', 'micaela.crespo.zepeda@email.com', '566.201.568-92', '55.404.585', '1989-11-20', 36, 'Calle Libia 329 399', '20730-820', 'Centro', 'DF', 'Vieja Tayikistán', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Robert Morales', '65907277029', 'robert.morales@email.com', '278.989.148-84', '57.337.184', '1972-05-23', 53, '53227 Barker Rest', '72041-536', 'Centro', 'SP', 'West Kimchester', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Benjamin Ruiz', '34187210373', 'benjamin.ruiz@email.com', '445.258.575-44', '13.469.446', '1991-03-28', 34, '5363 Christopher Plain Apt. 455', '26435-197', 'Centro', 'SP', 'Walkerchester', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Katelyn Mayer', '89324099936', 'katelyn.mayer@email.com', '916.554.325-87', '88.728.950', '2007-07-16', 18, '567 Lopez Highway', '98465-135', 'Centro', 'AK', 'East Bridgetmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Domitila Carrera', '79547990129', 'domitila.carrera@email.com', '969.554.415-13', '94.590.754', '1963-10-05', 62, 'Rambla Petrona Carbó 45', '89288-550', 'Centro', 'SP', 'Sevilla', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Óliver Soto', '11938386592', 'óliver.soto@email.com', '976.697.320-35', '55.994.509', '1971-03-07', 54, 'Calle Uruguay 001 Edif. 489 , Depto. 533', '83204-158', 'Centro', 'CAMP', 'Vieja Sri Lanka', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'James Meyers', '58145760837', 'james.meyers@email.com', '600.667.366-26', '20.624.153', '2004-05-16', 21, '2412 Clark Stream Apt. 397', '77635-177', 'Centro', 'SP', 'Hawkinsville', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Natália da Mata', '55719994099', 'natália.da.mata@email.com', '321.998.750-98', '67.202.137', '1991-08-09', 34, 'Estrada de Monteiro, 1', '62721-723', 'Centro', 'SE', 'Duarte', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Leandro da Mota', '55819542677', 'leandro.da.mota@email.com', '148.287.612-57', '21.160.336', '2000-10-16', 25, 'Conjunto Renan da Conceição, 812', '14384-577', 'Centro', 'RO', 'Moraes de Gomes', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Eric Carmen Valentín', '88961183355', 'eric.carmen.valentín@email.com', '789.365.194-99', '26.293.360', '1970-12-05', 55, 'Privada Norte Segovia 339 Edif. 951 , Depto. 991', '38674-269', 'Centro', 'VER', 'Nueva Bolivia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Luiz Otávio Moraes', '55619134778', 'luiz.otávio.moraes@email.com', '440.309.183-97', '39.294.628', '1972-03-27', 53, 'Feira Nascimento, 65', '56058-130', 'Centro', 'SC', 'da Costa', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Julio Verdugo', '94606520305', 'julio.verdugo@email.com', '719.469.808-96', '29.196.948', '1998-05-16', 27, 'Diagonal Norte Santillán 375 Interior 237', '22859-692', 'Centro', 'GTO', 'Nueva Camerún', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Dawn Riggs', '52189074845', 'dawn.riggs@email.com', '593.549.774-25', '37.307.470', '2004-05-26', 21, '642 Sarah Walks Apt. 003', '33567-639', 'Centro', 'VA', 'Zunigahaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Michelle Martin', '64124880210', 'michelle.martin@email.com', '542.890.238-26', '88.177.853', '2002-09-25', 23, '805 Michael Falls', '82809-197', 'Centro', 'WY', 'Christopherbury', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Christina Haney', '74934571630', 'christina.haney@email.com', '955.780.208-75', '10.716.805', '1963-05-21', 62, '9921 Perez Corners Suite 996', '68586-876', 'Centro', 'MA', 'Carrbury', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'João Lucas Sales', '55119215105', 'joão.lucas.sales@email.com', '758.150.779-75', '18.752.689', '2001-06-12', 24, 'Vila Ana Júlia Moura, 99', '36011-540', 'Centro', 'ES', 'da Paz de Ramos', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Stella Teixeira', '55519675964', 'stella.teixeira@email.com', '991.226.887-96', '20.231.853', '1999-07-12', 26, 'Chácara de da Rocha, 82', '26153-906', 'Centro', 'PA', 'Teixeira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Ana Wilkerson', '21782062635', 'ana.wilkerson@email.com', '107.185.286-76', '24.830.276', '1995-11-08', 30, '10627 Phillips Turnpike', '78452-195', 'Centro', 'NJ', 'New Ashley', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Terry Green', '76185568926', 'terry.green@email.com', '722.266.204-44', '94.112.826', '2001-02-16', 24, '74688 Benjamin Oval', '63203-642', 'Centro', 'SP', 'Joycefort', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Davi Lucca Correia', '55819004132', 'davi.lucca.correia@email.com', '914.490.630-87', '19.521.582', '1969-03-31', 56, 'Trecho de da Cruz, 407', '26882-244', 'Centro', 'MA', 'Araújo de da Rosa', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Dr. Alexandre Peixoto', '55619381356', 'dr..alexandre.peixoto@email.com', '219.312.818-23', '55.519.366', '1985-08-13', 40, 'Morro Alves, 398', '36542-123', 'Centro', 'PR', 'Costela do Campo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Wesley Anderson', '78915920936', 'wesley.anderson@email.com', '504.438.117-49', '59.663.124', '1984-04-14', 41, '92193 Mcintyre Park', '72845-678', 'Centro', 'NC', 'Haleborough', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'James Christian', '66601246391', 'james.christian@email.com', '986.364.556-45', '29.997.512', '1956-09-29', 69, '2256 Jordan Underpass', '16190-770', 'Centro', 'ME', 'Anthonytown', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Natalia Lourdes Flor Alfaro', '53411199905', 'natalia.lourdes.flor.alfaro@email.com', '642.107.638-12', '26.498.280', '1963-11-06', 62, 'Calle de Paulina Serrano 50 Apt. 04 ', '18602-626', 'Centro', 'SP', 'Burgos', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Adrian Butler', '55057510839', 'adrian.butler@email.com', '979.704.724-29', '32.355.757', '2002-09-16', 23, '8494 Lucas Junctions Suite 022', '97557-276', 'Centro', 'SP', 'Port Monicafurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Emily Harris', '46308597068', 'emily.harris@email.com', '416.819.156-26', '62.575.208', '1959-04-15', 66, '41248 Walker Burgs', '81778-442', 'Centro', 'KS', 'New Brandonhaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Sr. Vicente da Rosa', '55519706256', 'sr..vicente.da.rosa@email.com', '282.540.583-65', '44.192.261', '1976-12-19', 49, 'Rodovia de Rocha', '94382-455', 'Centro', 'SP', 'Sales', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'León Buenaventura Marin Torrijos', '61892043775', 'león.buenaventura.marin.torrijos@email.com', '312.807.471-24', '23.424.461', '1991-05-08', 34, 'Cuesta Cecilio Beltrán 94', '57139-585', 'Centro', 'SP', 'Valencia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Denise Howard', '87198695741', 'denise.howard@email.com', '549.305.704-79', '60.839.713', '2004-09-24', 21, '5724 Thompson Springs', '30064-358', 'Centro', 'MS', 'New Sharon', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Heloísa da Mata', '55419245533', 'heloísa.da.mata@email.com', '605.120.468-13', '34.318.151', '1985-03-14', 40, 'Ladeira Agatha Cavalcanti, 73', '47752-155', 'Centro', 'TO', 'da Cruz', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Jos Claudia Fuentes', '36259117013', 'jos.claudia.fuentes@email.com', '792.217.251-88', '50.977.957', '2001-03-15', 24, 'Periférico Baja California Sur 245 493', '40706-311', 'Centro', 'MOR', 'Nueva Seychelles', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Sr(a). Daniela Anguiano', '66538556285', 'sr(a)..daniela.anguiano@email.com', '611.891.418-38', '93.722.657', '1980-09-30', 45, 'Calzada Romero 995 466', '15753-503', 'Centro', 'OAX', 'San Jacinto los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Karina Fierro Véliz', '45701957963', 'karina.fierro.véliz@email.com', '309.256.551-27', '68.428.262', '1996-01-13', 29, 'Pasaje Belice 053 Edif. 275 , Depto. 941', '79782-331', 'Centro', 'HGO', 'Vieja Bélgica', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Silvia Fernando Molina', '98094797784', 'silvia.fernando.molina@email.com', '864.908.543-52', '83.440.310', '1995-09-11', 30, 'Cerrada Laboy 430 001', '54921-689', 'Centro', 'Q. ROO', 'San Yeni los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Soledad Aurora Madrigal Serrato', '48139308159', 'soledad.aurora.madrigal.serrato@email.com', '345.558.640-47', '45.803.863', '2005-10-18', 20, 'Callejón Cisneros 805 Edif. 758 , Depto. 044', '86562-446', 'Centro', 'YUC', 'San Georgina de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Daniel Flores', '46778086421', 'daniel.flores@email.com', '941.721.170-26', '88.745.659', '1974-04-17', 51, '1792 Jessica Rapid', '98483-412', 'Centro', 'MD', 'Port Paul', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Emilio Nieto Cisneros', '84219462192', 'emilio.nieto.cisneros@email.com', '497.631.755-16', '61.540.170', '1981-05-21', 44, 'Peatonal Campeche 018 Interior 318', '50682-486', 'Centro', 'GTO', 'San Irene los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Lisa Rubio', '75868181060', 'lisa.rubio@email.com', '481.519.770-12', '13.986.985', '1984-11-22', 41, '32210 Jennifer Prairie Apt. 238', '27127-405', 'Centro', 'OR', 'East David', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Sra. Isabelly Ribeiro', '55419592012', 'sra..isabelly.ribeiro@email.com', '562.395.341-51', '30.965.337', '1959-01-17', 66, 'Trecho Almeida, 16', '38930-786', 'Centro', 'MS', 'Castro', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Arthur Wilson', '48946747958', 'arthur.wilson@email.com', '491.629.495-15', '41.816.790', '1994-08-10', 31, '51260 Jimmy Park Apt. 909', '42878-570', 'Centro', 'SP', 'South Christopherfort', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Isabella Duarte', '55849772521', 'isabella.duarte@email.com', '642.480.241-55', '17.652.590', '1961-05-05', 64, 'Feira Almeida, 94', '68194-173', 'Centro', 'MS', 'Almeida', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Alex Wagner', '47226665825', 'alex.wagner@email.com', '446.171.445-14', '48.877.524', '1966-02-10', 59, '64714 Michelle Circle', '74295-153', 'Centro', 'TN', 'North Jacob', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Albert Briggs', '28586980007', 'albert.briggs@email.com', '907.258.747-14', '84.911.292', '1993-08-11', 32, '1052 Hannah Port Suite 692', '53345-499', 'Centro', 'SP', 'Donaldhaven', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Davi Lucca Porto', '55719627080', 'davi.lucca.porto@email.com', '232.629.189-34', '88.341.226', '1969-01-26', 56, 'Recanto Sales, 849', '31401-928', 'Centro', 'CE', 'Vieira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Cayetano Estévez Andrade', '50977585769', 'cayetano.estévez.andrade@email.com', '457.637.736-24', '26.520.129', '1978-12-09', 47, 'C. de Sebastian Santamaría 722 Piso 3 ', '14414-210', 'Centro', 'SP', 'Guipúzcoa', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Dr. Pedro Campos', '55819398184', 'dr..pedro.campos@email.com', '792.487.651-43', '95.442.886', '1984-10-04', 41, 'Chácara de Santos', '82356-735', 'Centro', 'PE', 'da Costa Verde', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Mtro. Reynaldo Puga', '91619881638', 'mtro..reynaldo.puga@email.com', '274.530.169-87', '57.171.685', '1983-01-23', 42, 'Callejón Vanegas 678 744', '40776-769', 'Centro', 'SLP', 'Vieja Rumania', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Ing. Jesús Garrido', '05483126293', 'ing..jesús.garrido@email.com', '708.222.597-66', '32.574.997', '1990-06-12', 35, 'Retorno Liechtenstein 496 Interior 919', '30727-248', 'Centro', 'DF', 'Nueva Kenya', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Gerald Suarez', '36664041500', 'gerald.suarez@email.com', '690.403.806-96', '88.984.710', '2006-01-10', 19, '61885 Jeffery Tunnel', '43288-892', 'Centro', 'UT', 'Kathleenville', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Luiz Fernando Martins', '55849292704', 'luiz.fernando.martins@email.com', '510.583.679-71', '42.594.466', '1955-02-19', 70, 'Estrada de Almeida, 78', '91859-838', 'Centro', 'PR', 'Freitas', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Emanuel Costa', '55119757486', 'emanuel.costa@email.com', '756.390.898-27', '51.702.511', '1982-06-09', 43, 'Conjunto da Conceição, 590', '79657-128', 'Centro', 'AC', 'da Mata de Melo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Stacey Hardin', '95200216471', 'stacey.hardin@email.com', '658.940.709-96', '32.468.530', '1964-11-18', 61, '887 Miller Keys', '84556-690', 'Centro', 'DE', 'Palmerhaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Stephen Werner', '68391453526', 'stephen.werner@email.com', '171.358.977-62', '34.453.847', '1976-02-26', 49, '882 Cochran Brooks', '22091-753', 'Centro', 'SP', 'Gregorymouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Vinicius Ribeiro', '55319244600', 'vinicius.ribeiro@email.com', '715.270.570-60', '66.770.196', '1963-11-08', 62, 'Passarela Natália Novaes, 48', '10890-472', 'Centro', 'PI', 'Dias', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Alejandro Yolanda Pichardo Carreón', '21188842318', 'alejandro.yolanda.pichardo.carreón@email.com', '815.219.803-13', '80.923.450', '1979-08-23', 46, 'Prolongación Uzbekistán 055 Interior 078', '44889-799', 'Centro', 'CAMP', 'Nueva Benin', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Mar Villalba Rosselló', '86104597326', 'mar.villalba.rosselló@email.com', '745.876.347-82', '16.180.272', '1981-12-12', 44, 'Plaza de Jose Ignacio López 602', '11408-855', 'Centro', 'SP', 'Baleares', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Daniel da Costa', '55319889339', 'daniel.da.costa@email.com', '268.561.349-48', '52.415.832', '1975-08-21', 50, 'Morro de Monteiro, 934', '79798-703', 'Centro', 'MA', 'Rocha de das Neves', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Vicenta Galindo Hurtado', '15706931490', 'vicenta.galindo.hurtado@email.com', '136.392.792-67', '44.145.366', '1992-11-02', 33, 'Via Roque Sotelo 3 Apt. 43 ', '93747-505', 'Centro', 'SP', 'Alicante', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Jacqueline Romero', '54655016707', 'jacqueline.romero@email.com', '991.273.856-98', '37.703.812', '1988-10-30', 37, '79130 Michael Lights Suite 108', '99378-786', 'Centro', 'SP', 'New Mark', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Roberto Martin', '52831552006', 'roberto.martin@email.com', '897.566.816-96', '47.264.998', '1957-09-19', 68, '183 Jennifer Common', '93686-775', 'Centro', 'SP', 'Youngside', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Tiffany Miller', '64676139664', 'tiffany.miller@email.com', '447.597.512-49', '90.261.251', '1968-04-13', 57, '778 Jenkins Burg Suite 115', '84401-569', 'Centro', 'NE', 'Smithland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Salvador Donaire', '60239447869', 'salvador.donaire@email.com', '170.609.590-12', '82.248.871', '2000-11-02', 25, 'Calle de Eladio Zapata 1 Piso 6 ', '96744-731', 'Centro', 'SP', 'Cuenca', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Marina Ibáñez Gaya', '18704186800', 'marina.ibánez.gaya@email.com', '703.550.613-41', '21.714.785', '1978-05-21', 47, 'Pasadizo de Celestina Carlos 46 Puerta 3 ', '69693-858', 'Centro', 'SP', 'Madrid', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Rafaela del Adadia', '44050063129', 'rafaela.del.adadia@email.com', '588.394.556-96', '27.933.248', '2005-03-21', 20, 'Alameda de Omar Salamanca 77', '96962-241', 'Centro', 'SP', 'Granada', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Iván Solís', '81395073173', 'iván.solís@email.com', '277.625.837-90', '21.773.939', '1955-09-05', 70, 'Calle Sinaloa 409 515', '45611-108', 'Centro', 'SLP', 'San Araceli de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Daniela Lima', '55119657542', 'daniela.lima@email.com', '227.105.554-90', '32.691.769', '1960-07-11', 65, 'Lagoa Barros, 46', '44503-643', 'Centro', 'SE', 'Gonçalves de Almeida', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Thomas Kelly', '82347265334', 'thomas.kelly@email.com', '994.851.551-40', '25.655.881', '1978-12-31', 47, '570 Bentley Mall Suite 953', '91562-162', 'Centro', 'SP', 'South Brandonburgh', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'María José Guajardo', '65228388107', 'maría.josé.guajardo@email.com', '604.331.110-57', '77.775.437', '1958-07-30', 67, 'Avenida Suiza 712 Edif. 308 , Depto. 332', '87644-466', 'Centro', 'NL', 'San José María los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Brenda da Cunha', '55719629423', 'brenda.da.cunha@email.com', '351.744.204-76', '55.520.239', '2004-12-08', 21, 'Jardim Raul Porto, 47', '64115-215', 'Centro', 'MG', 'Rezende do Amparo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Luis Manuel Bernardo Collado', '47942372190', 'luis.manuel.bernardo.collado@email.com', '290.159.198-38', '48.760.409', '1981-09-26', 44, 'Andador Iraq 605 Interior 238', '83615-160', 'Centro', 'SON', 'Vieja República Democrática Popular Lao', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Raquel Lemus Montañez', '50178772709', 'raquel.lemus.montanez@email.com', '679.520.928-32', '83.843.863', '1965-04-20', 60, 'Callejón Gurule 867 Interior 865', '99142-901', 'Centro', 'DGO', 'Nueva Qatar', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Buenaventura Costa Baró', '22520995615', 'buenaventura.costa.baró@email.com', '882.187.119-21', '40.926.790', '1992-08-24', 33, 'Pasadizo de Reyes Torre 537 Apt. 13 ', '86297-844', 'Centro', 'SP', 'Melilla', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Leandro Novaes', '55719846552', 'leandro.novaes@email.com', '519.876.249-64', '89.510.365', '1964-02-21', 61, 'Rua Vitor Pires, 5', '44144-374', 'Centro', 'PA', 'Nogueira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Marcela Ramos', '55319800394', 'marcela.ramos@email.com', '364.518.860-55', '21.234.681', '1975-07-01', 50, 'Lagoa Ana Júlia Gonçalves, 8', '37753-330', 'Centro', 'SE', 'Nascimento', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Paco Pombo', '43089335359', 'paco.pombo@email.com', '503.877.606-75', '10.917.441', '1965-07-15', 60, 'Ronda Gerardo Abascal 31 Puerta 3 ', '26067-507', 'Centro', 'SP', 'Toledo', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Traci Robinson MD', '44230505564', 'traci.robinson.md@email.com', '300.171.567-72', '26.779.635', '1984-02-10', 41, '5176 Taylor Station Suite 067', '73643-760', 'Centro', 'SP', 'Josephfurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Nieves Codina Amores', '21163067756', 'nieves.codina.amores@email.com', '120.249.493-38', '33.936.380', '1999-11-01', 26, 'Ronda de Adelia Cortina 71 Piso 5 ', '37837-941', 'Centro', 'SP', 'Navarra', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Rubén Mendoza Montañez', '88565663773', 'rubén.mendoza.montanez@email.com', '223.701.580-54', '33.551.509', '1980-06-23', 45, 'Diagonal Amador 057 Edif. 162 , Depto. 973', '89486-139', 'Centro', 'CHIS', 'San Caridad los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Alexander Copeland', '18476652617', 'alexander.copeland@email.com', '372.552.867-52', '23.748.635', '1967-05-02', 58, '589 Price Villages', '16378-601', 'Centro', 'SP', 'Silvaburgh', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Gala Porcel Losada', '11460256619', 'gala.porcel.losada@email.com', '550.629.401-88', '54.236.435', '1972-03-08', 53, 'C. de Laura Hervás 8 Apt. 25 ', '64998-387', 'Centro', 'SP', 'Murcia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Vanesa Lillo Sanchez', '06074114062', 'vanesa.lillo.sanchez@email.com', '280.813.530-94', '90.196.695', '2004-04-09', 21, 'Via Lázaro Simó 31 Puerta 6 ', '59796-436', 'Centro', 'SP', 'Álava', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Evelyn Oliveira', '55319849319', 'evelyn.oliveira@email.com', '154.162.476-68', '81.529.234', '1978-04-05', 47, 'Rua Igor Farias, 28', '85736-813', 'Centro', 'SP', 'Aragão', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Sr(a). Delia Quiroz', '31742338527', 'sr(a)..delia.quiroz@email.com', '353.571.229-74', '21.611.546', '1984-08-03', 41, 'Continuación Perales 949 Edif. 452 , Depto. 694', '52743-384', 'Centro', 'CHIH', 'San Hugo los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Jennifer Lewis', '12341760752', 'jennifer.lewis@email.com', '381.288.512-23', '32.976.156', '2000-08-31', 25, '25364 Jason Ramp', '87752-895', 'Centro', 'GA', 'East Brianland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Noah Barros', '55849482353', 'noah.barros@email.com', '516.552.690-81', '80.805.548', '1969-05-23', 56, 'Loteamento Vieira, 3', '81155-244', 'Centro', 'RJ', 'Nunes', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Dra. Isis Aragão', '55619484875', 'dra..isis.aragão@email.com', '994.749.957-43', '32.383.149', '1986-08-10', 39, 'Vila Campos, 95', '14223-415', 'Centro', 'RS', 'da Mota do Galho', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Emily Gomez', '98197565641', 'emily.gomez@email.com', '792.403.688-74', '51.972.736', '2004-12-02', 21, '72358 Bailey Junction Apt. 462', '12678-545', 'Centro', 'SP', 'South John', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Ana Sophia da Mota', '55319664021', 'ana.sophia.da.mota@email.com', '181.400.205-21', '43.557.944', '1977-07-26', 48, 'Rua de Lopes, 462', '25832-261', 'Centro', 'MG', 'da Conceição', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Micaela Valverde Padilla', '89719780839', 'micaela.valverde.padilla@email.com', '893.525.441-87', '67.931.389', '2001-12-21', 24, 'Diagonal Olmos 393 912', '90908-212', 'Centro', 'TAB', 'San Gregorio los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Jacinto Lebrón de la Torre', '86347457794', 'jacinto.lebrón.de.la.torre@email.com', '234.781.914-54', '55.550.841', '1956-03-16', 69, 'Andador Marruecos 609 Edif. 798 , Depto. 584', '42495-265', 'Centro', 'VER', 'Vieja Chad', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Austin Roberts', '82457181507', 'austin.roberts@email.com', '814.629.629-42', '50.370.769', '1967-12-25', 58, '05178 Alisha Track', '91447-621', 'Centro', 'SP', 'Hullfurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Jessica Ramirez', '34472253321', 'jessica.ramirez@email.com', '275.396.758-88', '15.423.577', '1971-08-30', 54, '237 Jeffrey Forge', '76248-535', 'Centro', 'VT', 'Smithberg', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Mtro. Ilse Quezada', '99532733542', 'mtro..ilse.quezada@email.com', '808.962.885-43', '78.663.797', '1956-02-01', 69, 'Corredor Colima 933 686', '71948-775', 'Centro', 'GRO', 'San Esperanza los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Ryan Lutz', '00880102537', 'ryan.lutz@email.com', '890.632.368-33', '61.577.196', '1980-04-14', 45, '36979 Hensley Valleys Apt. 360', '39568-789', 'Centro', 'CT', 'Brianburgh', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Luiz Fernando Fogaça', '55119796371', 'luiz.fernando.fogaça@email.com', '364.573.145-65', '89.502.513', '1972-07-13', 53, 'Residencial de Correia', '59709-222', 'Centro', 'RJ', 'Castro', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Dr. Patricio García', '76263884984', 'dr..patricio.garcía@email.com', '411.119.479-84', '81.783.170', '1997-12-29', 28, 'Avenida Norte Urbina 923 Interior 960', '63252-460', 'Centro', 'Q. ROO', 'Vieja República de Corea', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Magdalena Marisela Concepción', '00347152617', 'magdalena.marisela.concepción@email.com', '680.321.397-17', '78.929.522', '1985-03-03', 40, 'Calzada Morelos 566 165', '42965-996', 'Centro', 'COL', 'San Daniela los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Sarah Rodrigues', '55519596002', 'sarah.rodrigues@email.com', '971.777.815-29', '96.431.295', '1968-12-12', 57, 'Conjunto Freitas', '31892-999', 'Centro', 'AL', 'Nascimento', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Linda Hahn', '90781580996', 'linda.hahn@email.com', '433.242.366-16', '42.581.733', '1979-09-26', 46, '128 Tiffany Forest Apt. 195', '86948-756', 'Centro', 'SP', 'South Dominiquemouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Claudia Bustamante Escalante', '70949822931', 'claudia.bustamante.escalante@email.com', '110.611.635-77', '37.621.229', '1978-01-03', 47, 'Corredor Arce 070 114', '54823-285', 'Centro', 'CHIS', 'Nueva Namibia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Dakota Walker', '89922910169', 'dakota.walker@email.com', '519.605.585-52', '76.541.388', '1973-02-18', 52, '88266 Harris Well Suite 784', '18165-947', 'Centro', 'KS', 'Port Derek', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Erick Silveira', '55219603651', 'erick.silveira@email.com', '644.428.185-22', '53.919.174', '1963-06-23', 62, 'Jardim de da Mota, 1', '47025-150', 'Centro', 'RO', 'Castro da Mata', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Arcelia Camacho Arjona', '87481135979', 'arcelia.camacho.arjona@email.com', '174.677.359-74', '22.110.630', '1994-02-17', 31, 'Alameda Atilio Cantero 98', '23187-571', 'Centro', 'SP', 'Alicante', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Luiz Felipe Gomes', '55519845648', 'luiz.felipe.gomes@email.com', '918.221.247-32', '79.664.544', '1978-10-14', 47, 'Colônia Cunha, 51', '81407-302', 'Centro', 'MT', 'Moreira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Henry Dominguez', '40891600327', 'henry.dominguez@email.com', '943.195.411-82', '50.666.667', '2000-12-23', 25, '45643 Douglas Island', '20862-190', 'Centro', 'NJ', 'Horneshire', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Austin Rogers', '64492820127', 'austin.rogers@email.com', '204.246.696-68', '42.277.762', '1968-08-10', 57, '947 Carla Knolls Apt. 441', '81811-451', 'Centro', 'MN', 'Sarahview', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Bianca da Cunha', '55319218295', 'bianca.da.cunha@email.com', '761.473.809-14', '60.289.940', '2005-04-03', 20, 'Morro de Oliveira, 70', '78959-707', 'Centro', 'RN', 'Cunha das Flores', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Justin Alexander', '23925492039', 'justin.alexander@email.com', '312.985.348-48', '70.515.359', '1956-06-20', 69, '01603 Christopher Heights Apt. 150', '66757-733', 'Centro', 'AR', 'Port Stephenberg', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Sr. Antônio da Rocha', '55119058456', 'sr..antônio.da.rocha@email.com', '980.700.326-64', '98.584.919', '1955-03-02', 70, 'Distrito Joaquim Rodrigues', '72165-619', 'Centro', 'RJ', 'da Conceição', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Steven Wilson', '58474921461', 'steven.wilson@email.com', '236.651.608-93', '82.229.101', '1991-12-03', 34, '29802 Poole Neck Suite 265', '74248-329', 'Centro', 'OH', 'South Brenda', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Ian Costela', '55719946125', 'ian.costela@email.com', '259.206.279-88', '46.691.474', '1998-04-03', 27, 'Aeroporto Ana Vitória Pinto, 15', '29508-533', 'Centro', 'SC', 'Correia de Azevedo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Fernando Cunha', '55619735494', 'fernando.cunha@email.com', '295.387.493-20', '92.982.944', '1979-02-18', 46, 'Área Nascimento, 15', '23975-903', 'Centro', 'AP', 'Costa', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'María del Carmen Darío Romo Sisneros', '68150984044', 'maría.del.carmen.darío.romo.sisneros@email.com', '972.773.678-40', '38.570.376', '1999-04-24', 26, 'Calle Nayarit 980 272', '37427-578', 'Centro', 'NAY', 'San Horacio de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Cauê Moreira', '55419201308', 'cauê.moreira@email.com', '228.231.187-47', '87.922.263', '1963-06-20', 62, 'Passarela da Rocha, 86', '59883-605', 'Centro', 'RR', 'Costa das Flores', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Fernando Elvia Guzmán Tovar', '91562827310', 'fernando.elvia.guzmán.tovar@email.com', '522.871.626-76', '93.139.328', '2005-07-25', 20, 'Ampliación Chiapas 368 Interior 151', '13157-171', 'Centro', 'MICH', 'San Eloisa los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Erin Reyes', '60326227116', 'erin.reyes@email.com', '339.167.171-95', '19.390.446', '1969-10-31', 56, '8071 Peter Estates Suite 301', '52394-127', 'Centro', 'PA', 'Monroeton', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Shannon Hudson', '93002102241', 'shannon.hudson@email.com', '916.972.374-88', '65.445.651', '1983-06-14', 42, '04084 Hardy Causeway', '72617-175', 'Centro', 'IA', 'Hannahshire', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Julio César Peñalver Chaparro', '10084666591', 'julio.césar.penalver.chaparro@email.com', '720.868.614-64', '22.229.233', '1957-09-16', 68, 'Urbanización de Calisto Gonzalo 474 Puerta 2 ', '33945-237', 'Centro', 'SP', 'Álava', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Brígida del Ibarra', '21244681360', 'brígida.del.ibarra@email.com', '501.676.839-58', '57.981.838', '1967-07-05', 58, 'Pasaje Cirino Hervia 3 Apt. 64 ', '71398-911', 'Centro', 'SP', 'Valencia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Abraham Cavazos', '58437059868', 'abraham.cavazos@email.com', '223.235.386-11', '41.467.737', '1957-04-08', 68, 'Andador Jalisco 860 Interior 876', '42036-640', 'Centro', 'YUC', 'Nueva Trinidad y Tabago', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Teresa Whitaker', '37427520881', 'teresa.whitaker@email.com', '706.743.764-91', '70.963.782', '1975-04-27', 50, '7314 Gregory Ports', '41486-654', 'Centro', 'SP', 'Andrewshire', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Lisa Martinez', '93801015622', 'lisa.martinez@email.com', '465.627.731-13', '85.606.309', '1994-12-29', 31, '18710 Kenneth Prairie Apt. 446', '92598-407', 'Centro', 'OH', 'Johnsonmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Scott Baker', '47027661786', 'scott.baker@email.com', '184.689.443-63', '19.382.392', '1988-07-18', 37, '4378 Green Cove', '76348-548', 'Centro', 'SP', 'West Robert', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Richard Warren', '90371581444', 'richard.warren@email.com', '542.491.387-93', '42.849.298', '1981-11-20', 44, '152 Barker Parks', '45871-213', 'Centro', 'SP', 'North Jeremychester', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Sol del Castilla', '38727822212', 'sol.del.castilla@email.com', '529.538.774-85', '46.620.306', '2004-09-24', 21, 'C. de Ángel Rojas 15 Apt. 60 ', '72477-940', 'Centro', 'SP', 'Ciudad', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Eric Mitchell', '32802087463', 'eric.mitchell@email.com', '860.693.606-84', '11.232.816', '1987-07-01', 38, '5807 Kirby Hill Suite 082', '94673-105', 'Centro', 'SP', 'Gillview', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Cynthia Fisher', '56999722562', 'cynthia.fisher@email.com', '828.193.126-60', '22.698.269', '1989-02-16', 36, '517 Stafford Spring', '91104-598', 'Centro', 'SP', 'Glassmouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Michael Brown', '67601848125', 'michael.brown@email.com', '464.968.410-74', '41.460.686', '1962-05-14', 63, '38564 Amanda Landing', '49717-357', 'Centro', 'SP', 'Walkerburgh', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Enzo Gabriel Silveira', '55219336597', 'enzo.gabriel.silveira@email.com', '862.800.350-53', '75.604.247', '1976-09-02', 49, 'Parque de Rocha, 198', '27617-227', 'Centro', 'PI', 'Cardoso do Oeste', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Sra. Maria Alice Cardoso', '55619471619', 'sra..maria.alice.cardoso@email.com', '336.992.972-21', '88.556.575', '1966-01-22', 59, 'Sítio Correia, 74', '85536-235', 'Centro', 'AL', 'Rocha de Minas', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Jeffrey Smith', '50903379942', 'jeffrey.smith@email.com', '943.430.634-42', '95.465.818', '1994-01-28', 31, '58397 Guerrero Harbors Suite 386', '10643-948', 'Centro', 'SP', 'Fordchester', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Lisa Ramirez', '28278863282', 'lisa.ramirez@email.com', '968.704.212-97', '81.370.237', '1988-09-03', 37, '37035 Cynthia Manors', '23714-158', 'Centro', 'SP', 'West Yolanda', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Liliana Acuña', '20940397159', 'liliana.acuna@email.com', '721.113.774-70', '43.389.155', '2005-01-05', 20, 'Plaza Olegario Blanch 7', '25661-994', 'Centro', 'SP', 'Navarra', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Sean Smith', '08315447326', 'sean.smith@email.com', '283.475.264-18', '74.476.245', '1961-03-15', 64, '86967 Keller Island', '96118-506', 'Centro', 'SP', 'Port Christopherberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Evaristo Montalbán Orozco', '07409600701', 'evaristo.montalbán.orozco@email.com', '790.758.447-90', '60.671.523', '1967-03-09', 58, 'Camino José Ángel Boix 44 Piso 8 ', '42021-189', 'Centro', 'SP', 'Soria', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Dr. Yago Moura', '55119569040', 'dr..yago.moura@email.com', '405.552.154-54', '14.825.107', '2000-09-30', 25, 'Área de Santos, 60', '45601-585', 'Centro', 'AL', 'Araújo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Lic. Carolina Bétancourt', '83480625892', 'lic..carolina.bétancourt@email.com', '802.257.815-54', '89.594.220', '1982-12-08', 43, 'Corredor Baja California Sur 067 Edif. 940 , Depto. 114', '79184-138', 'Centro', 'YUC', 'San Flavio de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'William Pearson', '09279715878', 'william.pearson@email.com', '246.553.347-60', '61.737.474', '2001-01-05', 24, '5475 Phillips Summit', '34027-249', 'Centro', 'NV', 'Lake Phyllis', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Pepe Terrón', '30303608572', 'pepe.terrón@email.com', '508.944.754-63', '86.597.502', '1957-08-29', 68, 'Paseo Belén Bravo 70 Puerta 4 ', '78890-665', 'Centro', 'SP', 'Santa Cruz de Tenerife', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Carolyn Villanueva', '58868463153', 'carolyn.villanueva@email.com', '956.620.227-53', '89.926.128', '1996-12-06', 29, '44333 White Pass Suite 531', '36791-333', 'Centro', 'CO', 'Valdezmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Bradley Daniels', '63333065037', 'bradley.daniels@email.com', '519.613.379-32', '86.104.463', '1982-12-11', 43, '223 Douglas Path Apt. 640', '36573-574', 'Centro', 'VA', 'Amandaport', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Brittany Noble', '92758142346', 'brittany.noble@email.com', '663.602.407-58', '37.555.716', '1969-08-25', 56, '4946 Morales Trail', '64976-768', 'Centro', 'SP', 'East Sethmouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Concepción Portillo', '79236836089', 'concepción.portillo@email.com', '811.131.489-32', '85.191.400', '1960-03-24', 65, 'Circuito de la Crúz 286 912', '44679-675', 'Centro', 'DF', 'San Ariadna los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Joseph Wilson', '30739447692', 'joseph.wilson@email.com', '847.841.833-94', '42.246.389', '1985-06-30', 40, '749 Hughes Inlet', '67964-608', 'Centro', 'SP', 'Port Brianshire', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Saturnina Luna', '36677693645', 'saturnina.luna@email.com', '398.464.550-17', '98.941.663', '1974-12-27', 51, 'Camino Renato Alsina 44', '59299-707', 'Centro', 'SP', 'Las Palmas', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Dr. Juan Velázquez', '42198705735', 'dr..juan.velázquez@email.com', '717.963.448-51', '72.745.825', '1955-11-25', 70, 'Peatonal Almaraz 376 Edif. 593 , Depto. 837', '47585-932', 'Centro', 'JAL', 'San Ramón de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Benigna Romeu Bou', '87323099914', 'benigna.romeu.bou@email.com', '315.138.119-33', '13.429.128', '1974-05-08', 51, 'Plaza Pastor Miguel 7 Apt. 15 ', '36502-485', 'Centro', 'SP', 'Pontevedra', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Jennifer Beck', '79667817197', 'jennifer.beck@email.com', '648.655.264-17', '12.361.536', '1972-02-06', 53, '824 Wright Common', '37363-732', 'Centro', 'SP', 'Baileybury', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Brenda Sanchez', '73713119986', 'brenda.sanchez@email.com', '122.883.875-69', '92.220.275', '1974-01-19', 51, '369 Timothy Path', '67858-234', 'Centro', 'SP', 'Port Tanyahaven', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Etelvina Apolonia Peinado Herrero', '62990903331', 'etelvina.apolonia.peinado.herrero@email.com', '552.951.349-84', '81.944.947', '1956-07-12', 69, 'Vial Nadia Galiano 98', '79288-506', 'Centro', 'SP', 'Ciudad', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Melissa Lang', '71669448669', 'melissa.lang@email.com', '665.979.533-80', '94.778.108', '1988-04-18', 37, '1232 Summers Crest', '84223-147', 'Centro', 'SP', 'Thomastown', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Ofelia Ariza Cuevas', '77399328657', 'ofelia.ariza.cuevas@email.com', '836.268.502-39', '14.683.590', '2006-05-08', 19, 'Alameda Jaime Roda 51 Apt. 03 ', '54802-266', 'Centro', 'SP', 'Vizcaya', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Kevin Costela', '55119960162', 'kevin.costela@email.com', '288.211.889-27', '78.969.232', '1980-11-22', 45, 'Feira Renan Rocha, 506', '68424-852', 'Centro', 'AL', 'da Rocha das Flores', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Daniel Williams', '12608222860', 'daniel.williams@email.com', '345.966.864-20', '77.448.681', '1970-11-25', 55, '425 Laura Lane Apt. 993', '57200-966', 'Centro', 'SP', 'West Ronald', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Joe Salas', '21585872659', 'joe.salas@email.com', '885.459.532-80', '99.957.197', '1996-05-30', 29, '71551 Blevins Bypass Suite 078', '65675-911', 'Centro', 'WV', 'Andersonburgh', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Krista Spears', '50633000181', 'krista.spears@email.com', '510.223.951-17', '94.412.638', '2003-07-19', 22, '529 Becker Spur', '44441-393', 'Centro', 'KY', 'Davisland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Rodrigo Gabriela Cardenas', '76143031134', 'rodrigo.gabriela.cardenas@email.com', '858.286.827-77', '23.837.297', '1980-09-19', 45, 'Calle Yucatán 951 Edif. 472 , Depto. 293', '40671-163', 'Centro', 'OAX', 'San Francisco Javier los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Darío Raúl Espino Castillo', '72653976135', 'darío.raúl.espino.castillo@email.com', '303.533.824-39', '62.955.913', '1987-05-13', 38, 'Calle Ceja 058 Interior 719', '96178-752', 'Centro', 'MICH', 'Nueva Arabia Saudita', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Noah da Conceição', '55319116598', 'noah.da.conceição@email.com', '129.973.353-22', '73.370.401', '1956-05-18', 69, 'Lagoa de Silva, 81', '96613-357', 'Centro', 'PB', 'Azevedo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Mr. Eric Sosa', '63289499770', 'mr..eric.sosa@email.com', '316.168.192-77', '70.916.865', '1968-10-12', 57, '11157 Mckinney Fort', '49465-751', 'Centro', 'SP', 'Port Michael', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Lara Rodrigues', '55319984637', 'lara.rodrigues@email.com', '599.129.777-55', '51.189.360', '1961-12-24', 64, 'Estação de Pereira, 919', '98653-601', 'Centro', 'AP', 'Nogueira Paulista', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'María Cristina Sanchez-Cárdenas', '16461556222', 'maría.cristina.sanchez-cárdenas@email.com', '500.450.979-16', '57.226.322', '1989-12-29', 36, 'Cañada Águeda Bayón 78 Apt. 15 ', '76189-907', 'Centro', 'SP', 'Segovia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Crystal Smith', '86056693705', 'crystal.smith@email.com', '593.882.221-86', '52.130.441', '1986-03-12', 39, '2310 Scott Point Apt. 259', '43020-420', 'Centro', 'IL', 'Leeville', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Leonardo Lopes', '55719363552', 'leonardo.lopes@email.com', '567.984.920-15', '80.300.489', '1997-06-11', 28, 'Rua Isabella da Costa', '35950-107', 'Centro', 'PR', 'Peixoto', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Yasmin Dias', '55219601163', 'yasmin.dias@email.com', '821.817.285-66', '27.372.816', '1996-06-11', 29, 'Parque de Freitas', '53459-461', 'Centro', 'RR', 'Barbosa do Amparo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Joaquim Gomes', '55119070271', 'joaquim.gomes@email.com', '318.189.982-44', '68.136.179', '1988-05-16', 37, 'Vale de Barros, 71', '55987-657', 'Centro', 'GO', 'Alves Alegre', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Jeffrey Bailey', '75725386051', 'jeffrey.bailey@email.com', '518.458.838-18', '84.548.642', '1960-01-21', 65, '5698 Angela Avenue Apt. 752', '97783-921', 'Centro', 'SP', 'Boothport', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Zaida del Rivera', '33637885962', 'zaida.del.rivera@email.com', '378.919.315-39', '59.774.775', '1973-11-28', 52, 'Callejón de Luisa Osorio 19', '13197-997', 'Centro', 'SP', 'Santa Cruz de Tenerife', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Kim Brown', '21599618558', 'kim.brown@email.com', '740.924.903-89', '15.861.147', '2002-03-10', 23, '33424 Lindsey Courts Apt. 121', '24219-431', 'Centro', 'AK', 'South Donnaville', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Mr. Nicholas Brown', '19035040685', 'mr..nicholas.brown@email.com', '408.273.637-47', '63.294.749', '1992-10-12', 33, '11815 Reyes Street', '51321-382', 'Centro', 'SP', 'Yodermouth', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Erin Jackson', '48096573405', 'erin.jackson@email.com', '351.699.698-83', '77.949.923', '1969-12-22', 56, '5494 Arnold Manors Apt. 757', '12564-923', 'Centro', 'VA', 'Andrewport', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Destiny Mcgee MD', '74140495598', 'destiny.mcgee.md@email.com', '239.401.822-79', '35.604.210', '1970-11-20', 55, '6753 Kelly Cliff Suite 367', '97578-357', 'Centro', 'SP', 'East Nicole', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Dawn Lee', '98389908539', 'dawn.lee@email.com', '860.349.731-62', '67.478.317', '2005-10-05', 20, '5233 Stephen Island Suite 811', '97514-282', 'Centro', 'SP', 'East Thomas', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Fausto Álvaro Pina', '68054677854', 'fausto.álvaro.pina@email.com', '906.624.842-69', '22.458.313', '1960-01-03', 65, 'Via de Leonel Cruz 52 Puerta 0 ', '27076-824', 'Centro', 'SP', 'Toledo', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Dr. Thomas Cunha', '55619361128', 'dr..thomas.cunha@email.com', '820.725.301-30', '74.930.717', '1990-04-03', 35, 'Núcleo Pedro Lucas Castro, 36', '91152-976', 'Centro', 'PE', 'Silveira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Cynthia Adalberto Delgadillo', '30615962583', 'cynthia.adalberto.delgadillo@email.com', '611.919.914-22', '16.810.885', '1969-08-02', 56, 'Ampliación Aguascalientes 445 Edif. 914 , Depto. 664', '37324-216', 'Centro', 'NL', 'San Darío de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Manuel Judith Sanabria', '22237928668', 'manuel.judith.sanabria@email.com', '418.188.925-62', '44.614.347', '2000-10-11', 25, 'Periférico Norte Hurtado 859 Interior 386', '16083-414', 'Centro', 'NAY', 'Vieja Côte dIvoire', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Ángel Mariana Márquez', '08876544640', 'ángel.mariana.márquez@email.com', '976.696.188-20', '60.328.615', '1997-08-20', 28, 'Circuito Guajardo 588 456', '34079-333', 'Centro', 'COAH', 'Nueva Mauritania', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Evelia Gallardo Alegre', '17810240121', 'evelia.gallardo.alegre@email.com', '984.198.935-41', '29.117.806', '1961-01-28', 64, 'Ronda Macarena Buendía 97', '89166-140', 'Centro', 'SP', 'Murcia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'André Souza', '55719860070', 'andré.souza@email.com', '202.759.785-27', '48.849.125', '1963-07-08', 62, 'Morro Joaquim Jesus, 82', '36832-890', 'Centro', 'AM', 'Peixoto', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Srta. Emanuelly Moura', '55819222334', 'srta..emanuelly.moura@email.com', '290.867.505-91', '46.969.253', '1983-04-24', 42, 'Lagoa de Aragão', '79214-380', 'Centro', 'BA', 'Lopes', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Amy Ferguson', '73838405402', 'amy.ferguson@email.com', '358.649.161-79', '80.938.762', '1967-06-07', 58, '5303 Cooper Glen Apt. 622', '16376-722', 'Centro', 'SP', 'Natalieland', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Stephany Cardoso', '55619492272', 'stephany.cardoso@email.com', '990.232.513-53', '16.756.135', '1977-08-10', 48, 'Praça Evelyn Martins, 34', '89765-513', 'Centro', 'MG', 'Araújo', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Estela Leyva Tafoya', '57198190055', 'estela.leyva.tafoya@email.com', '686.431.714-73', '11.415.527', '1970-08-12', 55, 'Callejón Botswana 139 Interior 886', '55853-164', 'Centro', 'MEX', 'San Joaquín de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Oswaldo Zedillo', '70013012032', 'oswaldo.zedillo@email.com', '779.550.661-52', '33.707.396', '1974-09-17', 51, 'Calzada Norte Benavídez 189 Edif. 738 , Depto. 404', '61937-975', 'Centro', 'COAH', 'San Paulina de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Patrick Whitaker', '62796285567', 'patrick.whitaker@email.com', '337.570.820-74', '26.307.986', '1967-04-26', 58, '6087 Walters Station Suite 616', '77231-804', 'Centro', 'ND', 'East Georgebury', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Ivonne Asunción Cordero Montaño', '51784110561', 'ivonne.asunción.cordero.montano@email.com', '581.227.584-12', '43.607.449', '1988-07-12', 37, 'Avenida Santo Tomé y Príncipe 409 Edif. 612 , Depto. 138', '77053-362', 'Centro', 'BC', 'Nueva Myanmar', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Sarah Price', '89722183807', 'sarah.price@email.com', '237.342.262-42', '42.780.946', '1994-05-11', 31, '25677 Michael Village Apt. 732', '94746-331', 'Centro', 'NH', 'Erinhaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Isaac Martins', '55849693840', 'isaac.martins@email.com', '100.115.309-73', '23.811.654', '1996-02-04', 29, 'Parque Nogueira, 15', '23037-646', 'Centro', 'DF', 'Carvalho', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Travis Wong', '70085443852', 'travis.wong@email.com', '427.579.701-33', '96.791.718', '1961-03-15', 64, '834 Joan Rue', '95412-685', 'Centro', 'ID', 'Kyleland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Elizabeth Savage', '61886161271', 'elizabeth.savage@email.com', '495.462.197-51', '54.488.909', '1987-01-16', 38, '822 Edward Villages', '83178-309', 'Centro', 'SP', 'West Lisaberg', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Aida Ulloa', '92913517055', 'aida.ulloa@email.com', '412.243.711-25', '59.312.536', '1981-07-04', 44, 'Continuación Kuwait 322 Edif. 779 , Depto. 396', '44991-442', 'Centro', 'TAMPS', 'San Rosario los altos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Brianna Jones', '40320672271', 'brianna.jones@email.com', '588.849.360-78', '17.867.958', '1957-08-31', 68, '975 James Corner', '58092-232', 'Centro', 'IL', 'Andreaport', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Lorenzo Fogaça', '55219054576', 'lorenzo.fogaça@email.com', '401.932.916-55', '83.980.873', '1986-11-22', 39, 'Conjunto Silva, 14', '14771-840', 'Centro', 'RR', 'Mendes Verde', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Jacob Thompson', '16083670569', 'jacob.thompson@email.com', '797.829.130-49', '91.271.108', '2001-06-10', 24, '572 Arnold Summit', '65076-238', 'Centro', 'MD', 'West Nathanhaven', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Eloah Santos', '55849990421', 'eloah.santos@email.com', '655.235.284-33', '18.737.773', '1963-11-13', 62, 'Rua de da Paz, 719', '93770-262', 'Centro', 'DF', 'Moreira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Bruno Barros', '55319547806', 'bruno.barros@email.com', '269.240.109-14', '57.907.614', '1966-05-17', 59, 'Chácara de Mendes, 2', '12514-675', 'Centro', 'RR', 'da Rosa do Galho', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Salud del Otero', '39762533402', 'salud.del.otero@email.com', '975.353.907-46', '28.829.398', '1966-10-17', 59, 'Rambla de Agapito Mosquera 23', '25494-292', 'Centro', 'SP', 'Guipúzcoa', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Elena Dalia Garay Prado', '33901976425', 'elena.dalia.garay.prado@email.com', '694.709.586-49', '40.215.882', '2000-05-05', 25, 'Eje vial Gil 265 Edif. 066 , Depto. 273', '50502-615', 'Centro', 'DF', 'San José Luis de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Mamen Perales-Paredes', '43652916703', 'mamen.perales-paredes@email.com', '165.809.212-92', '17.411.832', '1984-10-14', 41, 'Ronda de Plácido Montesinos 424 Puerta 0 ', '29999-328', 'Centro', 'SP', 'Jaén', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Joseph Ayala', '12367327450', 'joseph.ayala@email.com', '357.669.598-19', '76.663.647', '1985-04-29', 40, '739 Brown Ridge', '28140-447', 'Centro', 'SP', 'Jonesfurt', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Helena Alves', '55819953281', 'helena.alves@email.com', '599.636.652-26', '24.485.119', '2003-04-22', 22, 'Praia Ribeiro, 5', '19304-297', 'Centro', 'PE', 'Rodrigues de Jesus', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Ana Luisa Daniela Yáñez', '16536853179', 'ana.luisa.daniela.yánez@email.com', '594.260.521-44', '24.684.100', '1994-06-21', 31, 'Viaducto Norte Briones 175 Edif. 579 , Depto. 034', '58924-360', 'Centro', 'ZAC', 'San Pedro los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Marta Duque Almeida', '78561899894', 'marta.duque.almeida@email.com', '553.885.164-45', '75.251.579', '1961-11-04', 64, 'C. Juan Carlos Flor 5', '83531-450', 'Centro', 'SP', 'Cuenca', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Renato Martín Carranza', '93105562110', 'renato.martín.carranza@email.com', '666.841.727-60', '47.562.831', '1977-06-21', 48, 'Callejón de Nazaret Cortina 6', '52733-712', 'Centro', 'SP', 'Soria', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Robert Webster', '73116404657', 'robert.webster@email.com', '469.265.284-47', '69.111.941', '1970-12-29', 55, '3196 Lisa Drives Apt. 978', '41648-118', 'Centro', 'SP', 'Shariport', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Rocío Vera', '05447900120', 'rocío.vera@email.com', '435.173.728-37', '52.355.958', '1960-01-22', 65, 'Corredor Norte Muñoz 490 559', '36796-852', 'Centro', 'PUE', 'San Trinidad los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Alexia Moraes', '55519535054', 'alexia.moraes@email.com', '842.534.514-96', '27.487.564', '1980-02-02', 45, 'Núcleo da Cruz, 4', '91060-493', 'Centro', 'CE', 'Porto', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Pánfilo Casanova Cabeza', '66040757020', 'pánfilo.casanova.cabeza@email.com', '281.763.165-87', '95.216.591', '2002-03-14', 23, 'Glorieta de Edmundo Segovia 94', '95364-701', 'Centro', 'SP', 'Granada', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Wesley Dyer', '98025131674', 'wesley.dyer@email.com', '819.539.544-66', '97.840.448', '2005-12-13', 20, '567 Hodge Court', '78666-269', 'Centro', 'WV', 'Reidborough', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Audrey Clark', '56241120967', 'audrey.clark@email.com', '585.426.627-35', '63.295.319', '1970-03-27', 55, '032 Julia Coves Apt. 590', '77329-187', 'Centro', 'NC', 'Karenborough', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Charles Nelson', '62272314889', 'charles.nelson@email.com', '503.725.781-87', '47.526.469', '1993-02-15', 32, '26357 John Trafficway Suite 708', '90695-441', 'Centro', 'DE', 'North Ashley', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Dra. Fernanda Azevedo', '55219492053', 'dra..fernanda.azevedo@email.com', '474.744.769-86', '82.685.659', '1982-09-02', 43, 'Ladeira de da Paz, 34', '53585-121', 'Centro', 'PE', 'da Rosa', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Kevin Brown', '73253840500', 'kevin.brown@email.com', '159.249.183-71', '12.576.453', '2002-12-18', 23, '499 Miller Oval Suite 595', '86974-876', 'Centro', 'SP', 'North Haley', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Linda Amaya Sosa', '91857026818', 'linda.amaya.sosa@email.com', '471.535.775-77', '18.533.374', '1977-03-26', 48, 'Ampliación Zacatecas 492 Interior 052', '58591-216', 'Centro', 'NAY', 'Vieja Federación de Rusia', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'María Dolores Verdejo Fiol', '47031738888', 'maría.dolores.verdejo.fiol@email.com', '224.631.941-11', '91.284.846', '2005-12-11', 20, 'Acceso Rodolfo Maza 57', '13700-323', 'Centro', 'SP', 'Álava', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Rhonda Martin', '82569451362', 'rhonda.martin@email.com', '411.409.265-92', '39.876.352', '1972-12-28', 53, '475 Rodriguez Port Suite 025', '72156-983', 'Centro', 'IN', 'Jordanmouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Juan Estela Hurtado Rosado', '92505185105', 'juan.estela.hurtado.rosado@email.com', '234.706.446-76', '19.100.980', '1989-11-29', 36, 'Circuito Sonora 536 Edif. 389 , Depto. 181', '44890-665', 'Centro', 'VER', 'San Angélica de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL08', 'Isidoro Elías Milla', '53323288663', 'isidoro.elías.milla@email.com', '344.954.898-24', '18.981.636', '2005-03-26', 20, 'Plaza Rosendo Cordero 63 Apt. 61 ', '14879-944', 'Centro', 'SP', 'Las Palmas', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Sara Austin', '92125986623', 'sara.austin@email.com', '641.307.833-37', '95.670.919', '1989-02-03', 36, '93844 Lee Fall', '97512-141', 'Centro', 'SP', 'Salasshire', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Steven Boyd', '54689875602', 'steven.boyd@email.com', '827.236.209-81', '68.209.179', '2005-12-11', 20, '6730 Guerra Road', '39822-697', 'Centro', 'SP', 'North Ashleyville', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Pedro Rosalia Camacho Escamilla', '25331008924', 'pedro.rosalia.camacho.escamilla@email.com', '612.478.858-12', '26.428.334', '1994-03-08', 31, 'Continuación Nieves 387 223', '90578-444', 'Centro', 'ZAC', 'Vieja Comoras', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL04', 'Diana Mcneil', '56110383720', 'diana.mcneil@email.com', '204.567.773-57', '33.683.573', '1969-02-23', 56, '116 Gonzalez Lake', '42288-130', 'Centro', 'SP', 'East Sarah', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Anthony Burgess', '09681281884', 'anthony.burgess@email.com', '124.363.678-31', '77.605.893', '1955-03-02', 70, '68675 Hill Points Apt. 787', '37969-231', 'Centro', 'SP', 'Griffithstad', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Gary Baker', '70114364227', 'gary.baker@email.com', '161.308.476-98', '34.622.360', '1979-07-15', 46, '007 Marisa Trail Suite 663', '96655-788', 'Centro', 'NM', 'North Lisashire', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Natalio Pereira Baquero', '45744361336', 'natalio.pereira.baquero@email.com', '711.955.528-97', '40.304.218', '1969-03-17', 56, 'Callejón de Santiago Prats 93', '92576-597', 'Centro', 'SP', 'Melilla', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Tiffany Robinson', '07343438600', 'tiffany.robinson@email.com', '729.351.897-11', '55.695.538', '2003-11-18', 22, '1058 Donovan Coves', '16655-898', 'Centro', 'SP', 'Port Katherine', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Gerónimo Solsona', '14326404310', 'gerónimo.solsona@email.com', '121.111.701-44', '42.690.839', '1959-02-15', 66, 'Via de Artemio Cabanillas 1 Apt. 46 ', '43324-107', 'Centro', 'SP', 'Palencia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL09', 'Clara Espinal Navarro', '97831473088', 'clara.espinal.navarro@email.com', '136.549.982-71', '37.455.292', '1965-03-11', 60, 'Andador Sur Quiñones 623 Edif. 116 , Depto. 094', '31228-730', 'Centro', 'TLAX', 'Vieja Kazajstán', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Pamela Viera Jaimes', '13347168050', 'pamela.viera.jaimes@email.com', '303.748.163-77', '96.367.912', '1980-01-25', 45, 'Eje vial Norte Mares 635 Interior 384', '78262-851', 'Centro', 'SLP', 'San Daniela los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Beverly Brown', '50818985456', 'beverly.brown@email.com', '262.311.928-44', '27.406.299', '1980-05-26', 45, '82204 Walker Fork Apt. 010', '35094-272', 'Centro', 'SP', 'South Joyce', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Alcides Borrás Cepeda', '25437063181', 'alcides.borrás.cepeda@email.com', '186.243.320-35', '48.503.614', '1974-10-19', 51, 'Acceso de Marcia Sáenz 869', '32470-208', 'Centro', 'SP', 'Granada', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Jeffery Chavez', '57419399639', 'jeffery.chavez@email.com', '110.719.188-84', '81.856.635', '1988-01-01', 37, '5223 Pierce Shores', '65884-593', 'Centro', 'ND', 'Steventown', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Kara Hoover', '06181104993', 'kara.hoover@email.com', '206.291.275-22', '71.981.423', '1970-08-20', 55, '63774 Schneider Keys Apt. 097', '97871-620', 'Centro', 'SP', 'Lake John', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Nathan Carter', '87194637317', 'nathan.carter@email.com', '805.954.483-76', '76.989.553', '1999-05-02', 26, '7086 Mitchell Ville', '19227-676', 'Centro', 'IN', 'East Kevin', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Scott Bernard', '63913684925', 'scott.bernard@email.com', '517.975.925-12', '18.782.354', '1996-06-22', 29, '2464 Audrey Ports', '59945-134', 'Centro', 'SP', 'Wilcoxborough', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Audrey Combs', '24446382312', 'audrey.combs@email.com', '924.664.608-23', '90.967.722', '1979-01-21', 46, '467 Victoria Lock Suite 861', '87442-763', 'Centro', 'SP', 'New Gregoryburgh', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Paulo das Neves', '55619829968', 'paulo.das.neves@email.com', '305.930.251-42', '81.837.918', '1971-04-20', 54, 'Rodovia da Rocha, 495', '62772-209', 'Centro', 'AM', 'Silveira', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Eugenio de Luján', '23737119876', 'eugenio.de.luján@email.com', '591.689.443-78', '90.691.540', '1991-03-09', 34, 'Cañada de Amarilis Moles 82 Piso 6 ', '79676-633', 'Centro', 'SP', 'Valladolid', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Alexia Farias', '55419535371', 'alexia.farias@email.com', '516.577.487-43', '54.899.406', '1995-07-21', 30, 'Loteamento João Guilherme Sales, 6', '68742-787', 'Centro', 'AM', 'Lima', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Jill Daugherty', '60529652552', 'jill.daugherty@email.com', '499.319.284-26', '64.650.563', '2000-05-08', 25, '152 Jacobs Village Suite 338', '14589-158', 'Centro', 'SP', 'Port Ariel', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Abelardo Adán Ruelas', '43275754813', 'abelardo.adán.ruelas@email.com', '264.166.345-25', '66.101.897', '1963-10-03', 62, 'Ampliación Norte Pineda 823 Interior 841', '63794-375', 'Centro', 'NL', 'San Marisela de la Montaña', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL19', 'Clarice Sales', '55219826176', 'clarice.sales@email.com', '589.637.502-10', '65.651.525', '1973-06-01', 52, 'Lago de Campos, 46', '84170-826', 'Centro', 'BA', 'Santos de Goiás', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL01', 'Pepito del Cerro', '44990543068', 'pepito.del.cerro@email.com', '818.559.785-97', '78.323.741', '1999-03-13', 26, 'Camino David Rocha 53', '45200-799', 'Centro', 'SP', 'Ávila', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Haley Cain', '95745414623', 'haley.cain@email.com', '101.811.226-44', '71.351.508', '2007-07-25', 18, '83123 Nancy Expressway Apt. 642', '20259-928', 'Centro', 'ID', 'Meltonland', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Marcus Gates', '95894559964', 'marcus.gates@email.com', '900.277.596-44', '70.146.788', '2003-10-03', 22, '255 Martin Shoal Apt. 332', '78381-244', 'Centro', 'UT', 'Lesliemouth', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL11', 'Manuel Higueras Posada', '11273971768', 'manuel.higueras.posada@email.com', '222.123.987-86', '26.674.375', '1955-08-08', 70, 'C. de Maribel Palma 6', '30565-544', 'Centro', 'SP', 'Cuenca', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL12', 'Horacio David Padrón Quintana', '22751540559', 'horacio.david.padrón.quintana@email.com', '382.853.627-28', '40.147.615', '1964-07-09', 61, 'Andador Michoacán de Ocampo 631 Edif. 412 , Depto. 920', '89168-135', 'Centro', 'Q. ROO', 'Vieja Nauru', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Carolina Arregui Pelayo', '93177740246', 'carolina.arregui.pelayo@email.com', '800.971.452-36', '50.573.385', '1996-04-13', 29, 'Pasaje de Paca Vidal 295 Piso 0 ', '23842-503', 'Centro', 'SP', 'Teruel', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL13', 'Lalo de Duque', '03485501062', 'lalo.de.duque@email.com', '762.810.496-26', '51.455.491', '1975-12-04', 50, 'Pasaje Flora Valentín 4', '24242-938', 'Centro', 'SP', 'Guadalajara', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'María Jesús Dávila Arrieta', '78546892639', 'maría.jesús.dávila.arrieta@email.com', '250.168.579-28', '11.281.159', '2004-08-24', 21, 'Cuesta Néstor Zamorano 22 Apt. 67 ', '46023-402', 'Centro', 'SP', 'Huelva', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL15', 'Nicole Lee', '46578015736', 'nicole.lee@email.com', '513.558.478-89', '45.820.600', '1991-04-24', 34, '4384 Louis Dam', '80972-261', 'Centro', 'SP', 'North Melindaview', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL16', 'Modesta Hoz-Gomis', '24077485525', 'modesta.hoz-gomis@email.com', '749.791.549-82', '85.476.977', '1955-02-24', 70, 'Paseo América Galan 88 Puerta 1 ', '23513-278', 'Centro', 'SP', 'Lugo', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Jacob Mueller', '55832169816', 'jacob.mueller@email.com', '131.898.760-75', '20.161.522', '1990-12-04', 35, '382 Campbell Place Apt. 382', '32889-370', 'Centro', 'IA', 'North Jaime', 'United States');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL18', 'Lourdes Verduzco', '61908380828', 'lourdes.verduzco@email.com', '634.116.635-21', '51.350.179', '2007-01-29', 18, 'Circuito Angola 336 Interior 537', '35179-805', 'Centro', 'CHIH', 'San Elisa los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Adelina Fonseca Álvarez', '78965041861', 'adelina.fonseca.álvarez@email.com', '454.399.377-43', '50.676.435', '1956-03-03', 69, 'Glorieta Olegario Palacios 291 Apt. 13 ', '96027-297', 'Centro', 'SP', 'Valencia', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Diana Barajas', '31472421480', 'diana.barajas@email.com', '997.910.594-73', '34.981.701', '1987-10-25', 38, 'Prolongación República Democrática del Congo 351 Edif. 822 , Depto. 861', '96495-101', 'Centro', 'CHIS', 'Vieja Mauritania', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL14', 'Lic. Isaac Gallegos', '84884947308', 'lic..isaac.gallegos@email.com', '928.116.842-77', '75.778.171', '1973-10-01', 52, 'Circuito Baja California 121 665', '89557-592', 'Centro', 'DGO', 'Vieja San Vicente y las Granadinas', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL02', 'Joana Ribeiro', '55119193810', 'joana.ribeiro@email.com', '724.324.371-42', '11.855.712', '1982-06-06', 43, 'Rodovia Emanuel Novaes, 50', '81107-479', 'Centro', 'RR', 'das Neves do Norte', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'CF01', 'Fortunato Torrens Suarez', '50536446353', 'fortunato.torrens.suarez@email.com', '810.158.807-33', '63.595.635', '1998-06-09', 27, 'Urbanización Renato Cazorla 60', '51085-961', 'Centro', 'SP', 'Zaragoza', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL10', 'Jacob Holden', '68862440886', 'jacob.holden@email.com', '419.708.693-96', '34.122.265', '1997-07-20', 28, '773 Harper Villages', '71585-345', 'Centro', 'SP', 'Parkerside', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Fabiola Aranda Llanos', '89914689181', 'fabiola.aranda.llanos@email.com', '183.743.149-48', '90.952.796', '1957-09-24', 68, 'Vial de Adán Escolano 16', '11699-406', 'Centro', 'SP', 'Zaragoza', 'Spain');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL17', 'Bernardo Castro', '55519976130', 'bernardo.castro@email.com', '385.719.813-65', '41.174.351', '1996-11-23', 29, 'Estação Silveira, 686', '28650-948', 'Centro', 'MA', 'Martins', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL06', 'Antonio Gutiérrez', '89732457728', 'antonio.gutiérrez@email.com', '158.902.991-86', '63.830.445', '1997-06-05', 28, 'Periférico San Marino 889 Interior 843', '50475-450', 'Centro', 'SLP', 'Vieja Pakistán', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL05', 'Luigi Alves', '55119341394', 'luigi.alves@email.com', '513.382.323-23', '56.219.691', '1995-12-04', 30, 'Conjunto João Miguel Correia, 68', '99282-681', 'Centro', 'DF', 'Lima', 'Brazil');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL20', 'Jared Sanchez', '55513813000', 'jared.sanchez@email.com', '144.851.144-32', '77.491.786', '1961-12-16', 64, '106 Barry Knolls Suite 305', '20840-239', 'Centro', 'SP', 'Stephanieside', 'Canada');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL03', 'Blanca Escalante', '34045238684', 'blanca.escalante@email.com', '579.741.131-90', '17.380.739', '1957-07-26', 68, 'Andador Ornelas 625 Interior 086', '25873-175', 'Centro', 'BC', 'San Abelardo los bajos', 'Mexico');
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais) VALUES (NULL, 'FL07', 'Letícia Silva', '55119881549', 'letícia.silva@email.com', '718.556.519-10', '83.824.511', '1999-05-25', 26, 'Vereda de Cunha, 86', '59170-365', 'Centro', 'TO', 'Rezende', 'Brazil');

-- Insere 100 Funcionários
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone)
SELECT
    T.n,
    CONCAT('Funcionario ', T.n),
    FLOOR(RAND() * 40) + 20,
    CONCAT('111222333', LPAD(T.n, 3, '0')),
    CURDATE() - INTERVAL FLOOR(RAND() * 1000) DAY,
    CASE FLOOR(RAND() * 4)
        WHEN 0 THEN 'Gerente'
        WHEN 1 THEN 'Vendedor'
        WHEN 2 THEN 'Confeiteiro'
        WHEN 3 THEN 'Caixa'
        ELSE 'Estoquista'
    END,
    FLOOR(RAND() * 4000) + 2000,
    CONCAT('119', FLOOR(RAND() * 90000000) + 10000000)
FROM (SELECT a.n + b.n * 10 AS n 
      FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
                   SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, 
           (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4) b) AS T
WHERE T.n BETWEEN 1 AND 100;


INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (1, 'Aarón Higueras Mateos', 24, '595.404.431-92', '2023-09-03', 'Caixa', 6710.82, '92022280872');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (2, 'Crystal Hill', 32, '336.760.185-18', '2021-10-13', 'Confeiteiro', 3386.7, '99253378829');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (3, 'Kristen Hayes', 62, '364.398.625-24', '2018-04-07', 'Confeiteiro', 4354.48, '39617481728');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (4, 'João Miguel Farias', 27, '472.762.654-23', '2019-06-13', 'Confeiteiro', 3875.16, '55849950863');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (5, 'Karen Norris', 57, '369.612.197-93', '2017-03-02', 'Confeiteiro', 3795.63, '21066908485');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (6, 'Mariano Uriel Vargas Quintero', 59, '925.572.184-71', '2022-01-29', 'Caixa', 2280.64, '50595569175');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (7, 'Jesusa Miranda Riera', 26, '389.561.921-38', '2023-11-20', 'Vendedor', 7989.06, '84991830468');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (8, 'Carl Nelson', 19, '797.922.497-22', '2016-02-03', 'Gerente', 6599.24, '32842328018');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (9, 'Erin Chapman', 20, '307.463.850-25', '2021-01-16', 'Vendedor', 4681.49, '88952343540');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (10, 'Amelia Lebrón Niño', 65, '768.686.767-16', '2022-01-11', 'Gerente', 3616.01, '79495107116');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (11, 'Manuel Turner', 34, '153.551.480-92', '2018-11-09', 'Gerente', 2094.31, '88626339554');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (12, 'Dulce Gabino Medina', 63, '407.969.445-18', '2017-07-05', 'Gerente', 2573.45, '54169071987');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (13, 'Paola Elvia Nieves', 46, '573.538.957-41', '2017-08-18', 'Confeiteiro', 4893.79, '33026689451');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (14, 'Antonio Lluch Vera', 49, '453.252.249-43', '2018-04-30', 'Confeiteiro', 5003.53, '32861102077');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (15, 'Jason Owens', 55, '872.424.333-10', '2020-11-09', 'Gerente', 7724.29, '84793159349');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (16, 'Violeta Treviño', 41, '515.507.423-35', '2019-04-29', 'Caixa', 6767.74, '98184390000');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (17, 'Katherine Dawson', 25, '828.856.305-88', '2023-08-05', 'Vendedor', 3720.91, '28365687990');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (18, 'Angelino Berenguer', 60, '216.584.721-70', '2016-05-11', 'Confeiteiro', 4706.94, '44818909584');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (19, 'Mark Ryan', 30, '939.631.231-57', '2017-06-28', 'Caixa', 2709.49, '89098143611');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (20, 'Lori Schultz', 50, '252.613.975-81', '2016-10-05', 'Gerente', 2189.05, '12895529661');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (21, 'Lynn Russell', 33, '402.311.873-62', '2018-11-07', 'Caixa', 6506.95, '50474709777');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (22, 'Jeffrey Carlson', 61, '101.308.108-48', '2021-08-30', 'Vendedor', 2595.78, '55003959738');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (23, 'Noemí Concepción Montez Garza', 58, '909.900.197-17', '2023-01-15', 'Caixa', 7199.71, '12192478719');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (24, 'Severino Ruano Gallardo', 18, '698.393.705-20', '2018-11-02', 'Estoquista', 4003.16, '08079334823');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (25, 'Katrina Green', 57, '387.918.215-73', '2017-12-27', 'Confeiteiro', 3008.64, '62268590539');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (26, 'Jos Rendón', 57, '491.640.122-84', '2023-09-03', 'Vendedor', 4591.92, '07331772523');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (27, 'Darío Gabino Carvajal', 51, '710.948.183-75', '2024-01-04', 'Estoquista', 6065.69, '99803122838');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (28, 'Anthony Noble', 41, '954.589.270-48', '2023-11-15', 'Vendedor', 3908.82, '23650128439');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (29, 'Odalys Portero Cuesta', 44, '715.780.853-17', '2018-04-01', 'Gerente', 7039.12, '27680655807');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (30, 'Donald Mason', 65, '476.394.182-23', '2017-11-17', 'Estoquista', 5825.68, '18764251450');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (31, 'Jeremy Wheeler', 20, '828.324.144-67', '2020-07-18', 'Confeiteiro', 5309.97, '79399697983');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (32, 'Sr. Gustavo Martins', 39, '641.910.130-32', '2017-12-19', 'Caixa', 7566.93, '55419087576');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (33, 'Sra. Ana Laura Ferreira', 44, '392.498.656-61', '2023-12-31', 'Gerente', 2773.23, '55319655376');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (34, 'Lic. Víctor Zayas', 24, '152.917.409-72', '2018-03-01', 'Vendedor', 2501.42, '24980244624');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (35, 'Tyler Sullivan', 39, '282.799.407-91', '2022-09-06', 'Vendedor', 4104.3, '00629038122');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (36, 'Dr. Pietro Rocha', 38, '744.228.779-72', '2018-04-15', 'Caixa', 2096.28, '55319882068');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (37, 'Ana Araújo', 48, '298.462.452-50', '2020-07-30', 'Confeiteiro', 3585.44, '55519747518');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (38, 'Selena Day', 36, '714.733.983-26', '2024-04-26', 'Confeiteiro', 7431.39, '41848470863');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (39, 'Odalys Giralt', 32, '230.790.285-48', '2025-08-20', 'Gerente', 3006.76, '54488152610');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (40, 'Salma Valles', 25, '830.222.899-84', '2020-09-04', 'Vendedor', 7989.85, '24961919590');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (41, 'Michael Harris', 52, '419.206.319-76', '2024-04-03', 'Estoquista', 7630.31, '67080445154');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (42, 'Dale Jones', 41, '797.803.791-12', '2020-03-04', 'Confeiteiro', 6315.04, '59333859728');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (43, 'José Luis Aparicio Recio', 32, '795.856.384-57', '2016-05-29', 'Estoquista', 2748.68, '89699837790');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (44, 'Dr. Pedro Henrique Lima', 39, '385.357.698-68', '2017-05-05', 'Confeiteiro', 2106.05, '55819150555');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (45, 'Alejo Cordero', 48, '531.113.584-22', '2019-09-18', 'Estoquista', 3824.66, '66830367363');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (46, 'Pedro César Baca', 34, '155.200.791-28', '2020-02-27', 'Confeiteiro', 2637.54, '42045015791');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (47, 'Esther Almeida', 29, '292.524.255-72', '2018-05-13', 'Estoquista', 4068.77, '55219911439');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (48, 'Lic. Luis Castillo', 19, '192.188.315-80', '2018-04-15', 'Estoquista', 3135.9, '79124518786');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (49, 'Robert Stephens', 49, '826.652.903-92', '2020-02-07', 'Estoquista', 2520.24, '26593666373');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (50, 'Poncio Olmedo Borrego', 32, '759.164.236-75', '2022-03-30', 'Estoquista', 5719.25, '43110234490');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (51, 'Raul da Rosa', 33, '612.591.249-54', '2022-09-21', 'Vendedor', 3946.61, '55519751150');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (52, 'Michael Mendoza', 61, '437.493.717-73', '2024-05-09', 'Gerente', 7891.01, '43127498844');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (53, 'Angela Robinson', 48, '755.335.196-49', '2016-07-02', 'Estoquista', 3488.81, '39859844275');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (54, 'Dr. Laura Ford', 42, '317.209.295-23', '2019-12-19', 'Confeiteiro', 7051.66, '76479592358');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (55, 'Cruz Gabino Gascón Coca', 28, '559.521.220-58', '2021-09-08', 'Caixa', 4793.64, '69931518907');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (56, 'Yasmin Moraes', 44, '651.532.821-88', '2015-09-16', 'Vendedor', 6764.8, '55219750313');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (57, 'Kathleen Gilbert', 61, '311.272.136-43', '2022-06-28', 'Gerente', 4509.22, '61059860237');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (58, 'Patrick Carey', 51, '210.893.694-18', '2023-03-01', 'Gerente', 3788.92, '54198459499');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (59, 'Agustín Eloisa Laboy Beltrán', 19, '228.953.301-89', '2023-03-19', 'Confeiteiro', 3096.24, '33536626473');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (60, 'Faustino Solana Batalla', 21, '848.773.202-20', '2022-12-04', 'Confeiteiro', 7798.52, '11067453286');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (61, 'Jessica Robinson', 65, '352.671.327-12', '2019-06-18', 'Estoquista', 7645.61, '35044602412');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (62, 'Stephen Banks', 53, '145.368.415-88', '2023-11-26', 'Vendedor', 4716.78, '37520656038');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (63, 'Andrew Gonzalez', 25, '681.853.496-88', '2015-10-26', 'Caixa', 3415.72, '00145258806');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (64, 'Cristian Blasco Vélez', 36, '371.467.220-35', '2021-08-02', 'Estoquista', 7305.68, '35879795764');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (65, 'Cynthia Jackson', 55, '579.894.795-72', '2024-02-19', 'Estoquista', 6028.21, '35996067576');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (66, 'Emanuelly Ferreira', 34, '680.307.763-67', '2025-08-14', 'Confeiteiro', 2238.74, '55819306256');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (67, 'Sierra Sanders', 41, '337.947.853-64', '2024-05-21', 'Caixa', 5595.82, '84685925427');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (68, 'Kevin Ramos', 37, '654.349.662-20', '2016-07-30', 'Estoquista', 2248.02, '55619597331');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (69, 'Ana Castro', 35, '146.579.867-81', '2017-03-29', 'Vendedor', 2771.65, '55619618110');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (70, 'Gary Martinez', 50, '127.701.766-84', '2015-11-03', 'Confeiteiro', 6715.35, '17103064012');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (71, 'Srta. Ana Luiza Almeida', 20, '852.733.118-22', '2025-07-16', 'Estoquista', 2842.67, '55119523778');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (72, 'Alejandra Rosalia Valle Varela', 63, '573.666.384-90', '2019-05-23', 'Vendedor', 2509.64, '27890083806');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (73, 'Pedro Miguel Barbosa', 45, '961.330.748-37', '2018-06-07', 'Gerente', 4539.39, '55319529728');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (74, 'Maria Eduarda da Cunha', 58, '602.176.667-30', '2023-11-02', 'Confeiteiro', 6620.34, '55419873208');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (75, 'Lic. Luis Baca', 41, '154.446.843-32', '2024-02-14', 'Vendedor', 7070.41, '02834250190');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (76, 'Tanya Jones', 37, '689.867.409-42', '2017-02-26', 'Gerente', 4608.29, '32289793157');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (77, 'Sol Santos-Oller', 44, '617.931.262-66', '2022-03-30', 'Caixa', 3850.88, '86368628525');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (78, 'Linda Steele', 23, '209.518.498-93', '2017-06-26', 'Vendedor', 3536.72, '23208881862');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (79, 'Luana Silva', 25, '607.327.608-13', '2022-10-10', 'Vendedor', 4297.4, '55319612921');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (80, 'Michael Taylor', 43, '576.185.963-65', '2016-01-22', 'Caixa', 7025.0, '78578664126');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (81, 'Nydia Mendoza Casal', 36, '172.461.736-73', '2021-02-15', 'Caixa', 5140.83, '89120893374');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (82, 'Kelsey Shaffer', 52, '529.585.177-94', '2016-11-21', 'Gerente', 3820.39, '53406207244');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (83, 'Donna Williams', 44, '484.661.130-28', '2016-07-04', 'Gerente', 3293.27, '04087719924');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (84, 'Joan Pellicer-Garrido', 41, '320.385.854-78', '2025-04-21', 'Caixa', 3743.83, '93719359112');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (85, 'Jason George', 27, '161.734.762-18', '2021-12-13', 'Gerente', 2739.15, '21560905351');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (86, 'Jonathan Mitchell', 33, '302.106.653-46', '2023-12-22', 'Vendedor', 6741.62, '44452306467');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (87, 'Camilo Galan', 52, '141.233.865-79', '2024-11-12', 'Gerente', 4404.69, '45559671693');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (88, 'Sara Asunción Colom Rocamora', 31, '926.322.242-23', '2018-01-27', 'Vendedor', 5638.88, '47405411214');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (89, 'Ana Laura Araújo', 49, '998.491.269-72', '2023-05-14', 'Caixa', 6707.4, '55849939654');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (90, 'Walter Rangel', 36, '980.867.135-16', '2020-04-19', 'Confeiteiro', 3814.25, '96166740885');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (91, 'Christian Howard', 60, '170.867.825-27', '2017-05-09', 'Confeiteiro', 5107.63, '17005800939');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (92, 'Sergio Somoza Maldonado', 62, '208.620.205-24', '2018-05-11', 'Vendedor', 4281.77, '18576968589');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (93, 'Jacobo Arias Paz', 64, '454.104.996-72', '2018-07-13', 'Gerente', 5897.1, '12882085546');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (94, 'Itzel Pérez Leal', 65, '669.441.185-65', '2022-10-12', 'Vendedor', 4659.47, '28065556664');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (95, 'Cory Stephenson', 18, '467.603.189-29', '2020-11-01', 'Caixa', 6509.25, '12194894817');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (96, 'Dra. Carolina da Cruz', 18, '802.246.597-75', '2019-10-07', 'Caixa', 4960.79, '55619922057');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (97, 'Adriana Johnson', 47, '106.885.602-58', '2020-02-09', 'Confeiteiro', 6154.4, '63136812774');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (98, 'Michael Williams', 21, '832.637.673-27', '2015-09-17', 'Vendedor', 4433.92, '52762454322');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (99, 'Miguel Rivera Menchaca', 24, '136.267.175-15', '2025-06-01', 'Confeiteiro', 2875.81, '48650243806');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (100, 'Blas Avilés Palomino', 49, '665.826.357-24', '2023-07-04', 'Estoquista', 3622.91, '63474435683');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (101, 'Jennifer Mendoza', 50, '728.149.804-10', '2024-10-16', 'Gerente', 2056.85, '38353142608');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (102, 'Rafaél Briones', 54, '840.207.478-69', '2021-06-11', 'Confeiteiro', 5153.49, '78240676275');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (103, 'João Fogaça', 60, '724.422.630-86', '2023-05-03', 'Gerente', 3671.66, '55319422009');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (104, 'Jeffrey Anderson', 40, '145.935.982-74', '2025-06-22', 'Confeiteiro', 3038.04, '52196770888');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (105, 'Ana María Rosa Castellanos Nevárez', 32, '242.625.637-66', '2017-07-10', 'Confeiteiro', 4777.3, '84180360721');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (106, 'Anthony Spence', 46, '521.652.349-20', '2022-03-29', 'Confeiteiro', 4838.76, '49036478425');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (107, 'Barry Smith', 47, '567.141.233-33', '2019-06-20', 'Gerente', 5279.64, '05097699562');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (108, 'Ilse Tello Ornelas', 60, '503.199.594-93', '2023-03-16', 'Confeiteiro', 3435.94, '73501901628');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (109, 'Anthony Wiley', 46, '167.168.427-42', '2018-08-27', 'Estoquista', 3399.68, '27670110317');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (110, 'Srta. Júlia Viana', 51, '458.947.377-61', '2015-12-29', 'Vendedor', 5355.08, '55619673625');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (111, 'Araceli Brito', 59, '173.259.651-48', '2017-08-21', 'Gerente', 7632.48, '08615437301');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (112, 'Deborah Nielsen', 54, '450.995.738-61', '2025-05-03', 'Vendedor', 2673.88, '75050006484');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (113, 'Cauã Castro', 55, '491.131.696-83', '2021-02-17', 'Gerente', 5441.91, '55619258799');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (114, 'Danilo Salamanca Guillen', 56, '998.183.269-35', '2018-07-23', 'Vendedor', 6112.3, '44518518352');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (115, 'Zoé Campos Bétancourt', 31, '232.768.152-11', '2016-05-14', 'Gerente', 7289.69, '03055106897');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (116, 'Adalberto de Arnal', 65, '432.856.383-27', '2016-08-04', 'Estoquista', 4110.63, '66078092990');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (117, 'Gustavo Gonçalves', 41, '773.282.323-21', '2017-12-01', 'Gerente', 6381.91, '55849540062');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (118, 'Lívia Melo', 21, '238.251.382-33', '2016-06-11', 'Vendedor', 6770.0, '55819778141');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (119, 'Rebecca Holloway', 44, '734.476.934-86', '2016-05-02', 'Estoquista', 4550.06, '79234303844');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (120, 'Kathy Morris', 29, '937.403.254-77', '2019-09-19', 'Confeiteiro', 2521.08, '15784382949');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (121, 'Abel Rosado Paniagua', 52, '912.438.375-93', '2017-07-23', 'Caixa', 6794.19, '86626466528');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (122, 'Teobaldo Escamilla Cal', 51, '244.193.608-53', '2017-12-17', 'Caixa', 2144.91, '35561903467');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (123, 'Carmen Morell Fajardo', 52, '811.130.170-57', '2024-09-28', 'Gerente', 3536.4, '30206948068');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (124, 'John Anderson', 60, '678.503.567-85', '2024-07-04', 'Confeiteiro', 6320.64, '49589547781');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (125, 'Caitlin Gates', 55, '686.606.689-38', '2020-05-14', 'Confeiteiro', 3011.09, '29958148686');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (126, 'Davi Luiz Rocha', 51, '532.221.220-51', '2018-06-04', 'Confeiteiro', 4234.85, '55319820425');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (127, 'Mathew Johnson', 25, '385.832.372-37', '2024-04-01', 'Estoquista', 3240.71, '77329940189');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (128, 'Amílcar Alberto Coronado', 63, '569.847.267-30', '2023-03-26', 'Caixa', 7609.88, '81435540391');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (129, 'Sara Martin PhD', 38, '832.484.106-58', '2020-02-13', 'Estoquista', 4703.08, '23489064636');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (130, 'Ing. Jaqueline Laboy', 28, '879.388.190-26', '2017-02-24', 'Vendedor', 6303.38, '76785120591');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (131, 'Dimas Casares', 21, '842.332.388-89', '2017-09-16', 'Estoquista', 2160.36, '45516972953');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (132, 'Mtro. Dolores Bustos', 23, '170.321.403-94', '2018-08-21', 'Estoquista', 7959.21, '73801943426');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (133, 'James Ford', 43, '737.721.327-36', '2019-08-28', 'Vendedor', 2084.58, '03768405663');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (134, 'David Sainz', 51, '569.923.761-75', '2023-01-08', 'Confeiteiro', 3878.7, '55491065270');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (135, 'Erin Richards', 49, '733.853.839-12', '2016-07-01', 'Confeiteiro', 7764.5, '55035781620');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (136, 'Laís da Rosa', 53, '570.109.953-87', '2017-06-13', 'Caixa', 3084.72, '55519796263');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (137, 'Derek Nguyen', 33, '286.340.452-33', '2017-03-14', 'Vendedor', 5317.78, '05885307776');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (138, 'Catarina Jesus', 52, '467.511.549-70', '2023-02-28', 'Caixa', 7139.79, '55849441628');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (139, 'Sarah Vieira', 65, '913.317.652-99', '2018-11-12', 'Caixa', 2069.04, '55619453777');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (140, 'Emanuella Ramos', 21, '360.772.860-63', '2019-09-02', 'Vendedor', 5831.63, '55819662051');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (141, 'Amanda Mcpherson', 53, '180.887.223-35', '2024-07-25', 'Confeiteiro', 6308.89, '22831752642');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (142, 'Cándido Amat Coloma', 25, '474.549.674-59', '2018-01-27', 'Estoquista', 6790.39, '84353754736');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (143, 'Jesús David Mesa Rivero', 54, '945.168.484-93', '2018-04-04', 'Vendedor', 7893.78, '42308442536');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (144, 'Irene Rojo Melgar', 18, '392.248.883-92', '2021-01-08', 'Gerente', 4926.31, '09404957471');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (145, 'Ricardo Phelps', 44, '324.133.760-54', '2021-09-26', 'Gerente', 3483.56, '53194926832');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (146, 'Joshua Hopkins', 42, '960.235.682-48', '2017-11-28', 'Caixa', 5669.22, '94117519468');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (147, 'Ing. Jerónimo Reyes', 27, '851.601.688-66', '2019-09-12', 'Estoquista', 2663.98, '21345081905');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (148, 'Dr. Claudia Gaitán', 20, '889.577.290-53', '2024-08-05', 'Confeiteiro', 6052.86, '45512374288');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (149, 'Emma Lane', 64, '723.443.501-16', '2022-07-27', 'Gerente', 7438.13, '44045071727');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (150, 'Ricardo Gabino Dueñas', 56, '676.626.729-93', '2021-01-10', 'Caixa', 4265.56, '44314677069');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (151, 'Rosalinda de Ruano', 22, '759.292.336-22', '2018-01-07', 'Confeiteiro', 6438.89, '74802309515');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (152, 'Erica Duffy', 24, '112.941.599-50', '2018-07-24', 'Confeiteiro', 4142.34, '46233085332');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (153, 'Kara Greer', 46, '870.973.189-45', '2023-08-26', 'Estoquista', 4576.49, '86861447364');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (154, 'Amanda Costa', 50, '639.867.208-90', '2023-06-26', 'Confeiteiro', 4798.94, '55719578289');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (155, 'Thales Porto', 27, '623.859.173-69', '2023-01-20', 'Gerente', 7279.1, '55219814436');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (156, 'Pascual Barela', 65, '564.540.143-14', '2025-03-14', 'Estoquista', 4794.28, '51175010332');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (157, 'Eduarda Santos', 39, '126.380.501-71', '2023-10-10', 'Estoquista', 5681.32, '55419515347');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (158, 'Ing. Rafaél Villa', 47, '570.278.730-92', '2024-08-18', 'Estoquista', 6747.87, '76563659176');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (159, 'Laurie Wells', 64, '158.555.387-86', '2023-07-17', 'Caixa', 4131.68, '53256102900');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (160, 'Travis Nguyen', 39, '103.965.306-61', '2019-05-03', 'Vendedor', 6129.97, '35284696044');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (161, 'Matthew Khan', 19, '676.292.875-60', '2020-09-14', 'Estoquista', 5113.5, '14451966376');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (162, 'Vitor Hugo Ferreira', 37, '315.495.932-66', '2016-05-17', 'Estoquista', 3253.49, '55119630124');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (163, 'Miss Cassandra Barnes', 18, '393.803.781-14', '2022-01-02', 'Caixa', 3203.79, '33655465951');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (164, 'Srta. Raquel da Rosa', 58, '156.500.753-62', '2021-10-13', 'Vendedor', 3292.58, '55619064797');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (165, 'Alexis Beltran', 28, '113.781.382-96', '2018-07-14', 'Gerente', 7956.55, '88078131166');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (166, 'Débora Mur Cifuentes', 29, '554.635.210-98', '2023-01-30', 'Estoquista', 3541.57, '67890917606');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (167, 'Lisa Allen', 33, '995.388.217-38', '2021-03-21', 'Vendedor', 2656.09, '05208795163');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (168, 'Vitor Gabriel Melo', 52, '918.953.695-82', '2025-04-02', 'Confeiteiro', 4822.61, '55519589712');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (169, 'Robert Hill', 28, '418.771.635-80', '2017-06-06', 'Confeiteiro', 5690.57, '64997306528');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (170, 'Israel Verónica Aguilera', 37, '235.660.794-75', '2020-08-27', 'Caixa', 7437.11, '40939383824');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (171, 'Dr. Alejandro Arredondo', 57, '133.106.917-70', '2021-08-03', 'Vendedor', 3780.45, '29777294745');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (172, 'Jason Peters', 19, '122.451.583-56', '2022-12-21', 'Vendedor', 6687.36, '77792143803');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (173, 'Milagros Higueras Román', 40, '635.608.108-19', '2024-11-14', 'Caixa', 5731.79, '16682924923');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (174, 'Susan Villarreal', 31, '405.954.755-57', '2019-11-08', 'Vendedor', 2258.36, '47045339415');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (175, 'Luiz Henrique Alves', 55, '860.443.549-84', '2020-10-14', 'Confeiteiro', 2086.18, '55849576664');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (176, 'Felicidad Coello Pablo', 52, '947.442.520-41', '2024-08-18', 'Confeiteiro', 4588.49, '80207409427');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (177, 'Yvette Nguyen', 38, '612.531.868-73', '2023-08-20', 'Confeiteiro', 2060.64, '90217200742');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (178, 'Carolina Zeferino Bétancourt Apodaca', 20, '930.399.677-52', '2021-01-29', 'Gerente', 6778.13, '52427206583');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (179, 'Isaac Malo Iborra', 51, '782.593.261-24', '2020-05-12', 'Estoquista', 2516.55, '30635727127');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (180, 'Juliana Melo', 50, '145.221.310-49', '2022-09-25', 'Gerente', 7010.72, '55319860087');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (181, 'Miguel Beatriz Ferrer Ruiz', 28, '496.430.662-44', '2018-04-05', 'Estoquista', 6340.91, '88455203587');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (182, 'Luiz Fernando Cardoso', 58, '272.206.513-74', '2016-09-05', 'Caixa', 6360.5, '55819051768');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (183, 'Maxi Rosario Pomares Carpio', 43, '873.202.818-25', '2024-06-15', 'Vendedor', 3488.43, '56564422237');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (184, 'Trini Belda-Gelabert', 31, '598.355.199-22', '2022-07-18', 'Confeiteiro', 7587.26, '31283876876');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (185, 'Blanca Natalia Arevalo', 61, '190.664.195-75', '2019-12-19', 'Caixa', 5007.77, '79943538324');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (186, 'Larissa Moura', 33, '222.848.662-42', '2022-01-14', 'Vendedor', 2031.99, '55819393360');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (187, 'Oswaldo Gilberto Medina Montaño', 61, '786.678.123-23', '2021-01-03', 'Confeiteiro', 2672.13, '18985058791');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (188, 'Maria Fernanda Duarte', 45, '290.518.204-34', '2024-10-26', 'Gerente', 2839.97, '55219684919');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (189, 'Mauro Guzmán', 56, '180.858.914-14', '2022-06-12', 'Confeiteiro', 2179.53, '62176240485');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (190, 'Juan Carlos Diana Alejandro Bueno', 58, '520.145.221-69', '2018-11-07', 'Confeiteiro', 4761.65, '19562484670');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (191, 'Sra. Luna Moraes', 37, '597.350.670-63', '2024-10-23', 'Confeiteiro', 7100.95, '55819153799');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (192, 'Isabel Ferreira', 33, '403.481.490-21', '2020-03-08', 'Confeiteiro', 7015.35, '55419643087');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (193, 'Alexandre Lima', 31, '558.146.409-71', '2015-11-01', 'Gerente', 4845.35, '55519086473');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (194, 'Alicia Roberts DDS', 48, '371.326.519-68', '2019-04-12', 'Estoquista', 3728.46, '13221486027');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (195, 'Enzo Rezende', 45, '453.884.605-72', '2017-05-28', 'Caixa', 6014.27, '55819192986');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (196, 'Michael Sullivan', 48, '728.745.246-15', '2021-11-27', 'Gerente', 2352.4, '82056303789');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (197, 'Mtro. Alfonso Nieves', 63, '683.355.660-56', '2017-06-23', 'Caixa', 7392.5, '96099976929');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (198, 'Mtro. Rodolfo Grijalva', 24, '979.676.579-35', '2022-12-03', 'Gerente', 5838.41, '99436308894');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (199, 'Keith Garcia', 46, '319.824.365-95', '2016-05-11', 'Estoquista', 7669.39, '04538018782');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (200, 'Elvia Granado Cisneros', 41, '674.608.443-74', '2024-10-27', 'Estoquista', 2084.12, '31056902776');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (201, 'Sr(a). Tomás Saavedra', 27, '387.765.761-85', '2024-04-23', 'Estoquista', 7966.96, '81712059143');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (202, 'Jeanne Robinson', 30, '468.355.355-86', '2022-03-06', 'Estoquista', 6748.29, '16883099366');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (203, 'Jerónimo Girón Espinoza', 19, '628.552.489-27', '2018-02-07', 'Confeiteiro', 4055.7, '85971700896');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (204, 'Justin Kelly', 25, '261.814.570-80', '2024-08-17', 'Vendedor', 2754.8, '37990399995');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (205, 'José Luis Inés Valdivia', 48, '551.345.730-34', '2023-11-22', 'Vendedor', 2360.75, '85017177201');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (206, 'Ralph Moore', 53, '175.310.950-15', '2020-12-05', 'Gerente', 6253.85, '65763825211');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (207, 'Cole Hernandez', 42, '136.685.183-13', '2022-04-23', 'Gerente', 5205.83, '33818521000');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (208, 'Teresa Pamela Mendoza', 54, '305.556.996-92', '2018-05-14', 'Vendedor', 2263.34, '70220712722');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (209, 'Jody Mann', 64, '852.741.495-32', '2020-06-02', 'Gerente', 6711.2, '18449667779');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (210, 'Lic. Natividad Báez', 25, '990.297.283-55', '2025-07-19', 'Gerente', 5160.26, '80456142645');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (211, 'Esteban Enríquez-Ropero', 52, '710.893.650-99', '2019-01-02', 'Gerente', 6380.56, '25184916633');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (212, 'Leandra Piña-Mayol', 40, '714.941.275-37', '2016-09-28', 'Gerente', 3919.34, '54343652526');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (213, 'Allison Frazier', 47, '253.981.845-90', '2018-11-22', 'Confeiteiro', 5382.22, '62430631097');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (214, 'Joseph Green', 26, '199.971.908-85', '2016-03-31', 'Gerente', 2053.33, '58002790320');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (215, 'Wendy Rodriguez', 59, '184.748.651-76', '2025-05-02', 'Caixa', 4598.72, '34909750048');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (216, 'Kristina Santiago', 54, '566.196.169-16', '2018-12-17', 'Estoquista', 4036.7, '23893551075');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (217, 'Sra. Mariana Nascimento', 46, '480.608.511-36', '2015-10-20', 'Caixa', 2251.08, '55719630882');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (218, 'Rosalía Castells Villaverde', 47, '587.190.336-70', '2025-09-05', 'Vendedor', 5846.23, '33152554729');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (219, 'Justin Hoover', 28, '628.762.206-77', '2022-09-21', 'Caixa', 3408.02, '14001655763');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (220, 'Renato Ramiro Espinoza', 57, '714.474.139-42', '2017-09-17', 'Caixa', 7299.55, '58929606957');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (221, 'Guadalupe Crespo', 37, '524.650.800-51', '2019-02-17', 'Vendedor', 7574.42, '92718857029');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (222, 'Davi Lucas Oliveira', 56, '252.573.406-41', '2022-12-26', 'Estoquista', 7496.37, '55519457625');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (223, 'Salud Mayo Juárez', 59, '581.403.721-41', '2019-02-17', 'Gerente', 5448.6, '77516939870');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (224, 'Larissa Fernandes', 47, '311.845.139-42', '2016-03-12', 'Gerente', 6217.98, '55119797104');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (225, 'Emanuelly Silva', 64, '764.895.265-71', '2021-12-25', 'Gerente', 6405.29, '55519501869');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (226, 'Cheryl Smith', 48, '505.737.119-63', '2022-10-25', 'Vendedor', 2591.94, '13423083194');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (227, 'Laura Gonçalves', 63, '930.750.420-59', '2022-08-06', 'Gerente', 5320.16, '55219066773');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (228, 'Joseph Hensley', 29, '771.191.696-41', '2016-06-27', 'Estoquista', 4608.07, '20502018712');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (229, 'Maria Clara Ramos', 24, '653.381.261-83', '2023-01-12', 'Gerente', 6345.28, '55419273635');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (230, 'César Ortega', 32, '146.809.919-90', '2025-05-04', 'Estoquista', 3125.65, '51466454821');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (231, 'Christopher Ryan', 29, '345.116.284-24', '2018-10-18', 'Gerente', 2993.46, '34585129956');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (232, 'Mark Garcia MD', 28, '106.973.624-74', '2017-06-12', 'Estoquista', 5905.55, '39722683104');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (233, 'Cecília Costela', 43, '874.845.679-66', '2022-05-27', 'Gerente', 7070.92, '55819751160');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (234, 'Frida Ariadna Naranjo Baca', 32, '616.388.718-22', '2024-12-13', 'Estoquista', 4867.05, '90926110880');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (235, 'Tina Weber', 48, '272.523.358-82', '2024-04-22', 'Confeiteiro', 5184.29, '90981959818');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (236, 'Luiz Otávio Nascimento', 29, '893.861.986-54', '2019-01-01', 'Gerente', 2932.33, '55619392217');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (237, 'Christina Edwards', 37, '481.176.991-39', '2021-11-11', 'Vendedor', 2602.84, '39743100367');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (238, 'Rafaél Jos Mojica Almonte', 56, '568.666.439-15', '2023-09-04', 'Caixa', 6352.82, '08123960707');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (239, 'Tony Harmon', 53, '599.974.604-63', '2020-12-17', 'Estoquista', 2268.88, '17001910654');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (240, 'Mtro. Alta  Gracia Báez', 61, '150.802.820-89', '2022-02-05', 'Estoquista', 2962.99, '12923526131');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (241, 'Jose Luis Aarón Echevarría Martin', 31, '516.158.738-20', '2024-08-19', 'Gerente', 7964.27, '80129040831');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (242, 'Daniel Braun', 30, '606.973.648-55', '2016-12-23', 'Caixa', 7091.25, '79207769527');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (243, 'Eloy Rojas', 48, '893.136.979-85', '2023-04-28', 'Caixa', 4257.11, '12991041508');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (244, 'Brenda Araújo', 24, '941.322.336-95', '2023-04-14', 'Confeiteiro', 5140.65, '55519447656');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (245, 'Ashley Meyer', 45, '467.772.835-83', '2022-01-17', 'Gerente', 7972.66, '75089654962');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (246, 'Juan Viana', 31, '884.653.444-52', '2021-10-09', 'Estoquista', 6664.24, '55849267762');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (247, 'Margaret Oneal', 52, '993.633.203-83', '2020-07-31', 'Confeiteiro', 6407.35, '56012503705');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (248, 'Azeneth Bernat Fabregat', 32, '341.331.638-41', '2017-10-25', 'Gerente', 2288.07, '45729825127');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (249, 'Alícia Gonçalves', 24, '593.383.791-30', '2021-12-23', 'Gerente', 5931.58, '55849434497');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (250, 'Elisa Sales', 52, '538.870.429-57', '2022-01-08', 'Vendedor', 5498.04, '55619471234');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (251, 'Megan Lucas', 19, '988.121.913-65', '2023-01-10', 'Vendedor', 3647.57, '67142373262');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (252, 'Emanuella da Luz', 27, '726.417.147-45', '2016-02-17', 'Gerente', 5638.89, '55849263172');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (253, 'Fernanda Pinto', 50, '527.115.729-88', '2016-06-15', 'Vendedor', 4408.23, '55849594588');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (254, 'Marina Alcázar Bernat', 38, '635.867.100-92', '2018-07-29', 'Estoquista', 7332.31, '08780945909');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (255, 'Emilia Francisco Tapia Carranza', 23, '152.139.667-91', '2020-11-18', 'Gerente', 2733.71, '65995772948');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (256, 'Rómulo Bello Feliu', 54, '497.270.847-10', '2017-11-05', 'Vendedor', 3739.15, '39340538756');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (257, 'Ana Beatriz das Neves', 20, '720.829.228-59', '2025-05-16', 'Vendedor', 7879.39, '55419338421');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (258, 'Erick Fogaça', 37, '140.194.525-88', '2019-07-06', 'Confeiteiro', 5339.81, '55419287940');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (259, 'Travis Bruce', 61, '793.790.237-44', '2016-08-13', 'Vendedor', 6565.83, '92416182419');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (260, 'Felipe Elpidio Mendoza Criado', 42, '117.336.211-81', '2023-09-14', 'Caixa', 2432.4, '18144174429');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (261, 'Esther Teixeira', 19, '618.976.231-78', '2020-07-18', 'Vendedor', 4042.15, '55819316662');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (262, 'Tracie Woods', 58, '754.252.694-31', '2018-01-28', 'Gerente', 6488.84, '69142347731');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (263, 'Sr. Samuel Santos', 22, '808.893.110-68', '2021-06-06', 'Caixa', 7054.43, '55849719449');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (264, 'Adela Mariano Jaramillo', 43, '864.617.783-21', '2022-01-19', 'Confeiteiro', 6354.91, '56671755095');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (265, 'Teo Rueda', 28, '283.676.831-32', '2022-06-19', 'Confeiteiro', 7667.27, '94324369855');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (266, 'Gwendolyn Mendez', 53, '830.491.927-20', '2019-11-11', 'Estoquista', 3113.09, '99874313627');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (267, 'Kayla Taylor', 45, '168.944.344-25', '2016-09-03', 'Confeiteiro', 2008.27, '01607729863');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (268, 'Sharon Jacobs', 61, '428.246.925-63', '2020-03-08', 'Caixa', 3774.99, '96210725019');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (269, 'Michael Fields', 21, '240.311.648-11', '2017-02-09', 'Confeiteiro', 6374.06, '74248773135');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (270, 'Karen Myers', 41, '649.931.847-37', '2018-04-02', 'Vendedor', 7850.93, '37936083678');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (271, 'Alfredo Jorge Montero', 19, '490.690.568-21', '2023-11-24', 'Gerente', 4343.29, '87776385933');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (272, 'Ricky Vega', 49, '872.988.970-77', '2024-01-22', 'Gerente', 2432.72, '81723628595');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (273, 'Alícia Monteiro', 20, '725.540.684-31', '2021-06-20', 'Vendedor', 6495.04, '55819794016');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (274, 'Ignacio Judith Roque', 35, '728.151.663-26', '2023-12-27', 'Vendedor', 4967.57, '31217947438');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (275, 'Michael Clements', 24, '758.515.538-83', '2025-02-08', 'Confeiteiro', 7823.71, '45699312808');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (276, 'Christina Farmer', 41, '769.340.676-72', '2017-06-27', 'Confeiteiro', 5017.67, '40949100555');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (277, 'Dra. Clara Lopes', 65, '107.588.762-83', '2018-11-01', 'Vendedor', 4684.66, '55219779470');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (278, 'Virgilio Buenaventura Bermudez Prada', 33, '124.778.648-81', '2019-02-20', 'Confeiteiro', 6036.97, '42557724365');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (279, 'Dustin Nguyen', 19, '295.715.352-62', '2016-07-16', 'Caixa', 2330.54, '41433916113');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (280, 'Eduardo Duarte', 49, '157.906.653-25', '2017-02-21', 'Estoquista', 6700.39, '55219552585');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (281, 'Rodolfo Tórrez de la Crúz', 42, '101.420.910-28', '2017-01-07', 'Estoquista', 6127.76, '17403358946');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (282, 'Jose Miguel Molins Chico', 18, '645.972.421-31', '2025-01-25', 'Caixa', 2885.08, '52672203858');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (283, 'Nuria Santamaría', 34, '445.935.808-69', '2017-03-21', 'Estoquista', 2271.47, '25777317564');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (284, 'Robert Pierce', 31, '285.452.914-84', '2016-03-21', 'Vendedor', 3744.51, '70200490897');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (285, 'Dr. Hilda Flórez', 26, '539.546.116-86', '2024-05-27', 'Estoquista', 3355.12, '55082659246');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (286, 'Davi Luiz Santos', 27, '442.881.617-41', '2019-12-30', 'Caixa', 2353.49, '55419390007');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (287, 'Steven Jones', 51, '770.733.609-99', '2017-05-25', 'Gerente', 2410.3, '40488267484');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (288, 'Dennis Maxwell', 33, '213.838.394-22', '2024-04-02', 'Confeiteiro', 7018.12, '71266282993');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (289, 'Marina Costa', 61, '745.711.319-34', '2025-06-03', 'Confeiteiro', 4054.06, '55719482834');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (290, 'Jane Blanchard', 59, '651.907.289-63', '2019-04-01', 'Caixa', 7369.6, '66915395392');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (291, 'Ing. Jacinto Ledesma', 59, '869.174.331-10', '2019-11-15', 'Gerente', 7090.88, '53956534014');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (292, 'Stephanie Rodriguez', 57, '341.801.385-44', '2023-07-08', 'Gerente', 5772.4, '18300433805');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (293, 'Esteban Ernesto Esquivel Pizarro', 22, '232.220.998-14', '2022-09-28', 'Confeiteiro', 4451.74, '73809560388');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (294, 'Julie Pelayo Ortiz', 25, '863.609.481-55', '2025-03-22', 'Caixa', 7390.64, '96298033880');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (295, 'Brandon Scott', 31, '145.150.208-63', '2017-05-21', 'Vendedor', 2648.33, '77723469484');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (296, 'John West', 23, '123.656.127-34', '2017-06-08', 'Confeiteiro', 3685.88, '28317456617');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (297, 'Odalys de Iriarte', 29, '950.972.635-37', '2021-03-20', 'Confeiteiro', 7150.87, '24301965023');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (298, 'Jessica Smith', 60, '838.966.742-17', '2025-07-07', 'Estoquista', 2027.14, '97939140524');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (299, 'Susan Johnson', 57, '335.187.952-65', '2024-02-23', 'Estoquista', 7626.92, '58539795604');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (300, 'João Miguel Oliveira', 41, '897.314.146-48', '2025-06-28', 'Confeiteiro', 2382.67, '55119356389');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (301, 'Kim Perez', 30, '411.177.964-86', '2019-05-11', 'Gerente', 6941.77, '41758070631');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (302, 'Custodia del Hurtado', 38, '634.692.426-42', '2023-08-04', 'Vendedor', 2151.93, '47509428481');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (303, 'Daniel Olson', 42, '996.336.816-29', '2015-10-04', 'Estoquista', 3362.37, '32933641809');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (304, 'Griselda Miralles-Alarcón', 32, '686.277.161-18', '2017-10-05', 'Confeiteiro', 4600.15, '21399244032');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (305, 'Sr. Joaquim Cavalcanti', 32, '696.587.727-17', '2021-10-04', 'Estoquista', 5457.8, '55319990185');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (306, 'Clarice Caldeira', 40, '692.488.130-42', '2015-12-25', 'Caixa', 3930.77, '55849220367');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (307, 'Michael Cunningham', 55, '281.169.794-86', '2021-05-11', 'Vendedor', 7550.73, '59434410663');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (308, 'Laura Pamela Girón Vásquez', 22, '654.179.355-70', '2024-06-03', 'Gerente', 6379.86, '39674217165');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (309, 'Macario Jonatan Cabañas Pablo', 48, '623.113.629-34', '2019-01-22', 'Estoquista', 3366.64, '45732064273');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (310, 'Gabrielly Aragão', 26, '840.489.426-69', '2021-04-15', 'Estoquista', 5930.41, '55819278279');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (311, 'Felicia Wright', 41, '655.360.433-52', '2021-10-03', 'Estoquista', 3383.33, '15707706831');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (312, 'Lic. Eloisa Dávila', 43, '635.537.497-39', '2019-01-01', 'Confeiteiro', 2949.65, '19841561566');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (313, 'Vitória Silva', 64, '452.773.521-95', '2017-02-03', 'Gerente', 4781.75, '55519977687');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (314, 'Dr. Claudio Aranda', 42, '324.537.732-18', '2020-02-03', 'Gerente', 3370.56, '98316409561');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (315, 'Richard Banks', 21, '240.258.317-87', '2020-10-20', 'Estoquista', 5661.28, '16279940705');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (316, 'Rubén Caraballo', 51, '389.949.742-57', '2022-01-25', 'Caixa', 5800.17, '49651612759');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (317, 'Michael Cross', 21, '276.575.148-21', '2018-05-06', 'Confeiteiro', 4351.15, '20017605811');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (318, 'Enzo Campos', 38, '152.411.230-25', '2024-07-16', 'Gerente', 5502.04, '55219334692');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (319, 'Michael Allen', 18, '594.985.641-55', '2016-11-22', 'Confeiteiro', 7930.75, '36882423135');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (320, 'Cristina Ropero Puig', 53, '907.248.142-45', '2019-09-07', 'Caixa', 5676.41, '23674126943');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (321, 'Tracy Bell', 50, '351.115.927-55', '2017-06-03', 'Gerente', 6118.32, '21592019613');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (322, 'Abelardo Pablo Aguilar Alejandro', 36, '626.757.324-50', '2021-12-13', 'Vendedor', 6201.31, '63491943980');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (323, 'Mtro. Estela Mesa', 59, '644.791.505-51', '2023-02-11', 'Confeiteiro', 7079.19, '49449960385');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (324, 'Gregory Davies', 36, '349.364.502-89', '2022-05-11', 'Confeiteiro', 7981.78, '50200222528');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (325, 'Sandra Carbajal', 56, '860.441.248-14', '2016-10-10', 'Confeiteiro', 3437.5, '40467795901');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (326, 'Alícia Silva', 34, '761.917.728-57', '2016-01-30', 'Caixa', 3374.22, '55719724935');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (327, 'Gloria Alejandro', 30, '574.729.467-66', '2022-06-05', 'Confeiteiro', 5773.89, '29464968506');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (328, 'Emily Smith', 35, '330.903.356-99', '2025-01-03', 'Caixa', 2290.16, '67902695014');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (329, 'Heather Khan', 18, '893.274.965-45', '2021-10-03', 'Estoquista', 7096.05, '87393886875');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (330, 'Raymond Rodgers', 54, '960.516.525-56', '2018-02-23', 'Vendedor', 4593.17, '30149176089');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (331, 'Hector Folch Gutierrez', 23, '564.832.601-81', '2025-02-20', 'Caixa', 4241.22, '90684733794');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (332, 'Jeffrey Franco', 20, '730.450.691-79', '2018-01-22', 'Caixa', 2003.71, '92417752052');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (333, 'Vitória Martins', 23, '732.900.707-41', '2017-08-27', 'Vendedor', 4959.19, '55219365771');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (334, 'Ronald Morrow', 23, '536.261.393-18', '2019-06-18', 'Confeiteiro', 7305.48, '24639101275');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (335, 'Brian Harper', 54, '712.460.513-70', '2020-04-30', 'Vendedor', 7417.0, '10220185415');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (336, 'Édgar Guardiola-Martinez', 48, '861.242.168-40', '2019-05-04', 'Confeiteiro', 5830.15, '14458907440');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (337, 'Renato Marcos de la Fuente', 54, '799.715.932-23', '2023-10-21', 'Vendedor', 3742.06, '18615162782');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (338, 'Sessa Villanueva', 47, '724.662.256-45', '2022-11-20', 'Caixa', 2283.13, '79975218617');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (339, 'Adela Irizarry', 33, '276.154.629-21', '2019-06-10', 'Gerente', 5251.77, '77898837586');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (340, 'Celia Rincón Delgadillo', 42, '973.652.387-78', '2019-04-27', 'Gerente', 4617.6, '35701281702');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (341, 'Mtro. Víctor Coronado', 27, '775.354.267-14', '2017-08-17', 'Estoquista', 6663.83, '77505604995');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (342, 'James Mendez', 52, '300.981.831-31', '2021-12-03', 'Gerente', 2777.57, '47894654364');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (343, 'Ing. Emilia Padrón', 44, '675.361.760-29', '2022-12-15', 'Gerente', 3819.07, '96069911069');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (344, 'Danielle Wilson', 20, '920.792.974-25', '2022-07-18', 'Vendedor', 4170.83, '56474527112');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (345, 'Austin Joseph', 50, '764.215.275-46', '2022-12-01', 'Confeiteiro', 4186.36, '32734362512');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (346, 'Sarah Teixeira', 47, '634.177.795-15', '2023-11-15', 'Vendedor', 5513.75, '55819554923');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (347, 'Ángela de Escribano', 51, '462.612.770-73', '2022-06-22', 'Gerente', 4049.35, '51670552546');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (348, 'Haydée Oliver', 31, '294.636.101-80', '2023-04-06', 'Vendedor', 7758.12, '49211829510');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (349, 'Tina Hall', 55, '579.148.243-10', '2019-10-05', 'Caixa', 5764.96, '25899102529');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (350, 'Omar Cámara Pardo', 33, '353.491.471-17', '2017-04-04', 'Gerente', 7223.67, '50732937239');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (351, 'Henry Smith', 50, '669.923.435-14', '2020-05-08', 'Confeiteiro', 5543.88, '80489604798');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (352, 'Gloria Alfonso Tijerina Venegas', 62, '272.379.869-34', '2019-11-07', 'Estoquista', 6860.55, '91021584108');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (353, 'Kyle Wood', 35, '824.337.590-56', '2016-11-23', 'Gerente', 7127.47, '46672527035');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (354, 'Larry Mckinney', 63, '615.266.416-41', '2023-07-14', 'Confeiteiro', 7993.4, '62729237997');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (355, 'Philip Howard', 22, '939.357.965-79', '2017-09-27', 'Gerente', 4125.32, '27660124716');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (356, 'Nayeli Alonso Prieto Méndez', 53, '552.281.575-47', '2018-12-08', 'Estoquista', 3655.8, '02543818203');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (357, 'Jeremías Seco Serna', 23, '526.653.277-43', '2020-04-12', 'Caixa', 4484.7, '54965343666');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (358, 'Sr(a). Alejandra Bétancourt', 49, '825.888.293-65', '2017-09-19', 'Caixa', 5686.44, '45630373768');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (359, 'Gonzalo Heredia', 26, '421.732.795-40', '2023-03-20', 'Caixa', 5661.99, '97317503950');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (360, 'Dr. Rodrigo Caldeira', 57, '618.304.867-88', '2021-11-20', 'Confeiteiro', 2416.83, '55419170383');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (361, 'Michael Wilson', 49, '695.271.183-67', '2016-01-18', 'Confeiteiro', 5090.6, '24930529136');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (362, 'Jacqueline Hunter', 32, '907.904.616-12', '2024-05-20', 'Vendedor', 6210.12, '11847976815');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (363, 'Ruben Miller', 46, '270.382.502-52', '2019-06-19', 'Caixa', 4768.91, '05355556536');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (364, 'Kevin Roach', 18, '238.223.889-40', '2017-09-18', 'Gerente', 2285.81, '84575573723');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (365, 'Tami Vargas', 44, '499.259.107-98', '2016-03-08', 'Vendedor', 6272.66, '93260949951');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (366, 'Tomasa Arias Domínguez', 41, '936.816.711-30', '2025-05-05', 'Vendedor', 6879.75, '85312805952');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (367, 'Ramón Perales Roma', 25, '417.276.944-90', '2019-01-12', 'Estoquista', 3879.48, '12057029997');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (368, 'Matthew Gutierrez', 45, '877.536.816-11', '2021-01-10', 'Vendedor', 3950.87, '59789507038');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (369, 'Linda Mcgee', 40, '440.624.632-46', '2018-03-03', 'Vendedor', 6938.51, '57158105996');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (370, 'Amy Green', 46, '144.368.326-84', '2024-11-11', 'Estoquista', 7354.61, '42922518739');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (371, 'Jimena Morell Giralt', 52, '556.798.785-68', '2020-09-01', 'Caixa', 5752.66, '97394849145');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (372, 'Sandy Browning', 51, '635.298.670-84', '2017-06-06', 'Estoquista', 5946.27, '38031001509');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (373, 'Robin Lutz', 24, '887.798.842-85', '2020-06-01', 'Caixa', 6818.58, '12902465277');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (374, 'Srta. Lívia Pires', 22, '746.239.930-66', '2019-12-08', 'Caixa', 2656.81, '55619771994');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (375, 'Paul Brewer', 31, '384.574.788-25', '2022-10-31', 'Estoquista', 5890.43, '35408289379');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (376, 'Tonya Valentine', 61, '465.923.493-69', '2017-01-13', 'Gerente', 4537.15, '72113719302');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (377, 'Stephen Jones', 37, '837.499.125-49', '2020-06-22', 'Gerente', 4027.79, '39703633262');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (378, 'Miguel Johnson', 22, '432.202.820-42', '2019-10-06', 'Confeiteiro', 3256.37, '05482975101');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (379, 'Maria Ferreira', 31, '981.853.853-27', '2022-12-31', 'Caixa', 6902.09, '55219458640');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (380, 'Dra. Yasmin Barros', 55, '673.988.186-38', '2021-02-23', 'Estoquista', 5464.61, '55219789852');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (381, 'David Fletcher', 28, '197.701.567-88', '2025-03-07', 'Estoquista', 3471.35, '45459616012');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (382, 'Abril Alma Montenegro', 43, '303.831.852-10', '2023-05-07', 'Estoquista', 5025.73, '94208048845');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (383, 'Paulina Campos Martin', 58, '620.216.882-69', '2020-01-26', 'Estoquista', 7267.32, '15729195683');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (384, 'Natasha Logan', 34, '238.176.981-26', '2016-01-12', 'Estoquista', 5138.61, '53710563575');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (385, 'Samuel Arnold', 50, '276.241.811-91', '2021-07-27', 'Confeiteiro', 6597.85, '13304379636');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (386, 'Dr. Renan Lopes', 58, '372.692.432-12', '2024-05-23', 'Confeiteiro', 7720.71, '55119877586');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (387, 'Teodoro Bustamante Sevilla', 36, '316.976.550-10', '2021-07-18', 'Caixa', 6655.31, '79590632007');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (388, 'Augusto Souza', 23, '604.320.126-54', '2016-05-29', 'Vendedor', 7161.85, '55849492952');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (389, 'Benjamin Melo', 65, '556.180.398-69', '2016-02-04', 'Gerente', 2121.08, '55849498822');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (390, 'Theresa Jones', 60, '480.450.636-91', '2021-09-27', 'Vendedor', 4209.16, '81290695656');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (391, 'Crystal Stafford', 20, '872.596.259-88', '2024-06-17', 'Caixa', 4689.79, '04019737736');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (392, 'Robert Dickerson', 59, '654.368.188-32', '2015-10-15', 'Estoquista', 7844.94, '13925394989');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (393, 'Guilherme Carvalho', 26, '681.241.219-78', '2016-02-03', 'Confeiteiro', 4737.44, '55849937484');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (394, 'Rafaela Carvalho', 52, '970.517.807-63', '2018-08-10', 'Confeiteiro', 3893.78, '55819993977');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (395, 'Phillip Holloway', 49, '207.719.826-43', '2017-02-09', 'Gerente', 7413.22, '88978215195');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (396, 'Jodi Miller', 43, '696.217.405-42', '2018-11-19', 'Estoquista', 3314.53, '97327518174');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (397, 'Amílcar Pi Elorza', 42, '467.261.688-10', '2020-05-21', 'Confeiteiro', 7556.72, '52815794882');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (398, 'Aaron Barber', 55, '827.697.470-89', '2024-01-13', 'Caixa', 3409.33, '13714734072');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (399, 'Sarah Duncan', 57, '980.427.428-80', '2017-07-03', 'Vendedor', 5142.09, '69027656794');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (400, 'Sherri Harris', 19, '158.714.451-19', '2017-07-22', 'Vendedor', 4893.57, '21329924336');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (401, 'María Pilar Carrillo-Paz', 49, '725.627.295-12', '2020-09-15', 'Caixa', 3132.14, '18812325768');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (402, 'Christopher Gibbs', 33, '863.223.678-48', '2024-02-28', 'Caixa', 5929.63, '61288422613');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (403, 'Tyler Parker', 46, '199.524.374-58', '2015-12-25', 'Vendedor', 3094.88, '68367019976');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (404, 'José María Eutimio Viñas España', 57, '995.576.506-31', '2019-11-06', 'Confeiteiro', 4033.16, '01182883151');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (405, 'Tiffany Anderson', 43, '461.692.552-87', '2016-10-10', 'Estoquista', 4000.46, '38008477157');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (406, 'Cynthia Powers', 22, '496.648.580-49', '2024-05-28', 'Gerente', 2182.14, '61347725332');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (407, 'Leandro Fernandes', 45, '483.378.614-93', '2016-04-13', 'Gerente', 5514.27, '55519353634');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (408, 'Carolyn Phillips', 22, '585.785.608-99', '2016-08-16', 'Estoquista', 7034.3, '04720576386');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (409, 'Larry Brooks', 20, '668.399.265-26', '2016-05-13', 'Estoquista', 4477.72, '45371473952');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (410, 'Sharon Cox', 54, '109.626.534-12', '2022-04-13', 'Confeiteiro', 2750.37, '93106062220');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (411, 'Edwin Brown', 65, '385.813.502-65', '2021-03-22', 'Confeiteiro', 4263.13, '17104559976');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (412, 'Sr. Leandro Campos', 65, '605.221.810-89', '2016-10-07', 'Confeiteiro', 5388.49, '55849961106');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (413, 'Linda Córdova', 57, '182.977.640-88', '2020-05-19', 'Caixa', 2839.68, '33805048180');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (414, 'Pamela Arellano', 19, '724.876.377-74', '2021-05-03', 'Caixa', 5792.3, '26148026859');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (415, 'Hugo Ernesto Corral', 65, '143.749.437-12', '2015-12-03', 'Estoquista', 3499.95, '69750853557');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (416, 'Lic. Violeta Treviño', 48, '486.781.397-88', '2022-11-26', 'Caixa', 7788.51, '43019911626');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (417, 'Clarice da Paz', 45, '706.365.434-78', '2024-03-05', 'Caixa', 7547.05, '55319615347');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (418, 'Lorena Monteiro', 49, '939.312.468-27', '2021-05-17', 'Confeiteiro', 4650.98, '55849445208');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (419, 'Lucca Silveira', 35, '642.439.204-80', '2024-08-17', 'Confeiteiro', 4991.67, '55119725765');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (420, 'Jamie Hill', 57, '174.227.971-54', '2018-05-30', 'Confeiteiro', 6854.47, '30703957220');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (421, 'Valentina Santos', 45, '442.134.337-51', '2020-07-23', 'Vendedor', 3936.92, '55819910935');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (422, 'Milena da Mota', 33, '204.798.470-65', '2018-01-06', 'Gerente', 2054.76, '55319714112');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (423, 'Ana Trillo Alvarado', 65, '337.939.841-89', '2019-03-31', 'Confeiteiro', 7725.75, '96546441944');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (424, 'John Ortiz', 54, '799.694.732-61', '2021-11-03', 'Caixa', 3400.23, '63363060383');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (425, 'Andrea Berry', 18, '450.276.542-13', '2024-04-21', 'Caixa', 2782.67, '36370155269');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (426, 'Aurelio Mauro Vergara', 44, '518.275.814-29', '2020-06-22', 'Estoquista', 5067.02, '45260956753');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (427, 'Lucas Nancy Matías', 58, '945.505.913-57', '2019-12-13', 'Confeiteiro', 6390.77, '21905235852');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (428, 'Armida Ruth Talavera Zamora', 38, '516.219.433-56', '2019-10-11', 'Confeiteiro', 6212.56, '87840646386');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (429, 'María Luisa Campos Collado', 32, '160.892.719-10', '2020-04-23', 'Estoquista', 3738.75, '66333454784');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (430, 'Jamie Brown', 44, '528.315.869-75', '2017-11-01', 'Gerente', 2955.26, '11966880878');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (431, 'Angelica Thomas', 32, '245.488.637-42', '2021-12-15', 'Vendedor', 7311.48, '83649729445');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (432, 'Gabino Olivia Ayala Casárez', 49, '789.931.606-41', '2022-07-20', 'Confeiteiro', 6607.5, '67955563936');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (433, 'Jesse Hanna', 23, '313.424.168-45', '2024-09-04', 'Estoquista', 7692.93, '86550794275');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (434, 'Mateo Maximiliano Amo Tena', 48, '591.640.339-78', '2016-06-05', 'Vendedor', 6327.4, '86721262709');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (435, 'Poncio Feliu', 27, '779.769.433-42', '2024-02-09', 'Caixa', 2574.74, '26285134055');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (436, 'Julieta Fiol Pérez', 55, '842.438.870-50', '2016-02-22', 'Confeiteiro', 5006.54, '53951973136');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (437, 'Jose Antonio Palau Somoza', 37, '196.409.416-15', '2023-11-29', 'Caixa', 4412.99, '20521441209');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (438, 'Diego Correia', 45, '171.802.754-61', '2022-11-10', 'Estoquista', 6612.16, '55619737065');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (439, 'Bianca Campos Campos', 31, '708.615.679-31', '2019-01-13', 'Vendedor', 2920.46, '98351139068');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (440, 'Alberto Marquez Ferrando', 64, '156.178.647-74', '2019-04-07', 'Gerente', 3965.78, '25513351199');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (441, 'Eloah Lima', 46, '340.222.186-88', '2023-10-21', 'Caixa', 5212.95, '55819208498');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (442, 'Lorenzo Lima', 62, '540.206.807-41', '2016-07-17', 'Gerente', 3666.97, '55849606816');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (443, 'Prudencio Gámez Adadia', 26, '806.301.336-64', '2021-07-17', 'Vendedor', 2866.37, '85445581473');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (444, 'Humberto Peralta', 52, '339.403.969-27', '2015-10-31', 'Estoquista', 7584.34, '49360793285');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (445, 'João Vitor Ribeiro', 27, '803.992.391-74', '2021-09-19', 'Caixa', 5473.22, '55319049604');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (446, 'Ana Sofía del Alfonso', 31, '190.528.704-43', '2020-12-27', 'Confeiteiro', 7038.25, '69343117176');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (447, 'Gabino Pablo Bayona', 28, '592.302.137-30', '2017-03-29', 'Vendedor', 3432.76, '52596617092');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (448, 'Nina Vieira', 65, '578.263.838-75', '2018-10-09', 'Caixa', 4027.58, '55619657990');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (449, 'Noemí Manuel García Rael', 56, '794.268.474-28', '2021-08-09', 'Vendedor', 6044.09, '08470558975');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (450, 'Liliana Inés Montenegro', 59, '551.119.434-56', '2023-07-17', 'Vendedor', 4231.41, '84934272771');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (451, 'Kristina Morgan', 51, '785.370.993-72', '2023-02-17', 'Gerente', 3204.05, '79944713826');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (452, 'Darío Olvera', 29, '150.882.267-64', '2024-05-29', 'Estoquista', 2968.79, '54422760051');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (453, 'José Manuél Palomino Galindo', 21, '628.785.607-38', '2022-09-28', 'Caixa', 2911.87, '10254528482');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (454, 'Srta. Ana Laura da Rocha', 35, '749.528.163-70', '2017-09-01', 'Gerente', 7972.48, '55519677407');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (455, 'Tina Briggs', 61, '490.158.666-81', '2017-02-21', 'Confeiteiro', 7400.84, '32353895559');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (456, 'Lívia Barros', 27, '226.593.311-77', '2016-06-19', 'Caixa', 7787.3, '55719710854');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (457, 'Valerie Alexander', 37, '352.427.632-11', '2022-09-29', 'Confeiteiro', 7191.54, '85380394724');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (458, 'Wendy Hall', 61, '744.685.641-99', '2020-10-28', 'Estoquista', 3488.29, '19750579373');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (459, 'Eric Beck', 24, '593.330.919-50', '2017-04-03', 'Caixa', 4788.58, '76774344861');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (460, 'Joseph Johnson', 52, '215.558.570-46', '2017-01-16', 'Caixa', 4753.99, '39165767035');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (461, 'Stephany Moraes', 27, '183.870.526-69', '2015-10-09', 'Caixa', 5411.34, '55719188264');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (462, 'Dr. Camilo Ybarra', 36, '101.951.409-19', '2025-07-19', 'Estoquista', 7885.86, '69279492083');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (463, 'Lic. Martha Godoy', 52, '179.962.322-60', '2025-02-11', 'Caixa', 4867.95, '04462656149');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (464, 'Gil Saavedra', 39, '824.798.801-16', '2022-07-20', 'Gerente', 5014.63, '68950748058');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (465, 'Héctor Manzanares', 19, '196.788.948-12', '2022-10-10', 'Caixa', 2480.69, '86562257425');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (466, 'Harold Burnett', 63, '140.217.375-23', '2018-01-18', 'Estoquista', 7012.94, '75184860704');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (467, 'Serafina Cifuentes Palacio', 45, '906.125.943-38', '2016-10-06', 'Caixa', 4880.74, '81293570645');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (468, 'Francisco Nunes', 36, '135.933.698-86', '2017-07-06', 'Caixa', 5457.22, '55319316538');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (469, 'Joana Monteiro', 64, '275.503.637-41', '2022-11-17', 'Confeiteiro', 5550.83, '55519551091');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (470, 'Leticia Luisa Otero', 41, '435.588.425-64', '2017-02-14', 'Estoquista', 2113.68, '83340827469');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (471, 'Robert Davis', 21, '657.970.370-78', '2022-10-11', 'Vendedor', 5571.39, '36294478457');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (472, 'Yolanda Baker', 60, '169.658.753-40', '2020-06-20', 'Estoquista', 6559.63, '10763151992');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (473, 'Christopher Villegas', 63, '848.827.488-49', '2017-11-06', 'Vendedor', 7570.13, '63573715561');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (474, 'Leonardo Frida Collazo', 32, '973.134.113-14', '2019-07-12', 'Gerente', 2757.58, '35405833793');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (475, 'Michelle Bernard', 24, '924.601.834-30', '2022-12-03', 'Vendedor', 4099.11, '96836865132');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (476, 'Mateo Helena Mascareñas Zamora', 48, '382.815.573-88', '2017-10-19', 'Estoquista', 6491.99, '64782843028');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (477, 'Fernando Araceli Serrano Mayorga', 40, '362.964.388-65', '2019-11-04', 'Confeiteiro', 2840.03, '41856160096');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (478, 'Calebe Nascimento', 52, '634.594.915-25', '2020-04-25', 'Vendedor', 4257.42, '55719561394');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (479, 'Gerardo Blanca Perez', 57, '258.408.152-19', '2024-12-28', 'Vendedor', 2668.02, '85598802735');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (480, 'Angela Rivera DVM', 44, '130.310.439-98', '2018-05-26', 'Vendedor', 2304.48, '59397844799');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (481, 'Mtro. Carlota Loya', 31, '975.801.952-99', '2023-08-30', 'Caixa', 2801.93, '31656716063');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (482, 'Constanza Campos', 51, '504.804.159-67', '2020-07-28', 'Caixa', 5556.39, '55459288799');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (483, 'Julia Granado Cazares', 54, '688.200.664-53', '2020-06-16', 'Gerente', 6521.94, '30743460242');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (484, 'Ivonne Méndez', 19, '921.184.694-89', '2019-10-05', 'Estoquista', 3701.53, '61274510608');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (485, 'Che Bonilla-Pizarro', 51, '480.711.731-41', '2022-06-16', 'Caixa', 7797.74, '43899388296');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (486, 'Mary Riley', 48, '975.520.646-43', '2017-08-22', 'Gerente', 3102.0, '39244203192');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (487, 'Amy Booth', 25, '545.177.883-29', '2018-01-15', 'Confeiteiro', 2275.31, '81563557236');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (488, 'Gavin Murray', 53, '720.735.198-90', '2022-06-28', 'Estoquista', 7066.23, '16364881544');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (489, 'Jacinto Lloret-Piña', 21, '655.151.136-57', '2024-04-09', 'Caixa', 5732.01, '80110168968');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (490, 'Lic. Antonio Acosta', 26, '319.148.761-65', '2022-08-29', 'Confeiteiro', 6541.77, '53391246423');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (491, 'Ryan da Mata', 62, '450.257.939-11', '2019-11-06', 'Confeiteiro', 2463.01, '55419770991');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (492, 'Eloah Silveira', 61, '822.188.336-74', '2017-02-13', 'Caixa', 3213.54, '55419467871');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (493, 'Thales Pires', 65, '108.547.527-39', '2016-09-21', 'Vendedor', 4793.99, '55119449251');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (494, 'Thomas Chung', 23, '661.398.838-69', '2022-08-30', 'Vendedor', 2921.18, '22008803478');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (495, 'Daniel Carvalho', 33, '916.146.579-13', '2019-06-14', 'Caixa', 3681.11, '55849117989');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (496, 'Marilyn Gutierrez', 24, '206.732.720-68', '2017-04-01', 'Confeiteiro', 5859.55, '33763910470');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (497, 'Olivia Ruiz Montenegro', 49, '989.751.638-62', '2019-10-11', 'Caixa', 7146.3, '14781589536');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (498, 'Melissa Stafford', 26, '812.399.455-32', '2022-05-14', 'Caixa', 4015.9, '59841419505');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (499, 'Joanna Hernandez', 28, '168.798.698-94', '2021-11-10', 'Caixa', 6396.02, '73098847427');
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone) VALUES (500, 'Christine Wise', 42, '835.320.948-67', '2021-02-23', 'Confeiteiro', 5267.88, '07571717311');

-- Insere 100 Contas
INSERT INTO Conta (ID_Conta, ID_Funcionario, Data_Nascimento, Username, Senha, Telefone, Email)
SELECT
    T.n,
    T.n,
    CURDATE() - INTERVAL FLOOR(RAND() * 20000) DAY,
    CONCAT('user', T.n),
    'senha123',
    CONCAT('119', FLOOR(RAND() * 90000000) + 10000000),
    CONCAT('user', T.n, '@email.com')
FROM (SELECT a.n + b.n * 10 AS n 
      FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
                   SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, 
           (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4) b) AS T
WHERE T.n BETWEEN 1 AND 100;

-- Insere 100 Produtos no Estoque (sem fornecedor agora)
INSERT INTO Estoque (id_filial, nome_do_chocolate, quantidade, preco, data_de_validade, data_que_foi_entregue, tipo_do_chocolate, peso)
SELECT
    F.id_filial,
    CONCAT('Chocolate ', T.n),
    FLOOR(RAND() * 500) + 1,
    FLOOR(RAND() * 50) + 10,
    CURDATE() + INTERVAL FLOOR(RAND() * 365) DAY,
    CURDATE() - INTERVAL FLOOR(RAND() * 30) DAY,
    CASE FLOOR(RAND() * 4)
        WHEN 0 THEN 'Amargo'
        WHEN 1 THEN 'Ao Leite'
        WHEN 2 THEN 'Branco'
        WHEN 3 THEN 'Com Recheio'
        ELSE 'Sem Açucar'
    END,
    FLOOR(RAND() * 200) + 50
FROM Filial F
JOIN (SELECT a.n + b.n * 10 AS n 
      FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
                   SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, 
           (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL 
                   SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b) AS T
WHERE T.n BETWEEN 1 AND 100
ORDER BY RAND();


-- -----------------------------------------------------
-- Reabilita verificação de FK
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------
-- SELECTS para análise de dados
-- -----------------------------------------------------

SELECT * FROM Estoque;
SELECT * FROM Funcionario;
SELECT * FROM Conta;
SELECT * FROM Cliente;
SELECT * FROM Filial;
SELECT * FROM Vendas;
SELECT * FROM ItemVenda;
