drop database if exists NC;
create database NC;
use NC;

create table Cliente(
	id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100)
);
create table Fornecedor(
    id_fornecedor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100),
    endereco VARCHAR(200)
);
create table Estoque(
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    quantidade_em_estoque INT NOT NULL,
    categoria VARCHAR(50), /*se é trufa, barra, ovo etc*/
	id_fornecedor INT,
    FOREIGN KEY (id_fornecedor) REFERENCES Fornecedor(id_fornecedor)
);
create table Venda(
    id_venda INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    data_venda DATETIME DEFAULT NOW(),
    valor_total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);
CREATE TABLE ItemVenda (
    id_item INT AUTO_INCREMENT PRIMARY KEY,
    id_venda INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_venda) REFERENCES Venda(id_venda),
    FOREIGN KEY (id_produto) REFERENCES Estoque(id_produto)
);
create table Filiais(
	id_filial INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    endereco VARCHAR(200)
);

-- coluna para disponibilidade dos intens em estoque
alter table Estoque add column disponibilidade VARCHAR(12) default "disponível";

-- Inserções de dados (certifique-se de que a tabela Estoque tenha os dados que você precisa)
INSERT INTO Cliente (nome, telefone, email) VALUES
('Lucas Silva 1', '+55 11 90000-01', 'lucas.silva1@exemplo.com.br'),
('Mariana Souza 2', '+55 21 90000-02', 'mariana.souza2@exemplo.com.br'),
('Pedro Costa 3', '+55 31 90000-03', 'pedro.costa3@exemplo.com.br'),
('Emma Johnson 4', '+1 202-555-0104', 'emma.johnson4@example.com'),
('Liam Smith 5', '+1 202-555-0105', 'liam.smith5@example.com'),
('Olivia Brown 6', '+1 416-555-0106', 'olivia.brown6@example.ca'),
('Noah Wilson 7', '+1 416-555-0107', 'noah.wilson7@example.ca'),
('Sofia Santos 8', '+55 41 90000-08', 'sofia.santos8@exemplo.com.br'),
('Miguel Lima 9', '+55 61 90000-09', 'miguel.lima9@exemplo.com.br'),
('Isabela Rocha 10', '+55 81 90000-10', 'isabela.rocha10@exemplo.com.br'),
('Lucas Oliveira 11', '+44 20 7946-0011', 'lucas.oliveira11@example.co.uk'),
('Marta Pereira 12', '+44 20 7946-0012', 'marta.pereira12@example.co.uk'),
('Ethan Miller 13', '+1 202-555-013', 'ethan.miller13@example.com'),
('Ava Davis 14', '+1 202-555-014', 'ava.davis14@example.com'),
('Gabriel Fernandes 15', '+55 71 90000-15', 'gabriel.fernandes15@exemplo.com.br'),
('Samantha Martin 16', '+33 1 42 68 0016', 'samantha.martin16@example.fr'),
('Mateo García 17', '+34 91 123 0017', 'mateo.garcia17@example.es'),
('Lucas Ramos 18', '+55 47 90000-18', 'lucas.ramos18@exemplo.com.br'),
('Chloe Taylor 19', '+1 647-555-019', 'chloe.taylor19@example.ca'),
('Benjamin Anderson 20', '+49 30 1234-0020', 'benjamin.anderson20@example.de'),
('Helena Almeida 21', '+55 11 90000-21', 'helena.almeida21@exemplo.com.br'),
('Arthur Rocha 22', '+55 21 90000-22', 'arthur.rocha22@exemplo.com.br'),
('Laura Castro 23', '+1 202-555-023', 'laura.castro23@example.com'),
('Daniel Costa 24', '+1 202-555-024', 'daniel.costa24@example.com'),
('Nora Silva 25', '+55 81 90000-25', 'nora.silva25@exemplo.com.br'),
('Hugo Alves 26', '+55 31 90000-26', 'hugo.alves26@exemplo.com.br'),
('Ivy Müller 27', '+49 30 1234-0027', 'ivy.muller27@example.de'),
('Sergio Lima 28', '+55 61 90000-28', 'sergio.lima28@exemplo.com.br'),
('Paula Moreau 29', '+33 1 42 68 0029', 'paula.moreau29@example.fr'),
('Ricardo Nunes 30', '+55 41 90000-30', 'ricardo.nunes30@exemplo.com.br'),
('Aline Gomes 31', '+55 71 90000-31', 'aline.gomes31@exemplo.com.br'),
('Oliver King 32', '+1 416-555-032', 'oliver.king32@example.ca'),
('Isabela Martins 33', '+55 47 90000-33', 'isabela.martins33@exemplo.com.br'),
('Carlos Dias 34', '+55 11 90000-34', 'carlos.dias34@exemplo.com.br'),
('Maya Hughes 35', '+1 202-555-035', 'maya.hughes35@example.com'),
('Felipe Rocha 36', '+55 21 90000-36', 'felipe.rocha36@exemplo.com.br'),
('Giulia Ferreira 37', '+55 31 90000-37', 'giulia.ferreira37@exemplo.com.br'),
('Luca Conti 38', '+39 06 1234-0038', 'luca.conti38@example.it'),
('Marina Costa 39', '+55 81 90000-39', 'marina.costa39@exemplo.com.br'),
('Eduardo Silva 40', '+55 61 90000-40', 'eduardo.silva40@exemplo.com.br'),
('Nina Campos 41', '+55 11 90000-41', 'nina.campos41@exemplo.com.br'),
('Theo Martins 42', '+1 202-555-042', 'theo.martins42@example.com'),
('Alice Rocha 43', '+55 21 90000-43', 'alice.rocha43@exemplo.com.br'),
('Vitor Sousa 44', '+55 31 90000-44', 'vitor.sousa44@exemplo.com.br'),
('Camila Nobre 45', '+55 41 90000-45', 'camila.nobre45@exemplo.com.br'),
('Rafael Pereira 46', '+55 71 90000-46', 'rafael.pereira46@exemplo.com.br'),
('Sofia Marques 47', '+55 47 90000-47', 'sofia.marques47@exemplo.com.br'),
('Davi Oliveira 48', '+1 647-555-048', 'davi.oliveira48@example.ca'),
('Bruna Alves 49', '+55 61 90000-49', 'bruna.alves49@exemplo.com.br'),
('Igor Lima 50', '+55 11 90000-50', 'igor.lima50@exemplo.com.br'),
('Helena Costa 51', '+44 20 7946-0051', 'helena.costa51@example.co.uk'),
('Marcos Pinto 52', '+55 21 90000-52', 'marcos.pinto52@exemplo.com.br'),
('Lara Vieira 53', '+55 31 90000-53', 'lara.vieira53@exemplo.com.br'),
('Pedro Henrique 54', '+1 202-555-054', 'pedro.henrique54@example.com'),
('Bianca Moreira 55', '+55 81 90000-55', 'bianca.moreira55@exemplo.com.br'),
('Matheus Rocha 56', '+55 41 90000-56', 'matheus.rocha56@exemplo.com.br'),
('Sabrina Lopes 57', '+33 1 42 68 0057', 'sabrina.lopes57@example.fr'),
('Lucas Azevedo 58', '+55 71 90000-58', 'lucas.azevedo58@exemplo.com.br'),
('Marcos Silva 59', '+55 47 90000-59', 'marcos.silva59@exemplo.com.br'),
('Ana Clara 60', '+1 416-555-060', 'ana.clara60@example.ca'),
('Jonas Pereira 61', '+55 61 90000-61', 'jonas.pereira61@exemplo.com.br'),
('Sergio Oliveira 62', '+55 11 90000-62', 'sergio.oliveira62@exemplo.com.br'),
('Luna Reis 63', '+49 30 1234-0063', 'luna.reis63@example.de'),
('Enzo Costa 64', '+55 21 90000-64', 'enzo.costa64@exemplo.com.br'),
('Mirella Rocha 65', '+55 31 90000-65', 'mirella.rocha65@exemplo.com.br'),
('Vera Santos 66', '+55 41 90000-66', 'vera.santos66@exemplo.com.br'),
('Cecilia Ramos 67', '+34 91 123 0067', 'cecilia.ramos67@example.es'),
('Igor Fernandes 68', '+55 71 90000-68', 'igor.fernandes68@exemplo.com.br'),
('Renata Lima 69', '+55 47 90000-69', 'renata.lima69@exemplo.com.br'),
('Bruno Alves 70', '+1 202-555-070', 'bruno.alves70@example.com'),
('Cliente Teste 71', '+55 11 90000-71', 'cliente.teste71@exemplo.com.br'),
('Cliente Teste 72', '+55 21 90000-72', 'cliente.teste72@exemplo.com.br'),
('Cliente Teste 73', '+1 202-555-073', 'cliente.teste73@example.com'),
('Cliente Teste 74', '+1 416-555-074', 'cliente.teste74@example.ca'),
('Cliente Teste 75', '+33 1 42 68 0075', 'cliente.teste75@example.fr'),
('Cliente Teste 76', '+49 30 1234-0076', 'cliente.teste76@example.de'),
('Cliente Teste 77', '+34 91 123 0077', 'cliente.teste77@example.es'),
('Cliente Teste 78', '+39 06 1234-0078', 'cliente.teste78@example.it'),
('Cliente Teste 79', '+55 31 90000-79', 'cliente.teste79@exemplo.com.br'),
('Cliente Teste 80', '+55 41 90000-80', 'cliente.teste80@exemplo.com.br'),
('Cliente Teste 81', '+55 61 90000-81', 'cliente.teste81@exemplo.com.br'),
('Cliente Teste 82', '+1 647-555-082', 'cliente.teste82@example.ca'),
('Cliente Teste 83', '+1 202-555-083', 'cliente.teste83@example.com'),
('Cliente Teste 84', '+55 11 90000-84', 'cliente.teste84@exemplo.com.br'),
('Cliente Teste 85', '+55 21 90000-85', 'cliente.teste85@exemplo.com.br'),
('Cliente Teste 86', '+55 31 90000-86', 'cliente.teste86@exemplo.com.br'),
('Cliente Teste 87', '+55 41 90000-87', 'cliente.teste87@exemplo.com.br'),
('Cliente Teste 88', '+55 61 90000-88', 'cliente.teste88@exemplo.com.br'),
('Cliente Teste 89', '+44 20 7946-0089', 'cliente.teste89@example.co.uk'),
('Cliente Teste 90', '+49 30 1234-0090', 'cliente.teste90@example.de'),
('Cliente Teste 91', '+55 11 90000-91', 'cliente.teste91@exemplo.com.br'),
('Cliente Teste 92', '+55 21 90000-92', 'cliente.teste92@exemplo.com.br'),
('Cliente Teste 93', '+1 202-555-093', 'cliente.teste93@example.com'),
('Cliente Teste 94', '+1 416-555-094', 'cliente.teste94@example.ca'),
('Cliente Teste 95', '+33 1 42 68 0095', 'cliente.teste95@example.fr'),
('Cliente Teste 96', '+34 91 123 0096', 'cliente.teste96@example.es'),
('Cliente Teste 97', '+39 06 1234-0097', 'cliente.teste97@example.it'),
('Cliente Teste 98', '+55 31 90000-98', 'cliente.teste98@exemplo.com.br'),
('Cliente Teste 99', '+55 41 90000-99', 'cliente.teste99@exemplo.com.br'),
('Cliente Teste 100', '+55 61 90000-100', 'cliente.teste100@exemplo.com.br');


INSERT INTO Fornecedor (nome, telefone, email, endereco) VALUES
('Chocolate Brasil Ltda', '+55 11 97000-001', 'contato1@chocobrasil.com.br', 'R. do Cacau, 100 - SP'),
('Trufas Import CA', '+1 416-555-200', 'sales1@trufas.ca', '88 King St, Toronto'),
('Cocoa US Inc', '+1 202-555-201', 'info@cocoaus.com', '10th Ave, Washington'),
('Bombons Europa', '+33 1 42 68 220', 'europa@bombons.fr', '12 Rue du Chocolat, Paris'),
('Delicias Alem', '+49 30 1234-221', 'info@delicias.de', 'Berliner Str. 5, Berlin'),
('Sweet Suppliers 6', '+55 21 97000-006', 'fornecedor6@exemplo.com.br', 'Av. Central, 60 - RJ'),
('Cacau Nordic 7', '+44 20 7946-207', 'nordic7@cacau.uk', '20 Chocolate Ln, London'),
('Cocoa Express 8', '+1 416-555-208', 'express8@cocoa.ca', '55 Queen St, Toronto'),
('Trufa Master 9', '+55 31 97000-009', 'master9@trufa.com.br', 'R. Doce, 9 - MG'),
('International Cocoa 10', '+1 202-555-210', 'intl10@cocoa.com', '100 Market St, NY'),
('Fornecedor Teste 11', '+55 41 97000-011', 'fornecedor11@exemplo.com.br', 'Av Teste, 11'),
('Fornecedor Teste 12', '+55 61 97000-012', 'fornecedor12@exemplo.com.br', 'R Teste, 12'),
('Fornecedor Teste 13', '+33 1 42 68 213', 'fornecedor13@example.fr', '13 Rue Teste, Paris'),
('Fornecedor Teste 14', '+49 30 1234-214', 'fornecedor14@example.de', '14 Strasse, Berlin'),
('Fornecedor Teste 15', '+1 202-555-215', 'fornecedor15@example.com', '15 Ave, Washington'),
('Fornecedor Teste 16', '+1 416-555-216', 'fornecedor16@example.ca', '16 St, Toronto'),
('Fornecedor Teste 17', '+55 11 97000-017', 'fornecedor17@exemplo.com.br', 'R Forn, 17'),
('Fornecedor Teste 18', '+55 21 97000-018', 'fornecedor18@exemplo.com.br', 'R Forn, 18'),
('Fornecedor Teste 19', '+55 31 97000-019', 'fornecedor19@exemplo.com.br', 'R Forn, 19'),
('Fornecedor Teste 20', '+55 41 97000-020', 'fornecedor20@exemplo.com.br', 'R Forn, 20'),
('Fornecedor Teste 21', '+55 61 97000-021', 'fornecedor21@exemplo.com.br', 'R Forn, 21'),
('Fornecedor Teste 22', '+44 20 7946-022', 'fornecedor22@example.co.uk', '22 Chocolate Ln'),
('Fornecedor Teste 23', '+49 30 1234-023', 'fornecedor23@example.de', '23 Strasse'),
('Fornecedor Teste 24', '+33 1 42 68 024', 'fornecedor24@example.fr', '24 Rue'),
('Fornecedor Teste 25', '+34 91 123 025', 'fornecedor25@example.es', '25 Plaza'),
('Fornecedor Teste 26', '+39 06 1234-026', 'fornecedor26@example.it', '26 Via'),
('Fornecedor Teste 27', '+1 202-555-027', 'fornecedor27@example.com', '27 Ave'),
('Fornecedor Teste 28', '+1 416-555-028', 'fornecedor28@example.ca', '28 St'),
('Fornecedor Teste 29', '+55 11 97000-029', 'fornecedor29@exemplo.com.br', 'R Forn, 29'),
('Fornecedor Teste 30', '+55 21 97000-030', 'fornecedor30@exemplo.com.br', 'R Forn, 30'),
('Fornecedor Teste 31', '+55 31 97000-031', 'fornecedor31@exemplo.com.br', 'R Forn, 31'),
('Fornecedor Teste 32', '+55 41 97000-032', 'fornecedor32@exemplo.com.br', 'R Forn, 32'),
('Fornecedor Teste 33', '+55 61 97000-033', 'fornecedor33@exemplo.com.br', 'R Forn, 33'),
('Fornecedor Teste 34', '+44 20 7946-034', 'fornecedor34@example.co.uk', '34 Chocolate Ln'),
('Fornecedor Teste 35', '+49 30 1234-035', 'fornecedor35@example.de', '35 Strasse'),
('Fornecedor Teste 36', '+33 1 42 68 036', 'fornecedor36@example.fr', '36 Rue'),
('Fornecedor Teste 37', '+34 91 123 037', 'fornecedor37@example.es', '37 Plaza'),
('Fornecedor Teste 38', '+39 06 1234-038', 'fornecedor38@example.it', '38 Via'),
('Fornecedor Teste 39', '+1 202-555-039', 'fornecedor39@example.com', '39 Ave'),
('Fornecedor Teste 40', '+1 416-555-040', 'fornecedor40@example.ca', '40 St'),
('Fornecedor Teste 41', '+55 11 97000-041', 'fornecedor41@exemplo.com.br', 'R Forn, 41'),
('Fornecedor Teste 42', '+55 21 97000-042', 'fornecedor42@exemplo.com.br', 'R Forn, 42'),
('Fornecedor Teste 43', '+55 31 97000-043', 'fornecedor43@exemplo.com.br', 'R Forn, 43'),
('Fornecedor Teste 44', '+55 41 97000-044', 'fornecedor44@exemplo.com.br', 'R Forn, 44'),
('Fornecedor Teste 45', '+55 61 97000-045', 'fornecedor45@exemplo.com.br', 'R Forn, 45'),
('Fornecedor Teste 46', '+44 20 7946-046', 'fornecedor46@example.co.uk', '46 Chocolate Ln'),
('Fornecedor Teste 47', '+49 30 1234-047', 'fornecedor47@example.de', '47 Strasse'),
('Fornecedor Teste 48', '+33 1 42 68 048', 'fornecedor48@example.fr', '48 Rue'),
('Fornecedor Teste 49', '+34 91 123 049', 'fornecedor49@example.es', '49 Plaza'),
('Fornecedor Teste 50', '+39 06 1234-050', 'fornecedor50@example.it', '50 Via'),
('Fornecedor Teste 51', '+1 202-555-051', 'fornecedor51@example.com', '51 Ave'),
('Fornecedor Teste 52', '+1 416-555-052', 'fornecedor52@example.ca', '52 St'),
('Fornecedor Teste 53', '+55 11 97000-053', 'fornecedor53@exemplo.com.br', 'R Forn, 53'),
('Fornecedor Teste 54', '+55 21 97000-054', 'fornecedor54@exemplo.com.br', 'R Forn, 54'),
('Fornecedor Teste 55', '+55 31 97000-055', 'fornecedor55@exemplo.com.br', 'R Forn, 55'),
('Fornecedor Teste 56', '+55 41 97000-056', 'fornecedor56@exemplo.com.br', 'R Forn, 56'),
('Fornecedor Teste 57', '+55 61 97000-057', 'fornecedor57@exemplo.com.br', 'R Forn, 57'),
('Fornecedor Teste 58', '+44 20 7946-058', 'fornecedor58@example.co.uk', '58 Chocolate Ln'),
('Fornecedor Teste 59', '+49 30 1234-059', 'fornecedor59@example.de', '59 Strasse'),
('Fornecedor Teste 60', '+33 1 42 68 060', 'fornecedor60@example.fr', '60 Rue'),
('Fornecedor Teste 61', '+34 91 123 061', 'fornecedor61@example.es', '61 Plaza'),
('Fornecedor Teste 62', '+39 06 1234-062', 'fornecedor62@example.it', '62 Via'),
('Fornecedor Teste 63', '+1 202-555-063', 'fornecedor63@example.com', '63 Ave'),
('Fornecedor Teste 64', '+1 416-555-064', 'fornecedor64@example.ca', '64 St'),
('Fornecedor Teste 65', '+55 11 97000-065', 'fornecedor65@exemplo.com.br', 'R Forn, 65');

INSERT INTO Estoque (nome, preco_unitario, quantidade_em_estoque, categoria, id_fornecedor) VALUES
('Trufa Clássica 1', 3.50, 200, 'Trufa', 1),
('Barra Meio Amargo 2', 8.90, 150, 'Barra', 2),
('Bombom Recheado 3', 2.10, 300, 'Bombom', 3),
('Ovo Páscoa 300g 4', 25.00, 120, 'Ovo de Páscoa', 4),
('Trufa Gourmet 5', 4.75, 180, 'Trufa', 5),
('Barra Ao Leite 6', 7.30, 220, 'Barra', 6),
('Bombom Mix 7', 2.50, 260, 'Bombom', 7),
('Ovo Páscoa Luxo 8', 45.00, 80, 'Ovo de Páscoa', 8),
('Trufa Crocante 9', 3.90, 140, 'Trufa', 9),
('Barra Branco 10', 6.50, 200, 'Barra', 10),
('Trufa Especial 11', 5.20, 160, 'Trufa', 11),
('Barra Castanha 12', 9.40, 130, 'Barra', 12),
('Bombom Amargo 13', 2.30, 210, 'Bombom', 13),
('Ovo Mini 14', 12.00, 300, 'Ovo de Páscoa', 14),
('Trufa Pimenta 15', 4.10, 190, 'Trufa', 15),
('Barra Crocante 16', 7.90, 170, 'Barra', 16),
('Bombom Caramelo 17', 2.60, 280, 'Bombom', 17),
('Ovo Recheado 18', 30.00, 110, 'Ovo de Páscoa', 18),
('Trufa Espresso 19', 3.80, 155, 'Trufa', 19),
('Barra Nozes 20', 10.50, 120, 'Barra', 20),
('Produto 21', 4.00, 210, 'Trufa', 21),
('Produto 22', 5.00, 205, 'Barra', 22),
('Produto 23', 2.75, 250, 'Bombom', 23),
('Produto 24', 15.00, 90, 'Ovo de Páscoa', 24),
('Produto 25', 3.60, 230, 'Trufa', 25),
('Produto 26', 6.80, 180, 'Barra', 26),
('Produto 27', 2.20, 260, 'Bombom', 27),
('Produto 28', 28.00, 95, 'Ovo de Páscoa', 28),
('Produto 29', 4.55, 175, 'Trufa', 29),
('Produto 30', 7.20, 200, 'Barra', 30),
('Produto 31', 4.10, 165, 'Trufa', 31),
('Produto 32', 8.00, 140, 'Barra', 32),
('Produto 33', 2.40, 220, 'Bombom', 33),
('Produto 34', 13.50, 85, 'Ovo de Páscoa', 34),
('Produto 35', 3.95, 195, 'Trufa', 35),
('Produto 36', 7.60, 175, 'Barra', 36),
('Produto 37', 2.55, 240, 'Bombom', 37),
('Produto 38', 32.00, 70, 'Ovo de Páscoa', 38),
('Produto 39', 4.20, 160, 'Trufa', 39),
('Produto 40', 6.90, 200, 'Barra', 40),
('Produto 41', 4.60, 170, 'Trufa', 41),
('Produto 42', 9.90, 130, 'Barra', 42),
('Produto 43', 2.15, 250, 'Bombom', 43),
('Produto 44', 18.00, 80, 'Ovo de Páscoa', 44),
('Produto 45', 3.70, 210, 'Trufa', 45),
('Produto 46', 6.30, 190, 'Barra', 46),
('Produto 47', 2.85, 230, 'Bombom', 47),
('Produto 48', 22.00, 100, 'Ovo de Páscoa', 48),
('Produto 49', 4.05, 180, 'Trufa', 49),
('Produto 50', 8.15, 160, 'Barra', 50),
('Produto 51', 3.99, 175, 'Trufa', 51),
('Produto 52', 11.50, 120, 'Barra', 52),
('Produto 53', 2.05, 240, 'Bombom', 53),
('Produto 54', 16.00, 95, 'Ovo de Páscoa', 54),
('Produto 55', 4.25, 190, 'Trufa', 55),
('Produto 56', 7.10, 180, 'Barra', 56),
('Produto 57', 2.45, 260, 'Bombom', 57),
('Produto 58', 26.00, 75, 'Ovo de Páscoa', 58),
('Produto 59', 4.45, 170, 'Trufa', 59),
('Produto 60', 6.75, 200, 'Barra', 60),
('Produto 61', 4.35, 165, 'Trufa', 61),
('Produto 62', 8.40, 140, 'Barra', 62),
('Produto 63', 2.65, 230, 'Bombom', 63),
('Produto 64', 19.00, 85, 'Ovo de Páscoa', 64),
('Produto 65', 3.85, 205, 'Trufa', 65),
('Produto 66', 7.45, 175, 'Barra', ((66-1)%65)+1),
('Produto 67', 2.95, 250, 'Bombom', ((67-1)%65)+1),
('Produto 68', 29.00, 60, 'Ovo de Páscoa', ((68-1)%65)+1),
('Produto 69', 4.95, 180, 'Trufa', ((69-1)%65)+1),
('Produto 70', 9.00, 150, 'Barra', ((70-1)%65)+1),
('Produto 71', 3.25, 210, 'Trufa', ((71-1)%65)+1),
('Produto 72', 5.80, 200, 'Barra', ((72-1)%65)+1),
('Produto 73', 2.10, 240, 'Bombom', ((73-1)%65)+1),
('Produto 74', 14.00, 90, 'Ovo de Páscoa', ((74-1)%65)+1),
('Produto 75', 3.60, 220, 'Trufa', ((75-1)%65)+1),
('Produto 76', 6.60, 185, 'Barra', ((76-1)%65)+1),
('Produto 77', 2.70, 230, 'Bombom', ((77-1)%65)+1),
('Produto 78', 21.00, 95, 'Ovo de Páscoa', ((78-1)%65)+1),
('Produto 79', 4.80, 175, 'Trufa', ((79-1)%65)+1),
('Produto 80', 7.85, 160, 'Barra', ((80-1)%65)+1),
('Produto 81', 3.55, 200, 'Trufa', ((81-1)%65)+1),
('Produto 82', 10.50, 130, 'Barra', ((82-1)%65)+1),
('Produto 83', 2.35, 250, 'Bombom', ((83-1)%65)+1),
('Produto 84', 17.00, 85, 'Ovo de Páscoa', ((84-1)%65)+1),
('Produto 85', 3.45, 215, 'Trufa', ((85-1)%65)+1),
('Produto 86', 6.95, 190, 'Barra', ((86-1)%65)+1),
('Produto 87', 2.25, 240, 'Bombom', ((87-1)%65)+1),
('Produto 88', 24.00, 80, 'Ovo de Páscoa', ((88-1)%65)+1),
('Produto 89', 4.10, 180, 'Trufa', ((89-1)%65)+1),
('Produto 90', 8.60, 150, 'Barra', ((90-1)%65)+1),
('Produto 91', 3.15, 210, 'Trufa', ((91-1)%65)+1),
('Produto 92', 9.75, 140, 'Barra', ((92-1)%65)+1),
('Produto 93', 2.05, 260, 'Bombom', ((93-1)%65)+1),
('Produto 94', 12.00, 100, 'Ovo de Páscoa', ((94-1)%65)+1),
('Produto 95', 3.99, 200, 'Trufa', ((95-1)%65)+1),
('Produto 96', 6.40, 180, 'Barra', ((96-1)%65)+1),
('Produto 97', 2.55, 230, 'Bombom', ((97-1)%65)+1),
('Produto 98', 27.00, 70, 'Ovo de Páscoa', ((98-1)%65)+1),
('Produto 99', 4.65, 160, 'Trufa', ((99-1)%65)+1),
('Produto 100', 7.25, 200, 'Barra', ((100-1)%65)+1);

INSERT INTO Filiais (nome, endereco) VALUES
('Filial Centro 1', 'R. Principal, 1'),
('Filial Norte 2', 'Av. Norte, 2'),
('Filial Sul 3', 'Av. Sul, 3'),
('Filial Leste 4', 'R. Leste, 4'),
('Filial Oeste 5', 'R. Oeste, 5'),
('Filial Teste 6', 'R. Teste, 6'),
('Filial Teste 7', 'R. Teste, 7'),
('Filial Teste 8', 'R. Teste, 8'),
('Filial Teste 9', 'R. Teste, 9'),
('Filial Teste 10', 'R. Teste, 10'),
('Filial Teste 11', 'R. Teste, 11'),
('Filial Teste 12', 'R. Teste, 12'),
('Filial Teste 13', 'R. Teste, 13'),
('Filial Teste 14', 'R. Teste, 14'),
('Filial Teste 15', 'R. Teste, 15'),
('Filial Teste 16', 'R. Teste, 16'),
('Filial Teste 17', 'R. Teste, 17'),
('Filial Teste 18', 'R. Teste, 18'),
('Filial Teste 19', 'R. Teste, 19'),
('Filial Teste 20', 'R. Teste, 20'),
('Filial Teste 21', 'R. Teste, 21'),
('Filial Teste 22', 'R. Teste, 22'),
('Filial Teste 23', 'R. Teste, 23'),
('Filial Teste 24', 'R. Teste, 24'),
('Filial Teste 25', 'R. Teste, 25'),
('Filial Teste 26', 'R. Teste, 26'),
('Filial Teste 27', 'R. Teste, 27'),
('Filial Teste 28', 'R. Teste, 28'),
('Filial Teste 29', 'R. Teste, 29'),
('Filial Teste 30', 'R. Teste, 30'),
('Filial Teste 31', 'R. Teste, 31'),
('Filial Teste 32', 'R. Teste, 32'),
('Filial Teste 33', 'R. Teste, 33'),
('Filial Teste 34', 'R. Teste, 34'),
('Filial Teste 35', 'R. Teste, 35'),
('Filial Teste 36', 'R. Teste, 36'),
('Filial Teste 37', 'R. Teste, 37'),
('Filial Teste 38', 'R. Teste, 38'),
('Filial Teste 39', 'R. Teste, 39'),
('Filial Teste 40', 'R. Teste, 40'),
('Filial Teste 41', 'R. Teste, 41'),
('Filial Teste 42', 'R. Teste, 42'),
('Filial Teste 43', 'R. Teste, 43'),
('Filial Teste 44', 'R. Teste, 44'),
('Filial Teste 45', 'R. Teste, 45'),
('Filial Teste 46', 'R. Teste, 46'),
('Filial Teste 47', 'R. Teste, 47'),
('Filial Teste 48', 'R. Teste, 48'),
('Filial Teste 49', 'R. Teste, 49'),
('Filial Teste 50', 'R. Teste, 50'),
('Filial Teste 51', 'R. Teste, 51'),
('Filial Teste 52', 'R. Teste, 52'),
('Filial Teste 53', 'R. Teste, 53'),
('Filial Teste 54', 'R. Teste, 54'),
('Filial Teste 55', 'R. Teste, 55'),
('Filial Teste 56', 'R. Teste, 56'),
('Filial Teste 57', 'R. Teste, 57'),
('Filial Teste 58', 'R. Teste, 58'),
('Filial Teste 59', 'R. Teste, 59'),
('Filial Teste 60', 'R. Teste, 60'),
('Filial Teste 61', 'R. Teste, 61'),
('Filial Teste 62', 'R. Teste, 62'),
('Filial Teste 63', 'R. Teste, 63'),
('Filial Teste 64', 'R. Teste, 64'),
('Filial Teste 65', 'R. Teste, 65'),
('Filial Teste 66', 'R. Teste, 66'),
('Filial Teste 67', 'R. Teste, 67'),
('Filial Teste 68', 'R. Teste, 68'),
('Filial Teste 69', 'R. Teste, 69'),
('Filial Teste 70', 'R. Teste, 70'),
('Filial Teste 71', 'R. Teste, 71'),
('Filial Teste 72', 'R. Teste, 72'),
('Filial Teste 73', 'R. Teste, 73'),
('Filial Teste 74', 'R. Teste, 74'),
('Filial Teste 75', 'R. Teste, 75'),
('Filial Teste 76', 'R. Teste, 76'),
('Filial Teste 77', 'R. Teste, 77'),
('Filial Teste 78', 'R. Teste, 78'),
('Filial Teste 79', 'R. Teste, 79'),
('Filial Teste 80', 'R. Teste, 80'),
('Filial Teste 81', 'R. Teste, 81'),
('Filial Teste 82', 'R. Teste, 82'),
('Filial Teste 83', 'R. Teste, 83'),
('Filial Teste 84', 'R. Teste, 84'),
('Filial Teste 85', 'R. Teste, 85'),
('Filial Teste 86', 'R. Teste, 86'),
('Filial Teste 87', 'R. Teste, 87'),
('Filial Teste 88', 'R. Teste, 88'),
('Filial Teste 89', 'R. Teste, 89'),
('Filial Teste 90', 'R. Teste, 90'),
('Filial Teste 91', 'R. Teste, 91'),
('Filial Teste 92', 'R. Teste, 92'),
('Filial Teste 93', 'R. Teste, 93'),
('Filial Teste 94', 'R. Teste, 94'),
('Filial Teste 95', 'R. Teste, 95'),
('Filial Teste 96', 'R. Teste, 96'),
('Filial Teste 97', 'R. Teste, 97'),
('Filial Teste 98', 'R. Teste, 98'),
('Filial Teste 99', 'R. Teste, 99'),
('Filial Teste 100', 'R. Teste, 100');


-- PROCEDURES
-- ----------------------------------------------------
USE NC;
DROP PROCEDURE IF EXISTS insert_item_venda;

DELIMITER $$
CREATE PROCEDURE insert_item_venda(
    IN p_id_venda INT,
    IN p_id_produto INT,
    IN p_quantidade INT
)
BEGIN
    DECLARE v_estoque INT;
    DECLARE v_preco DECIMAL(10,2);

    -- Busca a quantidade em estoque e o preço
    SELECT quantidade_em_estoque, preco_unitario
    INTO v_estoque, v_preco
    FROM Estoque
    WHERE id_produto = p_id_produto;

    -- Validação de estoque e produto
    IF v_estoque IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Produto não encontrado no estoque.';
    ELSEIF v_estoque < p_quantidade THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Estoque insuficiente.';
    ELSE
        -- Insere o item na tabela de vendas
        INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario)
        VALUES (p_id_venda, p_id_produto, p_quantidade, v_preco);
    END IF;
END$$

DELIMITER ;

-- TRIGGERS
-- ----------------------------------------------------

-- TRIGGER: Atualiza o estoque e o valor total da venda APÓS a inserção de um ItemVenda
DROP TRIGGER IF EXISTS trg_after_itemvenda_insert;

DELIMITER $$
CREATE TRIGGER trg_after_itemvenda_insert
AFTER INSERT ON ItemVenda
FOR EACH ROW
BEGIN
    -- Atualiza o valor total da venda
    UPDATE Venda
    SET valor_total = IFNULL(valor_total, 0) + (NEW.quantidade * NEW.preco_unitario)
    WHERE id_venda = NEW.id_venda;

    -- Atualiza o estoque do produto vendido
    UPDATE Estoque
    SET quantidade_em_estoque = quantidade_em_estoque - NEW.quantidade
    WHERE id_produto = NEW.id_produto;
END$$
DELIMITER ;

-- TRIGGER: Atualiza o valor_total da venda ao remover um item
DROP TRIGGER IF EXISTS trg_after_itemvenda_delete;
DELIMITER $$
CREATE TRIGGER trg_after_itemvenda_delete
AFTER DELETE ON ItemVenda
FOR EACH ROW
BEGIN
    UPDATE Venda
    SET valor_total = valor_total - (OLD.quantidade * OLD.preco_unitario)
    WHERE id_venda = OLD.id_venda;
END$$
DELIMITER ;

-- TRIGGER: Atualiza o valor_total da venda ao atualizar um item
DROP TRIGGER IF EXISTS trg_after_itemvenda_update;
DELIMITER $$
CREATE TRIGGER trg_after_itemvenda_update
AFTER UPDATE ON ItemVenda
FOR EACH ROW
BEGIN
    UPDATE Venda
    SET valor_total = valor_total
    + (NEW.quantidade * NEW.preco_unitario)
    - (OLD.quantidade * OLD.preco_unitario)
    WHERE id_venda = NEW.id_venda;
END$$
DELIMITER ;

-- TRIGGER: Atualiza o status de disponibilidade do produto ANTES da atualização do Estoque
DROP TRIGGER IF EXISTS trg_before_estoque_update;

DELIMITER $$
CREATE TRIGGER trg_before_estoque_update
BEFORE UPDATE ON Estoque
FOR EACH ROW
BEGIN
    IF NEW.quantidade_em_estoque <= 0 THEN
        SET NEW.disponibilidade = 'indisponível';
    ELSE
        SET NEW.disponibilidade = 'disponível';
    END IF;
END$$

DELIMITER ;

-- Testes de inserção de dados
-- ----------------------------------------------------
-- Insere uma venda
INSERT INTO Venda (id_cliente, data_venda, valor_total) VALUES
(1, NOW(), 0),(2, NOW(), 0),(3, NOW(), 0),(4, NOW(), 0),(5, NOW(), 0),
(6, NOW(), 0),(7, NOW(), 0),(8, NOW(), 0),(9, NOW(), 0),(10, NOW(), 0),
(11, NOW(), 0),(12, NOW(), 0),(13, NOW(), 0),(14, NOW(), 0),(15, NOW(), 0),
(16, NOW(), 0),(17, NOW(), 0),(18, NOW(), 0),(19, NOW(), 0),(20, NOW(), 0),
(21, NOW(), 0),(22, NOW(), 0),(23, NOW(), 0),(24, NOW(), 0),(25, NOW(), 0),
(26, NOW(), 0),(27, NOW(), 0),(28, NOW(), 0),(29, NOW(), 0),(30, NOW(), 0),
(31, NOW(), 0),(32, NOW(), 0),(33, NOW(), 0),(34, NOW(), 0),(35, NOW(), 0),
(36, NOW(), 0),(37, NOW(), 0),(38, NOW(), 0),(39, NOW(), 0),(40, NOW(), 0),
(41, NOW(), 0),(42, NOW(), 0),(43, NOW(), 0),(44, NOW(), 0),(45, NOW(), 0),
(46, NOW(), 0),(47, NOW(), 0),(48, NOW(), 0),(49, NOW(), 0),(50, NOW(), 0),
(51, NOW(), 0),(52, NOW(), 0),(53, NOW(), 0),(54, NOW(), 0),(55, NOW(), 0),
(56, NOW(), 0),(57, NOW(), 0),(58, NOW(), 0),(59, NOW(), 0),(60, NOW(), 0),
(61, NOW(), 0),(62, NOW(), 0),(63, NOW(), 0),(64, NOW(), 0),(65, NOW(), 0),
(66, NOW(), 0),(67, NOW(), 0),(68, NOW(), 0),(69, NOW(), 0),(70, NOW(), 0),
(71, NOW(), 0),(72, NOW(), 0),(73, NOW(), 0),(74, NOW(), 0),(75, NOW(), 0),
(76, NOW(), 0),(77, NOW(), 0),(78, NOW(), 0),(79, NOW(), 0),(80, NOW(), 0),
(81, NOW(), 0),(82, NOW(), 0),(83, NOW(), 0),(84, NOW(), 0),(85, NOW(), 0),
(86, NOW(), 0),(87, NOW(), 0),(88, NOW(), 0),(89, NOW(), 0),(90, NOW(), 0),
(91, NOW(), 0),(92, NOW(), 0),(93, NOW(), 0),(94, NOW(), 0),(95, NOW(), 0),
(96, NOW(), 0),(97, NOW(), 0),(98, NOW(), 0),(99, NOW(), 0),(100, NOW(), 0);

-- Insere um item de venda usando a procedure corrigida
-- Agora, você pode chamar a procedure, mas com um id_produto válido.
-- O produto com id_produto 5 existe, então o erro "Produto não encontrado no estoque" não acontecerá.
CALL insert_item_venda(1, 5, 3);
-- Insere uma segunda venda para o cliente com id 2
INSERT INTO Venda (id_cliente, valor_total) VALUES (2, 0);

-- Insere um item para a segunda venda (id_venda 2)
-- Produto 10, com 2 unidades
CALL insert_item_venda(2, 10, 2);

-- Insere um segundo item para a mesma venda
-- Produto 15, com 1 unidade
CALL insert_item_venda(2, 15, 1);

-- Insere uma terceira venda para o cliente com id 10
INSERT INTO Venda (id_cliente, valor_total) VALUES (10, 0);

-- Insere um item para a terceira venda (id_venda 3)
-- Produto 5, com 5 unidades
CALL insert_item_venda(3, 5, 5);

-- Insere uma quarta venda para o cliente com id 5
INSERT INTO Venda (id_cliente, valor_total) VALUES (5, 0);

-- Insere um item para a quarta venda (id_venda 4)
-- Produto 20, com 10 unidades
CALL insert_item_venda(4, 20, 10);


SELECT * FROM Cliente;

SELECT * FROM Fornecedor;

SELECT * FROM Estoque;

SELECT * FROM Venda;

SELECT * FROM ItemVenda;

SELECT * FROM Filiais;