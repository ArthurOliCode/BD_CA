DROP DATABASE IF EXISTS ChocolateriaUnificada;
CREATE DATABASE ChocolateriaUnificada;
USE ChocolateriaUnificada;

-- Desabilita a verificação de chaves estrangeiras para evitar erros durante as inserções
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------
-- ESTRUTURA DAS TABELAS (ATUALIZADA CONFORME O DOCUMENTO)
-- -----------------------------------------------------

-- Tabela Fornecedor
CREATE TABLE Fornecedor (
    id_fornecedor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cnpj VARCHAR(20),
    telefone VARCHAR(20),
    email VARCHAR(100),
    endereco VARCHAR(200),
    contato VARCHAR(50),
    fornecimento VARCHAR(50),
    cep VARCHAR(10),
    municipio VARCHAR(100),
    estado VARCHAR(50),
    pais VARCHAR(50),
    horario_funcionamento VARCHAR(50),
    horario_que_fecha VARCHAR(50)
);

-- Tabela Estoque (Corrigida com colunas faltantes)
CREATE TABLE Estoque (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    id_fornecedor INT,
    id_filial VARCHAR(4),
    nome_do_chocolate VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL,
    preco DECIMAL(10, 2),
    data_de_validade DATE,
    data_que_foi_entregue DATE,
    tipo_do_chocolate VARCHAR(100),
    peso DECIMAL(10, 2),
    FOREIGN KEY (id_fornecedor) REFERENCES Fornecedor(id_fornecedor),
    FOREIGN KEY (id_filial) REFERENCES Filial(id_filial)
);

-- Tabela Funcionario
CREATE TABLE Funcionario (
    id_funcionario INT PRIMARY KEY AUTO_INCREMENT,
    id_conta INT,
    nome VARCHAR(100) NOT NULL,
    idade INT,
    cpf VARCHAR(15),
    data_entrada DATE,
    cargo VARCHAR(100) NOT NULL,
    salario DECIMAL(10, 2),
    telefone VARCHAR(20)
);

-- Tabela Conta
CREATE TABLE Conta (
    ID_Conta INT PRIMARY KEY,
    ID_Funcionario INT,
    Data_Nascimento DATE,
    Username VARCHAR(50),
    Senha VARCHAR(50),
    Telefone VARCHAR(20),
    Email VARCHAR(50)
);

-- Tabela Cliente (Corrigida com colunas faltantes)
CREATE TABLE Cliente (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    id_conta INT,
    id_filial VARCHAR(4),
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100),
    cpf VARCHAR(15),
    rg VARCHAR(15),
    data_de_nascimento DATE,
    idade INT,
    endereco VARCHAR(200),
    cep VARCHAR(10),
    bairro VARCHAR(100),
    estado VARCHAR(50),
    municipio VARCHAR(100),
    pais VARCHAR(50),
    FOREIGN KEY (id_filial) REFERENCES Filial(id_filial)
);

-- Tabela Filial
CREATE TABLE Filial (
    id_filial VARCHAR(4) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    endereco VARCHAR(200),
    telefone VARCHAR(20),
    cep VARCHAR(10),
    cnpj VARCHAR(20),
    bairro VARCHAR(100),
    estado VARCHAR(50),
    municipio VARCHAR(100),
    quantidade_de_funcionarios INT,
    clientes_por_dia INT,
    email VARCHAR(100),
    pais VARCHAR(50)
);

-- Tabela Vendas
CREATE TABLE Vendas (
    id_venda INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    id_filial VARCHAR(4),
    data_da_compra DATE,
    valor_total DECIMAL(10, 2),
    status VARCHAR(50),
    forma_de_pagamento VARCHAR(50),
    data_do_envio DATE,
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_filial) REFERENCES Filial(id_filial)
);

-- Tabela ItemVenda
CREATE TABLE ItemVenda (
    id_item_venda INT AUTO_INCREMENT PRIMARY KEY,
    id_venda INT,
    id_produto INT,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_venda) REFERENCES Vendas(id_venda),
    FOREIGN KEY (id_produto) REFERENCES Estoque(id_produto)
);

-- -----------------------------------------------------
-- INSERÇÃO DE DADOS
-- -----------------------------------------------------

-- Insere 50 Fornecedores
INSERT INTO Fornecedor (nome, cnpj, telefone, email, endereco, contato, fornecimento, cep, municipio, estado, pais)
SELECT
    CONCAT('Fornecedor ', T.n),
    CONCAT(T.n, '00010001', T.n),
    CONCAT('119', FLOOR(RAND() * 90000000) + 10000000),
    CONCAT('fornecedor', T.n, '@email.com'),
    'Rua das Doces, 123',
    'Contato Principal',
    'Chocolate em barra',
    '01000-000',
    'Sao Paulo',
    'SP',
    'Brasil'
FROM (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4) b) AS T
WHERE T.n BETWEEN 1 AND 50;

-- Insere 20 Filiais (CF01 e FL01-FL20)
INSERT INTO Filial (id_filial, nome, endereco, telefone, cep, cnpj, bairro, estado, municipio, quantidade_de_funcionarios, clientes_por_dia, email, pais) VALUES
('CF01', 'Empresa Chefe', 'Av. Paulista, 1000', '1133334444', '01310-100', '01.234.567/0001-89', 'Bela Vista', 'SP', 'São Paulo', 50, 100, 'matriz@email.com', 'Brasil');
INSERT INTO Filial (id_filial, nome, endereco, telefone, cep, cnpj, bairro, estado, municipio, quantidade_de_funcionarios, clientes_por_dia, email, pais)
SELECT
    CONCAT('FL', LPAD(T.n, 2, '0')),
    CONCAT('Filial ', LPAD(T.n, 2, '0')),
    CASE WHEN RAND() > 0.5 THEN 'Rua dos Chocolates, 10' ELSE 'Chocolate Ave, 500' END,
    CASE WHEN RAND() > 0.5 THEN '119' ELSE '613' END,
    CASE WHEN RAND() > 0.5 THEN '01000-000' ELSE 'M4W 1W2' END,
    CASE WHEN RAND() > 0.5 THEN '01.234.567/0001-89' ELSE '99.887.765/0001-23' END,
    CASE WHEN RAND() > 0.5 THEN 'Centro' ELSE 'Downtown' END,
    CASE WHEN RAND() > 0.5 THEN 'SP' ELSE 'ON' END,
    CASE WHEN RAND() > 0.5 THEN 'São Paulo' ELSE 'Toronto' END,
    FLOOR(RAND() * 20) + 10,
    FLOOR(RAND() * 200) + 50,
    CONCAT('filial', LPAD(T.n, 2, '0'), '@email.com'),
    CASE WHEN RAND() > 0.5 THEN 'Brasil' ELSE 'Canadá' END
FROM (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1) b) AS T
WHERE T.n BETWEEN 1 AND 20;

-- Insere 200 Clientes (Corrigido com dados do Brasil e do Canadá)
INSERT INTO Cliente (id_conta, id_filial, nome, telefone, email, cpf, rg, data_de_nascimento, idade, endereco, cep, bairro, estado, municipio, pais)
SELECT
    NULL,
    F.id_filial,
    CONCAT('Cliente ', T.n),
    CASE WHEN F.pais = 'Brasil' THEN CONCAT('119', FLOOR(RAND() * 90000000) + 10000000) ELSE CONCAT('613', FLOOR(RAND() * 9000000) + 1000000) END,
    CONCAT('cliente', T.n, '@email.com'),
    CASE WHEN F.pais = 'Brasil' THEN CONCAT(FLOOR(RAND() * 999), '.', FLOOR(RAND() * 999), '.', FLOOR(RAND() * 999), '-', FLOOR(RAND() * 99)) ELSE NULL END,
    CASE WHEN F.pais = 'Brasil' THEN CONCAT(FLOOR(RAND() * 99), '.', FLOOR(RAND() * 999), '.', FLOOR(RAND() * 999)) ELSE CONCAT(FLOOR(RAND() * 9999), '-', LPAD(T.n, 3, '0')) END,
    CURDATE() - INTERVAL FLOOR(RAND() * 20000) DAY,
    FLOOR(RAND() * 40) + 20,
    CASE WHEN F.pais = 'Brasil' THEN 'Rua das Rosas, 456' ELSE 'Maple Street, 10' END,
    CASE WHEN F.pais = 'Brasil' THEN CONCAT(FLOOR(RAND() * 99999), '-', FLOOR(RAND() * 999)) ELSE CONCAT('M1A', FLOOR(RAND() * 99999)) END,
    CASE WHEN F.pais = 'Brasil' THEN 'Jardim da Gloria' ELSE 'North York' END,
    CASE WHEN F.pais = 'Brasil' THEN 'SP' ELSE 'ON' END,
    CASE WHEN F.pais = 'Brasil' THEN 'São Paulo' ELSE 'Toronto' END,
    F.pais
FROM Filial F
JOIN (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b) AS T
WHERE T.n BETWEEN 1 AND 200
ORDER BY RAND();


-- Insere 100 Funcionários
INSERT INTO Funcionario (id_conta, nome, idade, cpf, data_entrada, cargo, salario, telefone)
SELECT
    T.n,
    CONCAT('Funcionario ', T.n),
    FLOOR(RAND() * 40) + 20,
    CONCAT('111222333', LPAD(T.n, 3, '0')),
    CURDATE() - INTERVAL FLOOR(RAND() * 1000) DAY,
    CASE FLOOR(RAND() * 4)
        WHEN 0 THEN 'Gerente'
        WHEN 1 THEN 'Vendedor'
        WHEN 2 THEN 'Confeiteiro'
        WHEN 3 THEN 'Caixa'
        ELSE 'Estoquista'
    END,
    FLOOR(RAND() * 4000) + 2000,
    CONCAT('119', FLOOR(RAND() * 90000000) + 10000000)
FROM (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4) b) AS T
WHERE T.n BETWEEN 1 AND 100;

-- Insere 100 Contas
INSERT INTO Conta (ID_Conta, ID_Funcionario, Data_Nascimento, Username, Senha, Telefone, Email)
SELECT
    T.n,
    T.n,
    CURDATE() - INTERVAL FLOOR(RAND() * 20000) DAY,
    CONCAT('user', T.n),
    'senha123',
    CONCAT('119', FLOOR(RAND() * 90000000) + 10000000),
    CONCAT('user', T.n, '@email.com')
FROM (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4) b) AS T
WHERE T.n BETWEEN 1 AND 100;

-- Insere 100 Produtos no Estoque (Corrigido com dados do Brasil e do Canadá)
INSERT INTO Estoque (id_fornecedor, id_filial, nome_do_chocolate, quantidade, preco, data_de_validade, data_que_foi_entregue, tipo_do_chocolate, peso)
SELECT
    (SELECT id_fornecedor FROM Fornecedor ORDER BY RAND() LIMIT 1),
    F.id_filial,
    CONCAT('Chocolate ', T.n),
    FLOOR(RAND() * 500) + 1,
    FLOOR(RAND() * 50) + 10,
    CURDATE() + INTERVAL FLOOR(RAND() * 365) DAY,
    CURDATE() - INTERVAL FLOOR(RAND() * 30) DAY,
    CASE FLOOR(RAND() * 4)
        WHEN 0 THEN 'Amargo'
        WHEN 1 THEN 'Ao Leite'
        WHEN 2 THEN 'Branco'
        WHEN 3 THEN 'Com Recheio'
        ELSE 'Sem Açucar'
    END,
    FLOOR(RAND() * 200) + 50
FROM Filial F
JOIN (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b) AS T
WHERE T.n BETWEEN 1 AND 100
ORDER BY RAND();

-- Insere 200 Vendas
INSERT INTO Vendas (id_cliente, data_da_compra, valor_total, status, forma_de_pagamento, id_filial, data_do_envio)
SELECT
    (SELECT id_cliente FROM Cliente ORDER BY RAND() LIMIT 1),
    CURDATE() - INTERVAL FLOOR(RAND() * 365) DAY,
    0, -- O valor total será atualizado pelo gatilho
    CASE FLOOR(RAND() * 3)
        WHEN 0 THEN 'Entregue'
        WHEN 1 THEN 'Processando'
        ELSE 'Cancelado'
    END,
    CASE FLOOR(RAND() * 3)
        WHEN 0 THEN 'Cartão'
        WHEN 1 THEN 'Dinheiro'
        ELSE 'PIX'
    END,
    (SELECT id_filial FROM Filial ORDER BY RAND() LIMIT 1),
    CURDATE() + INTERVAL FLOOR(RAND() * 30) DAY
FROM (SELECT a.n + b.n * 10 AS n FROM (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a, (SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) b) AS T
WHERE T.n BETWEEN 1 AND 200;

-- Insere 300 Itens de Venda
INSERT INTO ItemVenda (id_venda, id_produto, quantidade, preco_unitario)
SELECT
    (SELECT id_venda FROM Vendas ORDER BY RAND() LIMIT 1),
    E.id_produto,
    FLOOR(RAND() * 5) + 1,
    E.preco
FROM Estoque E
ORDER BY RAND()
LIMIT 300;

-- -----------------------------------------------------
-- GATILHOS (INALTERADOS)
-- -----------------------------------------------------

DELIMITER $$

-- GATILHO: Atualiza o valor_total da venda e a quantidade em estoque
DROP TRIGGER IF EXISTS trg_after_itemvenda_insert;
CREATE TRIGGER trg_after_itemvenda_insert
AFTER INSERT ON ItemVenda
FOR EACH ROW
BEGIN
    UPDATE Vendas
    SET valor_total = valor_total + (NEW.quantidade * NEW.preco_unitario)
    WHERE id_venda = NEW.id_venda;
    
    UPDATE Estoque
    SET quantidade = quantidade - NEW.quantidade
    WHERE id_produto = NEW.id_produto;
END$$

-- GATILHO: Atualiza o valor_total da venda ao deletar um item
DROP TRIGGER IF EXISTS trg_after_itemvenda_delete;
CREATE TRIGGER trg_after_itemvenda_delete
AFTER DELETE ON ItemVenda
FOR EACH ROW
BEGIN
    UPDATE Vendas
    SET valor_total = valor_total - (OLD.quantidade * OLD.preco_unitario)
    WHERE id_venda = OLD.id_venda;
    
    UPDATE Estoque
    SET quantidade = quantidade + OLD.quantidade
    WHERE id_produto = OLD.id_produto;
END$$

-- GATILHO: Atualiza o valor_total da venda ao atualizar um item
DROP TRIGGER IF EXISTS trg_after_itemvenda_update;
CREATE TRIGGER trg_after_itemvenda_update
AFTER UPDATE ON ItemVenda
FOR EACH ROW
BEGIN
    UPDATE Vendas
    SET valor_total = valor_total
    + (NEW.quantidade * NEW.preco_unitario)
    - (OLD.quantidade * OLD.preco_unitario)
    WHERE id_venda = NEW.id_venda;
    
    UPDATE Estoque
    SET quantidade = quantidade - (NEW.quantidade - OLD.quantidade)
    WHERE id_produto = NEW.id_produto;
END$$

-- GATILHO: Atualiza o status de disponibilidade do produto ANTES da atualização do Estoque
DROP TRIGGER IF EXISTS trg_before_estoque_update;
CREATE TRIGGER trg_before_estoque_update
BEFORE UPDATE ON Estoque
FOR EACH ROW
BEGIN
    IF NEW.quantidade <= 0 THEN
        -- Aqui você pode adicionar uma lógica para uma coluna de 'disponibilidade'
        -- SET NEW.disponibilidade = 'indisponível';
        -- Nota: A sua tabela Estoque não possui uma coluna de 'disponibilidade',
        -- então esta linha está comentada para evitar erros.
        SELECT 'Este produto está indisponível' INTO @dummy;
    END IF;
END$$

DELIMITER ;

-- Reabilita a verificação de chaves estrangeiras
SET FOREIGN_KEY_CHECKS = 1;
-- -----------------------------------------------------
-- Consultas (JOINS)
-- -----------------------------------------------------

-- 1. Unir as tabelas de Clientes e Contas
-- Para visualizar os dados completos dos clientes e suas respectivas contas
SELECT
    C.nome AS nome_cliente,
    C.email,
    C.telefone,
    A.username,
    A.email AS email_conta
FROM Cliente AS C
JOIN Conta AS A ON C.id_conta = A.id_conta;

-- 2. Unir as tabelas de Funcionários e Contas
-- Para ver os dados de login e informações de contato dos funcionários
SELECT
    F.nome AS nome_funcionario,
    F.cargo,
    F.salario,
    A.username,
    A.email AS email_conta
FROM Funcionario AS F
JOIN Conta AS A ON F.id_conta = A.id_conta;

-- 3. Unir Vendas e Clientes
-- Para obter informações sobre quem fez cada compra
SELECT
    V.id_venda,
    C.nome AS nome_cliente,
    V.data_da_compra,
    V.valor_total
FROM Vendas AS V
JOIN Cliente AS C ON V.id_cliente = C.id_cliente;

-- 4. Unir Estoque e Fornecedores
-- Para saber de qual fornecedor cada produto em estoque veio
SELECT
    E.nome_do_chocolate,
    E.quantidade,
    F.nome AS nome_fornecedor,
    F.telefone AS telefone_fornecedor
FROM Estoque AS E
JOIN Fornecedor AS F ON E.id_fornecedor = F.id_fornecedor;

-- 5. Unir ItemVenda, Vendas e Estoque
-- Para detalhar cada item vendido em uma venda específica
SELECT
    V.id_venda,
    E.nome_do_chocolate,
    I.quantidade,
    I.preco_unitario
FROM ItemVenda AS I
JOIN Vendas AS V ON I.id_venda = V.id_venda
JOIN Estoque AS E ON I.id_produto = E.id_produto;

-- 6. Unir todas as tabelas relevantes para uma visão completa
-- Exemplo: Vendas, Clientes, Itens de Venda e Produtos
SELECT
    V.id_venda,
    V.data_da_compra,
    C.nome AS nome_cliente,
    E.nome_do_chocolate AS nome_produto,
    IV.quantidade,
    IV.preco_unitario,
    V.valor_total
FROM Vendas AS V
JOIN Cliente AS C ON V.id_cliente = C.id_cliente
JOIN ItemVenda AS IV ON V.id_venda = IV.id_venda
JOIN Estoque AS E ON IV.id_produto = E.id_produto
ORDER BY V.id_venda;